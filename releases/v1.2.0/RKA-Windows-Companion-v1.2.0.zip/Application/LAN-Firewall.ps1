# Retro Knights Arcade - LAN play. Lets every PC on the arcade's local network reach this PC,
# so any LAN game can host and join, while Windows Firewall keeps blocking the internet.
# Also turns off the inbound block rules Windows makes when a game's firewall prompt is
# cancelled or can't be answered (a standard guest can't approve it). Disable undoes both.
# Windows PowerShell 5.1. Enable, Disable and Maintain need an administrator or SYSTEM.
#Requires -Version 5.1
param([ValidateSet('Status','Preview','Enable','Disable','Maintain')][string]$Action='Status')
$ErrorActionPreference='Stop'
$Group='RKA LAN play'
$RuleName='RKA-LAN-Play-Local-Network'
$RuleDisplay='RKA LAN play: allow the local network'
$Root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\LanPlay'
$StateFile=Join-Path $Root 'state.json'
$LogFile=Join-Path $Root 'lan-play.log'
$Installed=Join-Path $Root 'LAN-Firewall.ps1'
$TaskName='RKA-LAN-Play'

function Write-Log([string]$message){try{if(Test-Path -LiteralPath $Root){Add-Content -LiteralPath $LogFile -Value ((Get-Date).ToString('o')+' '+$message) -Encoding UTF8}}catch{}}
function Assert-Admin {
 $p=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'LAN play changes need an administrator.'}
}
function Protect-Root {
 if(-not(Test-Path -LiteralPath $Root)){[void](New-Item -ItemType Directory -Path $Root -Force)}
 # SYSTEM and administrators change it; everyone else may only read the state.
 & "$env:SystemRoot\System32\icacls.exe" $Root '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX'|Out-Null
 if($LASTEXITCODE -ne 0){throw 'Cannot protect the LAN play folder.'}
}
function Read-State {
 if(Test-Path -LiteralPath $StateFile){
  try{$s=Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8|ConvertFrom-Json;return [pscustomobject]@{enabled=[bool]$s.enabled;disabledRules=@($s.disabledRules|ForEach-Object {[string]$_});changedUtc=[string]$s.changedUtc}}catch{}
 }
 return [pscustomobject]@{enabled=$false;disabledRules=@();changedUtc=''}
}
function Save-State($state){
 $state.changedUtc=[DateTime]::UtcNow.ToString('o')
 $tmp=$StateFile+'.tmp'
 [IO.File]::WriteAllText($tmp,($state|ConvertTo-Json -Depth 4),(New-Object Text.UTF8Encoding($false)))
 Move-Item -LiteralPath $tmp -Destination $StateFile -Force
}
# Inbound block rules with no group that name one program outside the Windows folder:
# the rules Windows adds from a game's firewall prompt. Built-in rules always have a group.
function Get-GameBlockRules {
 $windows=[IO.Path]::GetFullPath($env:SystemRoot).TrimEnd('\')+'\'
 foreach($rule in @(Get-NetFirewallRule -Direction Inbound -Action Block -ErrorAction SilentlyContinue|Where-Object {[string]::IsNullOrEmpty([string]$_.Group) -and [string]$_.Enabled -eq 'True'})){
  $program=[string]($rule|Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue).Program
  if([string]::IsNullOrWhiteSpace($program) -or $program -eq 'Any' -or $program -eq 'System'){continue}
  $full=[Environment]::ExpandEnvironmentVariables($program)
  if($full.StartsWith($windows,[StringComparison]::OrdinalIgnoreCase)){continue}
  [pscustomobject]@{Name=[string]$rule.Name;DisplayName=[string]$rule.DisplayName;Program=$full;Profile=[string]$rule.Profile}
 }
}
function Ensure-AllowRule {
 $rule=Get-NetFirewallRule -Name $RuleName -ErrorAction SilentlyContinue
 if(-not $rule){
  # LocalSubnet = addresses on this PC's own network. Edge traversal stays blocked,
  # so nothing from the internet gets in through this rule.
  New-NetFirewallRule -Name $RuleName -DisplayName $RuleDisplay -Group $Group -Description 'Added by RKA Companion. Lets PCs on the local network reach this PC for LAN games. Internet traffic stays blocked.' -Direction Inbound -Action Allow -RemoteAddress LocalSubnet -Profile Any -EdgeTraversalPolicy Block -Enabled True|Out-Null
  Write-Log 'Added the local network allow rule.'
 }elseif([string]$rule.Enabled -ne 'True'){Enable-NetFirewallRule -Name $RuleName;Write-Log 'Turned the local network allow rule back on.'}
}
function Disable-GameBlockRules($state){
 $done=@($state.disabledRules)
 foreach($r in @(Get-GameBlockRules)){
  Disable-NetFirewallRule -Name $r.Name
  $done+=$r.Name
  Write-Log ('Turned off block rule "'+$r.DisplayName+'" for '+$r.Program)
 }
 $state.disabledRules=@($done|Select-Object -Unique)
}
function Register-Maintenance {
 if([IO.Path]::GetFullPath($PSCommandPath) -ne [IO.Path]::GetFullPath($Installed)){Copy-Item -LiteralPath $PSCommandPath -Destination $Installed -Force}
 $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $action=New-ScheduledTaskAction -Execute $exe -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$Installed+'" -Action Maintain')
 # Runs when Windows adds a firewall rule (event 2004 on Windows 10, 2097 on Windows 11),
 # at startup, and hourly in case the event never fires.
 $class=Get-CimClass -Namespace 'Root/Microsoft/Windows/TaskScheduler' -ClassName 'MSFT_TaskEventTrigger'
 $onRule=New-CimInstance -CimClass $class -ClientOnly
 $onRule.Enabled=$true
 $onRule.Subscription='<QueryList><Query Id="0" Path="Microsoft-Windows-Windows Firewall With Advanced Security/Firewall"><Select Path="Microsoft-Windows-Windows Firewall With Advanced Security/Firewall">*[System[(EventID=2004 or EventID=2097)]]</Select></Query></QueryList>'
 $triggers=@((New-ScheduledTaskTrigger -AtStartup),$onRule,(New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)))
 $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
 $settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -Principal $principal -Settings $settings -Description 'RKA LAN play: keeps new game block rules off so LAN games work. Added by RKA Companion.' -Force|Out-Null
}
function Get-Report {
 $state=Read-State
 $allow=Get-NetFirewallRule -Name $RuleName -ErrorAction SilentlyContinue
 $task=Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
 $blocks=@(Get-GameBlockRules)
 $profiles=@(Get-NetFirewallProfile -ErrorAction SilentlyContinue)
 $networks=@(Get-NetConnectionProfile -ErrorAction SilentlyContinue)
 $off=@($profiles|Where-Object {[string]$_.Enabled -ne 'True'}|ForEach-Object {[string]$_.Name})
 $on=$state.enabled -and $allow -and [string]$allow.Enabled -eq 'True'
 $lines=@(
  ('LAN PLAY: '+$(if($on){'on'}else{'off'})),
  ('ALLOW RULE: '+$(if($allow){'present'}else{'missing'})),
  ('UPKEEP TASK: '+$(if($task){'ready'}else{'missing'})),
  ('GAME BLOCK RULES ACTIVE: '+$blocks.Count),
  ('TURNED OFF BY RKA: '+@($state.disabledRules).Count),
  ('FIREWALL: '+(@($profiles|ForEach-Object {$_.Name+' '+$(if([string]$_.Enabled -eq 'True'){'on'}else{'off'})}) -join ', '))
 )
 foreach($n in $networks){$lines+=('NETWORK: '+$n.Name+' ('+$n.NetworkCategory+')')}
 $summary=if($off.Count -eq $profiles.Count -and $profiles.Count -gt 0){'Windows Firewall is turned off on this PC'}
  elseif($on -and $blocks.Count -eq 0){'On: local network open, internet blocked'}
  elseif($on){'On; '+$blocks.Count+' new game block rule(s) get turned off within the hour'}
  else{'Off: games may hit firewall prompts the guest can''t answer'}
 $lines+=('SUMMARY: '+$summary)
 return @{lines=$lines;blocks=$blocks}
}

try{
 switch($Action){
  'Status' {(Get-Report).lines}
  'Preview' {
   $r=Get-Report
   $r.lines
   ''
   if($r.blocks.Count -eq 0){'Open to LAN would add one rule: allow all traffic from the local network. No game block rules need turning off.'}
   else{
    'Open to LAN would add one rule that allows all traffic from the local network,'
    'and turn off these block rules Windows made for games:'
    foreach($b in @($r.blocks|Select-Object -First 40)){('  '+$b.DisplayName+'  ->  '+$b.Program)}
    if($r.blocks.Count -gt 40){('  ...and '+($r.blocks.Count-40)+' more')}
   }
  }
  'Enable' {
   Assert-Admin;Protect-Root
   $state=Read-State
   Ensure-AllowRule
   Disable-GameBlockRules $state
   $state.enabled=$true;Save-State $state
   Register-Maintenance
   Write-Log 'LAN play turned on.'
   (Get-Report).lines
  }
  'Disable' {
   Assert-Admin
   if(Test-Path -LiteralPath $Root){Protect-Root}
   $state=Read-State
   Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
   Remove-NetFirewallRule -Name $RuleName -ErrorAction SilentlyContinue
   foreach($name in @($state.disabledRules)){
    if(Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue){Enable-NetFirewallRule -Name $name}
   }
   if(Test-Path -LiteralPath $Root){$state.enabled=$false;$state.disabledRules=@();Save-State $state}
   Write-Log 'LAN play turned off; the block rules RKA had turned off are back on.'
   (Get-Report).lines
  }
  'Maintain' {
   Assert-Admin
   $state=Read-State
   if(-not $state.enabled){exit 0}
   # Windows adds a game's rules in pairs (TCP and UDP); let it finish first.
   Start-Sleep -Seconds 3
   Ensure-AllowRule
   Disable-GameBlockRules $state
   Save-State $state
  }
 }
}catch{
 Write-Log ('LAN play '+$Action+' failed: '+$_.Exception.Message)
 Write-Output ('ERROR: '+$_.Exception.Message)
 exit 1
}
