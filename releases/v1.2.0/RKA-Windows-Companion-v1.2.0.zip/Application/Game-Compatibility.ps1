# v1.0.8 read-only admin compatibility diagnostics. Does NOT launch or elevate games.
#Requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$TargetSid)
$ErrorActionPreference='Stop'
try{
 $who=[Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not ([Security.Principal.WindowsPrincipal]$who).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Admin required for guest profile scan'}
 if($TargetSid -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Invalid standard guest SID'}
 $members=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
 if(@($members|Where-Object {$_.SID -and $_.SID.Value -eq $TargetSid}).Count -gt 0){throw 'Refusing to inspect administrator as guest'}
 $prof=Get-CimInstance Win32_UserProfile -Filter "SID='$TargetSid'" -ErrorAction Stop|Select-Object -First 1
 if(-not $prof -or -not $prof.LocalPath){throw 'Guest has not signed in yet'}
 Write-Output 'RKA Game & Startup Compatibility — READ ONLY'
 Write-Output ('Guest SID: '+$TargetSid)
 Write-Output 'This scan lists startup and shortcut clues; it cannot prove a game needs or does not need UAC elevation.'
 $shell=New-Object -ComObject WScript.Shell
 $locations=@(
  @{Label='Guest Desktop';Path=(Join-Path $prof.LocalPath 'Desktop')},
  @{Label='Public Desktop';Path=[Environment]::GetFolderPath('CommonDesktopDirectory')},
  @{Label='Guest Startup';Path=(Join-Path $prof.LocalPath 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup')},
  @{Label='Common Startup';Path=[Environment]::GetFolderPath('CommonStartup')}
 )
 $total=0
 foreach($loc in $locations){
  Write-Output ('--- '+$loc.Label+' ---')
  if(-not(Test-Path -LiteralPath $loc.Path)){Write-Output '(folder not available)';continue}
  foreach($f in @(Get-ChildItem -LiteralPath $loc.Path -File -ErrorAction SilentlyContinue|Where-Object {$_.Extension -in @('.lnk','.url')})){
   $total++;$target='(web shortcut)';$flags=@()
   try{
    if($f.Extension -eq '.lnk'){
     $lnk=$shell.CreateShortcut($f.FullName);$target=[string]$lnk.TargetPath
     $bytes=[IO.File]::ReadAllBytes($f.FullName)
     if($bytes.Length -ge 24 -and (([BitConverter]::ToUInt32($bytes,20) -band 0x2000) -ne 0)){$flags+='RUN AS ADMIN flag'}
     if($target -match '(?i)\\(Riot|ArmouryCrate|ArmoryCrate)'){$flags+='REVIEW startup/updates'}
     if($target -and $target.StartsWith((Join-Path ([Environment]::GetFolderPath('UserProfile')) 'AppData'),[StringComparison]::OrdinalIgnoreCase)){$flags+='ADMIN PRIVATE PROFILE'}
    }
   }catch{$flags+='unreadable shortcut'}
   Write-Output ('  '+$f.Name+' -> '+$target+' '+$(if($flags.Count){'['+($flags -join ', ')+']'}else{''}))
  }
 }
 Write-Output ('Shortcuts inspected: '+$total)
 $h=[Microsoft.Win32.Registry]::Users.OpenSubKey($TargetSid,$false)
 $mounted=$false;$mount=''
 if(-not $h){
  $dat=Join-Path $prof.LocalPath 'NTUSER.DAT'
  if(Test-Path $dat){$mount='RKA_COMPAT_'+[guid]::NewGuid().ToString('N');& "$env:SystemRoot\System32\reg.exe" load "HKU\$mount" $dat |Out-Null;if($LASTEXITCODE -eq 0){$h=[Microsoft.Win32.Registry]::Users.OpenSubKey($mount,$false);$mounted=$true}}
 }
 try{
  if($h){
   foreach($path in @('Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers','Software\Microsoft\Windows\CurrentVersion\Run','Software\Microsoft\Windows\CurrentVersion\RunOnce')){
    Write-Output ('--- HKCU\'+$path+' ---')
    $k=$h.OpenSubKey($path,$false)
    if($k){try{foreach($name in @($k.GetValueNames())){ $val=[string]$k.GetValue($name);Write-Output ('  '+$name+' = '+$val+$(if($val -match '(?i)RUNASADMIN|Riot|Armoury|Armory'){'  [REVIEW]'}else{''})) }}finally{$k.Dispose()}}
    else{Write-Output '(none)'}
   }
  }else{Write-Output 'Guest hive unavailable — sign out guest and rerun to read compatibility flags.'}
 }finally{if($h){$h.Dispose()};if($mounted){[GC]::Collect();[GC]::WaitForPendingFinalizers();& "$env:SystemRoot\System32\reg.exe" unload "HKU\$mount"|Out-Null}}
 Write-Output 'Guidance: Configure hardware utilities using admin account. Do not globally bypass UAC; first-run drivers and privileged game prerequisites still require staff approval.'
 exit 0
}catch{Write-Error $_.Exception.Message;exit 1}
