param([ValidateSet('Configure','Disable','Status')][string]$Action='Status',[string]$GuestName,[string]$GuestSid)
$ErrorActionPreference='Stop'
try {
 $principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator elevation required.'}
 if($GuestSid -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Invalid local guest SID.'}
 $account=Get-CimInstance Win32_UserAccount -Filter "SID='$GuestSid' AND LocalAccount=True" | Select-Object -First 1
 if(-not $account -or $account.Disabled -or $account.Name -ine $GuestName){throw 'Selected guest account is missing, disabled, or changed.'}
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
 if($admins -contains $GuestSid){throw 'Refusing administrator auto-sign-in.'}
 $key='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
 if($Action -eq 'Status') {
  $p=Get-ItemProperty -Path $key
  $enabled=([string]$p.AutoAdminLogon -eq '1')
  Write-Output ('Automatic Windows sign-in: '+$(if($enabled){'ENABLED'}else{'DISABLED'}))
  Write-Output ('Configured user: '+[string]$p.DefaultUserName)
  Write-Output ('Selected guest: '+$GuestName)
  Write-Output 'No password is displayed. This reads Winlogon status, not a successful sign-in test.'
  exit 0
 }
 $toolsDir=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\MicrosoftTools'
 if(-not(Test-Path $toolsDir)){New-Item -ItemType Directory -Path $toolsDir -Force | Out-Null}
 $exe=Join-Path $toolsDir 'Autologon64.exe'
 if(-not(Test-Path $exe)){
  $zip=Join-Path $toolsDir 'AutoLogon.zip'
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -Uri 'https://download.sysinternals.com/files/AutoLogon.zip' -OutFile $zip -UseBasicParsing -ErrorAction Stop
  Expand-Archive -LiteralPath $zip -DestinationPath $toolsDir -Force
 }
 if(-not(Test-Path $exe)){throw 'Microsoft Autologon64.exe not found in downloaded archive.'}
 $sig=Get-AuthenticodeSignature -LiteralPath $exe
 if($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Microsoft'){throw 'Microsoft Authenticode verification failed. Refusing to run.'}
 if($Action -eq 'Configure'){
  Write-Output ('Opening Microsoft Autologon. Set user '+$GuestName+' and computer/domain '+$env:COMPUTERNAME+'. Enter password only in Microsoft utility.')
  Start-Process -FilePath $exe -WorkingDirectory $toolsDir
 }else{
  # Do not use command-line password arguments. Official GUI offers Disable.
  Write-Output 'Opening Microsoft Autologon. Click Disable in its window.'
  Start-Process -FilePath $exe -WorkingDirectory $toolsDir
 }
 exit 0
}catch{Write-Error $_.Exception.Message;exit 1}
