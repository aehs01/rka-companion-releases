# Retro Knights Arcade Companion 1.2 - the guest lockdown items, in one place.
# Block writes an item's values into the guest's registry; Allow deletes them,
# which is Windows' default. So Allow and Unlock everything work however the
# guest was locked before, with no snapshot to go wrong. Dot-sourced by
# PolicyWorker.ps1 (the Companion window's actions), Remote-Operations.ps1
# (Lovable's agent) and the Companion window's status column. Defines only.
#Requires -Version 5.1

# Regs: each value's Path under the guest's HKEY_USERS\<sid>, Name, Value, Kind.
# Subkeys: whole subkeys that Allow deletes (the browser lists). Not 'Values'
# or 'Keys': those names return a hashtable's own collections.
$script:RkaGuestItems=[ordered]@{
 settings=@{Label='Settings and Control Panel';Regs=@(
  @{Path='Software\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='NoControlPanel';Value=1;Kind='DWord'})}
 cmd=@{Label='Command Prompt';Regs=@(
  @{Path='Software\Policies\Microsoft\Windows\System';Name='DisableCMD';Value=2;Kind='DWord'})}
 registry=@{Label='Registry Editor';Regs=@(
  @{Path='Software\Microsoft\Windows\CurrentVersion\Policies\System';Name='DisableRegistryTools';Value=1;Kind='DWord'})}
 taskmgr=@{Label='Task Manager';Regs=@(
  @{Path='Software\Microsoft\Windows\CurrentVersion\Policies\System';Name='DisableTaskMgr';Value=1;Kind='DWord'})}
 # Removes "Change a password" from Ctrl+Alt+Del. PolicyWorker also sets the
 # account's "user cannot change password" flag.
 password=@{Label='Password changes';Regs=@(
  @{Path='Software\Microsoft\Windows\CurrentVersion\Policies\System';Name='DisableChangePassword';Value=1;Kind='DWord'})}
 # Windows tips, suggestions, "get even more out of Windows" and notification
 # pop-ups, so nothing appears over a game.
 popups=@{Label='Windows tips and pop-ups';Regs=@(
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SoftLandingEnabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SystemPaneSuggestionsEnabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SubscribedContent-310093Enabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SubscribedContent-338388Enabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SubscribedContent-338389Enabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SubscribedContent-353694Enabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager';Name='SubscribedContent-353696Enabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement';Name='ScoobeSystemSettingEnabled';Value=0;Kind='DWord'},
  @{Path='Software\Microsoft\Windows\CurrentVersion\PushNotifications';Name='ToastEnabled';Value=0;Kind='DWord'},
  @{Path='Software\Policies\Microsoft\Windows\CloudContent';Name='DisableWindowsSpotlightFeatures';Value=1;Kind='DWord'},
  @{Path='Software\Policies\Microsoft\Windows\CloudContent';Name='DisableTailoredExperiencesWithDiagnosticData';Value=1;Kind='DWord'})}
 # The per-user "deny all removable storage" policy: only the guest loses USB
 # drives; administrators keep them.
 usb=@{Label='USB storage';Regs=@(
  @{Path='Software\Policies\Microsoft\Windows\RemovableStorageDevices';Name='Deny_All';Value=1;Kind='DWord'})}
 # Block writes the approved lists then '*' (values come from PolicyWorker's
 # Get-BrowserChanges); Allow deletes all four lists.
 browser=@{Label='Chrome and Edge websites';Regs=@();Subkeys=@(
  'Software\Policies\Google\Chrome\URLBlocklist','Software\Policies\Microsoft\Edge\URLBlocklist',
  'Software\Policies\Google\Chrome\URLAllowlist','Software\Policies\Microsoft\Edge\URLAllowlist')}
}
# What each item is called in a saved lockdown profile (profile.json and
# approved-policy.json).
$script:RkaProfileFlags=[ordered]@{settings='blockSettings';cmd='blockCmd';registry='blockRegistry';taskmgr='blockTaskManager';password='blockPassword';popups='blockPopups';usb='blockUsb';browser='restrictEdge'}

function Read-RkaValue($root,[string]$path,[string]$name){
 $k=$root.OpenSubKey($path,$false)
 if(-not $k){return $null}
 try{if($k.GetValueNames() -contains $name){return $k.GetValue($name)}else{return $null}}finally{$k.Dispose()}
}

# 'Blocked', 'Allowed' or 'Partly blocked', read from the guest's registry.
function Get-RkaItemState($root,[string]$item){
 $def=$script:RkaGuestItems[$item]
 if($null -eq $def){throw "Unknown lockdown item $item"}
 if($item -eq 'browser'){
  $chrome=Read-RkaValue $root 'Software\Policies\Google\Chrome\URLBlocklist' '1'
  $edge=Read-RkaValue $root 'Software\Policies\Microsoft\Edge\URLBlocklist' '1'
  $on=@(@($chrome,$edge)|Where-Object {[string]$_ -eq '*'}).Count
  return $(if($on -eq 2){'Blocked'}elseif($on -eq 0){'Allowed'}else{'Partly blocked'})
 }
 $matched=0
 foreach($v in $def.Regs){if([string](Read-RkaValue $root $v.Path $v.Name) -eq [string]$v.Value){$matched++}}
 return $(if($matched -eq $def.Regs.Count){'Blocked'}elseif($matched -eq 0){'Allowed'}else{'Partly blocked'})
}

# Writes (Block) or deletes (Allow) an item's values. $browserValues is the
# ordered list PolicyWorker builds for a browser Block: allowlists first,
# the '*' blocklists last.
function Set-RkaItem($root,[string]$item,[bool]$block,[object[]]$browserValues=@()){
 $def=$script:RkaGuestItems[$item]
 if($null -eq $def){throw "Unknown lockdown item $item"}
 if($item -eq 'browser'){
  foreach($key in $def.Subkeys){$root.DeleteSubKeyTree($key,$false)}
  if(-not $block){return}
  if(@($browserValues).Count -lt 3 -or @($browserValues)[-1].Value -ne '*'){throw 'Browser blocking needs the approved websites first.'}
  $values=$browserValues
 }else{
  $values=$def.Regs
 }
 foreach($v in $values){
  if($block){
   $k=$root.CreateSubKey($v.Path,$true)
   if(-not $k){throw "Unable to open registry key $($v.Path)"}
   try{$k.SetValue($v.Name,$v.Value,([Microsoft.Win32.RegistryValueKind][Enum]::Parse([Microsoft.Win32.RegistryValueKind],$v.Kind)))}finally{$k.Dispose()}
  }else{
   $k=$root.OpenSubKey($v.Path,$true)
   if($k){try{$k.DeleteValue($v.Name,$false)}finally{$k.Dispose()}}
  }
 }
}
