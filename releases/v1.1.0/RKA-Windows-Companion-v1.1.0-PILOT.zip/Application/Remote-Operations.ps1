﻿# RKA v1.0 remote operations. Dot-sourced ONLY by the authenticated SYSTEM command agent.
# No remote supplied paths, registry keys, scripts, or executable names are accepted.
$script:RkaRoot=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
$script:RkaRecovery=Join-Path $script:RkaRoot 'ItemRecovery'
$script:RkaAllowList=@('chrome_web','edge_web','control_panel','regedit','command_prompt','task_manager')
# Gaming sign-in, email-code and captcha sites, always kept in the guest browser allowlists.
# Fixed here, never taken from Lovable. Keep identical to $GameSignInSites in PolicyWorker.ps1.
$script:RkaGameSignInHosts=@('riotgames.com','leagueoflegends.com','playvalorant.com','epicgames.com','ea.com','battle.net','blizzard.com','ubisoft.com','ubi.com','steampowered.com','steamcommunity.com','xbox.com','account.sony.com','live.com','account.microsoft.com','login.microsoftonline.com','accounts.google.com','mail.google.com','login.yahoo.com','mail.yahoo.com','guce.yahoo.com','appleid.apple.com','idmsa.apple.com','icloud.com','hcaptcha.com','arkoselabs.com','challenges.cloudflare.com','recaptcha.net','www.google.com/recaptcha')
$script:RkaClientData=Join-Path $env:ProgramData 'RKA-Client'
function Require-Guest([string]$sid){
 if(-not(Is-ValidSid $sid)){throw 'Invalid standard guest SID'}
 $matches=@(StandardAccounts|Where-Object {$_.sid -ceq $sid})
 if($matches.Count -ne 1){throw 'Target guest no longer exists or is now an administrator'}
 return $matches[0]
}
function Open-GuestHive([string]$sid){
 $h=[Microsoft.Win32.Registry]::Users.OpenSubKey($sid,$true)
 if($h){return @{handle=$h;mount=$null}}
 $p=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop|Select-Object -First 1
 if(-not $p -or -not $p.LocalPath){throw 'Guest profile missing. Sign in once before remote changes'}
 $path=Join-Path $p.LocalPath 'NTUSER.DAT'
 if(-not(Test-Path -LiteralPath $path)){throw 'Guest registry hive unavailable'}
 $mount='RKA_REM_'+[guid]::NewGuid().ToString('N')
 & "$env:SystemRoot\System32\reg.exe" load "HKU\$mount" $path |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Guest hive is in use or inaccessible'}
 $h=[Microsoft.Win32.Registry]::Users.OpenSubKey($mount,$true)
 if(-not $h){throw 'Guest hive mount failed'}
 return @{handle=$h;mount=$mount}
}
function Close-GuestHive($h){
 if($h.handle){$h.handle.Dispose()}
 if($h.mount){[GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 180;& "$env:SystemRoot\System32\reg.exe" unload "HKU\$($h.mount)"|Out-Null}
}
function Read-Value($h,[string]$path,[string]$name){
 $k=$h.handle.OpenSubKey($path,$false)
 if(-not $k){return @{exists=$false;value=$null;kind='String'}}
 try {
  if($k.GetValueNames() -cnotcontains $name){return @{exists=$false;value=$null;kind='String'}}
  $kind=$k.GetValueKind($name).ToString()
  if($kind -notin @('String','DWord','ExpandString','MultiString')){throw 'Unsupported existing registry type'}
  return @{exists=$true;value=$k.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);kind=$kind}
 }finally{$k.Dispose()}
}
function Write-Value($h,[string]$path,[string]$name,$value,[string]$kind){
 $k=$h.handle.CreateSubKey($path,$true)
 if(-not $k){throw 'Guest registry key unavailable'}
 try{$k.SetValue($name,$value,([Microsoft.Win32.RegistryValueKind][Enum]::Parse([Microsoft.Win32.RegistryValueKind],$kind)))}finally{$k.Dispose()}
}
function Delete-Value($h,[string]$path,[string]$name){
 $k=$h.handle.OpenSubKey($path,$true)
 if($k){try{$k.DeleteValue($name,$false)}finally{$k.Dispose()}}
}
function Registry-Spec([string]$item){
 switch($item){
  'control_panel' {return @{path='Software\Microsoft\Windows\CurrentVersion\Policies\Explorer';name='NoControlPanel';value=1}}
  'regedit' {return @{path='Software\Microsoft\Windows\CurrentVersion\Policies\System';name='DisableRegistryTools';value=1}}
  'command_prompt' {return @{path='Software\Policies\Microsoft\Windows\System';name='DisableCMD';value=2}}
  'chrome_web' {return @{path='Software\Policies\Google\Chrome\URLBlocklist';name='1';value='*'}}
  'edge_web' {return @{path='Software\Policies\Microsoft\Edge\URLBlocklist';name='1';value='*'}}
  'task_manager' {return @{path='Software\Microsoft\Windows\CurrentVersion\Policies\System';name='DisableTaskMgr';value=1}}
  default {throw 'Unsupported individual restriction'}
 }
}
function State-Value($h,$spec){
 $v=Read-Value $h $spec.path $spec.name
 if(-not $v.exists){return 'not_configured'}
 if(([string]$v.value) -eq ([string]$spec.value)){return 'match'}
 return 'missing'
}
function Snapshot-Path([string]$sid,[string]$item){return Join-Path $script:RkaRecovery ($sid+'-'+$item+'.json')}
function Save-First-Snapshot([string]$sid,[string]$item,$data){
 if(-not(Test-Path -LiteralPath $script:RkaRecovery)){[void](New-Item -ItemType Directory -Path $script:RkaRecovery -Force)}
 $path=Snapshot-Path $sid $item
 if(-not(Test-Path -LiteralPath $path)){
  $data|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $path -Encoding UTF8 -NoNewline -ErrorAction Stop
 }
 return $path
}
# v1.0.8: remote targeted policy changes may coexist with the local full-policy
# recovery snapshot. Add missing ORIGINAL registry states to the SAME protected
# full snapshot before a remote edit; local Restore then reverses both its old
# policy and any newer typed remote edits. Existing baseline keys are NEVER
# overwritten, so repeated toggles do not change the original restore point.
function Get-FullPolicySnapshot([string]$sid){
 $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery'
 $pointer=Join-Path $root 'current.json'
 if(-not(Test-Path -LiteralPath $pointer)){return $null}
 $ptr=Get-Content -LiteralPath $pointer -Raw -Encoding UTF8|ConvertFrom-Json
 $file=[string]$ptr.path
 if([string]::IsNullOrWhiteSpace($file) -or -not [IO.Path]::IsPathRooted($file)){throw 'Full recovery pointer invalid; local administrator recovery required'}
 $expectedRoot=[IO.Path]::GetFullPath($root).TrimEnd('\')+'\'
 $full=[IO.Path]::GetFullPath($file)
 if(-not $full.StartsWith($expectedRoot,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($full) -ne '.json'){
  throw 'Full recovery snapshot path outside protected Recovery directory; no remote policy change made'
 }
 if(-not(Test-Path -LiteralPath $full)){throw 'Full recovery snapshot missing; no remote policy change made'}
 $backup=Get-Content -LiteralPath $full -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$backup.sid -cne $sid){throw 'Full policy recovery belongs to another guest; no remote change made'}
 if([string]$backup.status -ne 'active' -and [string]$backup.status -ne 'prepared'){
  throw 'Full policy recovery is not active; no remote change made'
 }
 if(-not $backup.PSObject.Properties['before']){throw 'Full policy recovery is missing original values'}
 return @{path=$full;value=$backup}
}
function Ensure-FullRestoreKeys([string]$sid,$h,[object[]]$keys){
 $full=Get-FullPolicySnapshot $sid
 if($null -eq $full){return $false}
 $backup=$full.value
 $entries=New-Object System.Collections.ArrayList
 foreach($old in @($backup.before)){[void]$entries.Add($old)}
 $known=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 foreach($old in @($entries)){[void]$known.Add(([string]$old.Path)+'|'+([string]$old.Name))}
 $added=0
 foreach($item in $keys){
  $key=([string]$item.path)+'|'+([string]$item.name)
  if(-not $known.Add($key)){continue}
  $previous=Read-Value $h ([string]$item.path) ([string]$item.name)
  [void]$entries.Add(@{Path=[string]$item.path;Name=[string]$item.name;Exists=[bool]$previous.exists;Value=$previous.value;Kind=[string]$previous.kind})
  $added++
 }
 if($added -gt 0){
  $backup.before=@($entries.ToArray())
  # Replace on the same NTFS volume atomically; .pre-remote.bak is retained
  # for administrator forensic recovery. Fail closed before editing the guest.
  $tmp=$full.path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
  try{
   $backup|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $tmp -Encoding UTF8 -NoNewline -ErrorAction Stop
   [IO.File]::Replace($tmp,$full.path,($full.path+'.pre-remote.bak'))
  }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}}
 }
 return $true
}
function Browser-KeysForChange($h,[string]$browser,[int]$desiredCount){
 $path='Software\Policies\'+$browser+'\URLAllowlist'
 $names=New-Object System.Collections.ArrayList
 $k=$h.handle.OpenSubKey($path,$false)
 if($k){try{foreach($name in @($k.GetValueNames())){if($name -cmatch '^\d+$'){[void]$names.Add($name)}}}finally{$k.Dispose()}}
 for($i=1;$i -le $desiredCount;$i++){[void]$names.Add([string]$i)}
 return @($names|Select-Object -Unique|ForEach-Object {@{path=$path;name=[string]$_}})
}

# v1.0.4: safely initialize guest browser allowlists BEFORE any wildcard block.
# A missing list is not interpreted as an intentional empty list: use the last
# explicitly saved remote/local profile if present, otherwise seed RKA defaults.
# Existing nonempty custom lists are preserved, including per-PC exclusions.
function Get-SafeInitialHosts([string]$sid){
 $sites=Join-Path $script:RkaRoot 'approved-websites-state.json'
 if(Test-Path -LiteralPath $sites){
  try{
   $record=Get-Content -LiteralPath $sites -Raw -Encoding UTF8|ConvertFrom-Json
   if([string]$record.sid -ceq $sid -and [string]$record.source -eq 'authenticated_remote_command'){
    return @($record.hosts|ForEach-Object {[string]$_}|Where-Object {Host-Valid $_}|Select-Object -Unique)
   }
  }catch{}
 }
 $saved=Join-Path $script:RkaRoot 'approved-policy.json'
 if(Test-Path -LiteralPath $saved){
  try{
   $p=Get-Content -LiteralPath $saved -Raw -Encoding UTF8|ConvertFrom-Json
   $g=Require-Guest $sid
   if([string]$p.account -ceq [string]$g.account_name){
    $list=@()
    foreach($url in @($p.urls)){
     $parsed=$null
     if([uri]::TryCreate([string]$url,[uriKind]::Absolute,[ref]$parsed) -and $parsed.Scheme -in @('http','https')){
      $h=$parsed.Host.ToLowerInvariant()
      if(Host-Valid $h){$list+=$h}
     }
    }
    return @($list|Select-Object -Unique)
   }
  }catch{}
 }
 # Only when no explicit list exists, use the packaged baseline. This is
 # defensive initialization, NOT a replacement for fleet defaults in Lovable.
 return @('discord.com','discord.gg','cdn.discordapp.com','media.discordapp.net')
}
function Ensure-BrowserAllowlist([string]$sid,$h){
 $intranet=Intranet-Host
 $oldChrome=@(Read-HostList $h 'Google\Chrome')
 $oldEdge=@(Read-HostList $h 'Microsoft\Edge')
 $current=@($oldChrome)+@($oldEdge)
 $preserved=@($current|Where-Object {Host-Valid (([string]$_).ToLowerInvariant())}|ForEach-Object {([string]$_).ToLowerInvariant()}|Select-Object -Unique)
 if($preserved.Count -eq 0){$preserved=@(Get-SafeInitialHosts $sid)}
 $required=@($intranet.host,'edge://policy','chrome://policy')+$script:RkaGameSignInHosts
 if(-not $intranet.isDefault){$required+=($intranet.host+':'+$intranet.port)}
 # Keep explicit browser-specific policies already present; only repair
 # absent protected intranet and empty policy lists. Never replace nonempty
 # per-browser custom entries with a global default without approval.
 foreach($browser in @('Google\Chrome','Microsoft\Edge')){
  $existing=if($browser -eq 'Google\Chrome'){$oldChrome}else{$oldEdge}
  $wanted=if($existing.Count -gt 0){@($existing)+$required}else{@($preserved)+$required}
  $wanted=@($wanted|Where-Object {-not [string]::IsNullOrWhiteSpace([string]$_)}|Select-Object -Unique)
  if($wanted.Count -gt 64){throw 'Browser approved site list exceeds safe limit; block refused'}
  if($wanted.Count -ne $existing.Count -or @($required|Where-Object {$_ -notin $existing}).Count -gt 0){
   $fullActive=Ensure-FullRestoreKeys $sid $h @((Browser-KeysForChange $h $browser $wanted.Count))
   if(-not $fullActive){[void](Save-First-Snapshot $sid 'browser_allowlist' @{sid=$sid;item='browser_allowlist';chrome=$oldChrome;edge=$oldEdge;createdAt=(Get-Date).ToUniversalTime().ToString('o')})}
   Set-HostList $h $browser $wanted
  }
 }
 # Block only after both browser policy values were read back as present.
 foreach($browser in @('Google\Chrome','Microsoft\Edge')){
  $observed=@(Read-HostList $h $browser)
  if($observed.Count -lt 1 -or $intranet.host -notin $observed){
   throw 'Browser allowlist verification failed; wildcard block not applied'
  }
 }
}
function Set-GuestRestriction([string]$sid,[string]$item,[bool]$enabled){
 [void](Require-Guest $sid)
 if($item -notin $script:RkaAllowList){throw 'Unsupported local guest restriction'}
 $spec=Registry-Spec $item
 $h=$null
 try{
  $h=Open-GuestHive $sid
  $current=Read-Value $h $spec.path $spec.name
  $snapshot=Snapshot-Path $sid $item
  $fullActive=Ensure-FullRestoreKeys $sid $h @(@{path=$spec.path;name=$spec.name})
  if($enabled){
   if($item -in @('chrome_web','edge_web')){Ensure-BrowserAllowlist $sid $h}
   if(-not $fullActive){[void](Save-First-Snapshot $sid $item @{sid=$sid;item=$item;before=@{path=$spec.path;name=$spec.name;state=$current};createdAt=(Get-Date).ToUniversalTime().ToString('o')})}
   $kind=if($item -in @('chrome_web','edge_web')){'String'}else{'DWord'}
   Write-Value $h $spec.path $spec.name $spec.value $kind
  }else{
   if($fullActive){Delete-Value $h $spec.path $spec.name}
   elseif(-not(Test-Path -LiteralPath $snapshot)){
    # No backup: safe no-op only if restriction is already absent.
    if($current.exists){throw 'No per-item snapshot; restore the earlier full policy locally first'}
   }else{
    $saved=Get-Content -LiteralPath $snapshot -Raw|ConvertFrom-Json
    if($saved.sid -cne $sid -or $saved.item -cne $item){throw 'Snapshot ownership mismatch'}
    if($saved.before.state.exists){
     $v=$saved.before.state.value
     if($saved.before.state.kind -eq 'DWord'){$v=[int]$v}
     if($saved.before.state.kind -eq 'MultiString'){$v=[string[]]@($v)}
     Write-Value $h $spec.path $spec.name $v ([string]$saved.before.state.kind)
    }else{Delete-Value $h $spec.path $spec.name}
   }
  }
  $state=State-Value $h $spec
  if($enabled -and $state -ne 'match'){throw 'Restriction write failed registry verification'}
  return @{restriction=$item;registry=$state;scope='guest';enforcement='not_verified';guest_sid=$sid}
 }finally{if($h){Close-GuestHive $h}}
}
function Host-Valid([string]$hostname){return $hostname -cmatch '^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'}
function Intranet-Host {
 $profilePath=Join-Path $script:RkaRoot 'approved-policy.json'
 $value='http://rkaserver/'
 if(Test-Path -LiteralPath $profilePath){$p=Get-Content -LiteralPath $profilePath -Raw|ConvertFrom-Json;if($p.intranet){$value=[string]$p.intranet}}
 $uri=$null
 if(-not [uri]::TryCreate($value,[uriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.UserInfo){throw 'Locally configured intranet URL is invalid'}
 return @{url=$uri.AbsoluteUri;host=$uri.Host.ToLowerInvariant();port=$uri.Port;isDefault=$uri.IsDefaultPort}
}
function Read-HostList($h,[string]$browser){
 $path="Software\Policies\$browser\URLAllowlist"
 $k=$h.handle.OpenSubKey($path,$false)
 $v=@()
 if($k){try{foreach($name in @($k.GetValueNames()|Sort-Object {[int]($_ -as [int])})){$x=$k.GetValue($name);if($x -is [string]){$v+=([string]$x)}}}finally{$k.Dispose()}}
 return @($v)
}
function Set-HostList($h,[string]$browser,[string[]]$hosts){
 $path="Software\Policies\$browser\URLAllowlist"
 $k=$h.handle.CreateSubKey($path,$true)
 if(-not $k){throw 'Cannot open allowlist policy'}
 try{
  foreach($name in @($k.GetValueNames())){if($name -cmatch '^\d+$'){$k.DeleteValue($name,$false)}}
  $i=1;foreach($hostname in @($hosts|Select-Object -Unique)){$k.SetValue([string]$i,[string]$hostname,[Microsoft.Win32.RegistryValueKind]::String);$i++}
 }finally{$k.Dispose()}
}
function Effective-HostList($h){
 $intranet=Intranet-Host
 $chrome=@(Read-HostList $h 'Google\Chrome')
 $edge=@(Read-HostList $h 'Microsoft\Edge')
 # Report only hosts observed in BOTH Chrome and Edge, avoiding false
 # union-based "allowed" status when one browser lacks an entry.
 $both=@($chrome|Where-Object {$_ -in $edge}|Select-Object -Unique)
 $hosts=@()
 foreach($val in $both){
  $v=([string]$val).ToLowerInvariant()
  if(((Host-Valid $v) -or $v -eq $intranet.host) -and $v -notin $script:RkaGameSignInHosts){$hosts+=$v}
 }
 return @($hosts|Select-Object -Unique|Select-Object -First 50)
}
function Set-BrowserAllowlist([string]$sid,[string]$mode,[string[]]$hosts){
 [void](Require-Guest $sid)
 if($mode -notin @('add','remove','replace') -or $hosts.Count -gt 25 -or (($mode -ne 'replace') -and $hosts.Count -eq 0)){throw 'Invalid allowlist change'}
 foreach($hostname in $hosts){if(-not(Host-Valid $hostname)){throw 'Invalid hostname in allowlist'}}
 if(@($hosts|Select-Object -Unique).Count -ne $hosts.Count){throw 'Duplicate allowlist host'}
 $intranet=Intranet-Host
 $h=$null
 try{
  $h=Open-GuestHive $sid
  $oldChrome=@(Read-HostList $h 'Google\Chrome');$oldEdge=@(Read-HostList $h 'Microsoft\Edge')
  $base=@(Effective-HostList $h)
  if($mode -eq 'replace'){$next=@($hosts)}elseif($mode -eq 'add'){$next=@($base)+@($hosts)}else{$next=@($base|Where-Object {$_ -notin $hosts})}
  $next=@($next|Where-Object {$_ -ne $intranet.host}|Select-Object -Unique)
  # Browser diagnostic URL / Discord entries are retained unless explicitly removed via local admin.
  $protected=@($intranet.host,'edge://policy','chrome://policy')+$script:RkaGameSignInHosts
  if(-not $intranet.isDefault){$protected+=($intranet.host+':'+$intranet.port)}
  $next=@($next|Where-Object {$_ -notin $script:RkaGameSignInHosts})
  $effective=@($next)+$protected
  if($effective.Count -gt 64){throw 'Allowlist too long to apply safely'}
  $fullActive=Ensure-FullRestoreKeys $sid $h @((Browser-KeysForChange $h 'Google\Chrome' $effective.Count)+(Browser-KeysForChange $h 'Microsoft\Edge' $effective.Count))
  if(-not $fullActive){[void](Save-First-Snapshot $sid 'browser_allowlist' @{sid=$sid;item='browser_allowlist';chrome=$oldChrome;edge=$oldEdge;createdAt=(Get-Date).ToUniversalTime().ToString('o')})}
  Set-HostList $h 'Google\Chrome' $effective
  Set-HostList $h 'Microsoft\Edge' $effective
  # Re-read effective lists before persisting. This is a non-secret local state
  # projection for the admin GUI; never write into another user's AppData.
  $verifyChrome=@(Read-HostList $h 'Google\Chrome')
  $verifyEdge=@(Read-HostList $h 'Microsoft\Edge')
  foreach($hostName in $effective){
   if($hostName -notin $verifyChrome -or $hostName -notin $verifyEdge){throw 'Browser allowlist did not verify in both registry locations'}
  }
  $sync=@{schema=1;sid=$sid;hosts=@($next);intranet=$intranet.url;updatedUtc=[DateTime]::UtcNow.ToString('o');source='authenticated_remote_command'}
  $syncTemp=Join-Path $script:RkaRoot ('approved-websites-'+[guid]::NewGuid().ToString('N')+'.tmp')
  try{
   $sync|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $syncTemp -Encoding UTF8 -NoNewline
   Move-Item -LiteralPath $syncTemp -Destination (Join-Path $script:RkaRoot 'approved-websites-state.json') -Force
  }finally{if(Test-Path -LiteralPath $syncTemp){Remove-Item -LiteralPath $syncTemp -Force -ErrorAction SilentlyContinue}}
  return @{applied=$true;hosts_effective=@($next);intranet_preserved=$true;staged_until_signin=$false;enforcement='not_verified'}
 }finally{if($h){Close-GuestHive $h}}
}
function Run-LocalScript([string]$file,[string[]]$parameters){
 $path=Join-Path $script:RkaRoot $file
 if(-not(Test-Path -LiteralPath $path)){throw 'Required installed helper missing'}
 $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $quoted=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File','"'+$path+'"')+@($parameters)
 $p=Start-Process -FilePath $ps -ArgumentList ($quoted -join ' ') -PassThru -Wait -WindowStyle Hidden
 if($p.ExitCode -ne 0){throw 'Local helper could not complete safely; review its protected log'}
}
function Set-ChromeAutolaunch([string]$sid,[bool]$enabled){
 $guest=Require-Guest $sid
 $intranet=Intranet-Host
 if($enabled){
  Run-LocalScript 'Chrome-Portal-Setup.ps1' @('-Action','Install','-UserName','"'+$guest.account_name+'"','-Url','"'+$intranet.url+'"','-Mode','Fullscreen')
 }else{
  $cfg=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\ChromePortal\config.json'
  if(Test-Path -LiteralPath $cfg){$c=Get-Content -LiteralPath $cfg -Raw|ConvertFrom-Json;if($c.sid -cne $sid){throw 'Chrome startup belongs to a different guest'}}
  Run-LocalScript 'Chrome-Portal-Setup.ps1' @('-Action','Remove')
 }
 return @{enabled=$enabled;guest_sid=$sid;browser='chrome';note='Configured; verify at next guest sign-in'}
}
function Get-PolicyInventory([string]$sid){
 [void](Require-Guest $sid)
 $items=@();$h=$null
 try{
  $h=Open-GuestHive $sid
  foreach($key in @('chrome_web','edge_web','control_panel','regedit','command_prompt','task_manager')){
   $items+=@{key=$key;scope='guest';registry=(State-Value $h (Registry-Spec $key));enforcement='not_verified'}
  }
  $intranet=Intranet-Host
  $chrome=@(Read-HostList $h 'Google\Chrome')
  $edge=@(Read-HostList $h 'Microsoft\Edge')
  $intranetPresent=($intranet.host -in $chrome -and $intranet.host -in $edge)
  $items+=@{key='intranet_allowlist';scope='guest';registry=$(if($intranetPresent){'match'}else{'missing'});enforcement='not_verified'}
  $browserEvidence=if($chrome.Count -eq 0 -and $edge.Count -eq 0){'not_configured'}elseif($chrome.Count -eq 0 -or $edge.Count -eq 0 -or -not $intranetPresent){'missing'}else{'match'}
  $items+=@{key='browser_allowlist';scope='guest';registry=$browserEvidence;enforcement='not_verified';hosts=@(Effective-HostList $h);detail=('Chrome entries='+$chrome.Count+'; Edge entries='+$edge.Count+'; protected intranet='+$intranetPresent)}
 }finally{if($h){Close-GuestHive $h}}
 $usbKey='HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices'
 $usb=Get-ItemProperty -LiteralPath $usbKey -Name Deny_All -ErrorAction SilentlyContinue
 $items+=@{key='usb_storage';scope='system';registry=$(if($null -eq $usb){'not_configured'}elseif([int]$usb.Deny_All -eq 1){'match'}else{'missing'});enforcement='not_verified'}
 $chromeCfg=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\ChromePortal\config.json'
 $state='not_configured'
 if(Test-Path -LiteralPath $chromeCfg){try{$c=Get-Content -LiteralPath $chromeCfg -Raw|ConvertFrom-Json;if($c.sid -eq $sid -and $c.enabled){$state='match'}}catch{$state='unknown'}}
 $items+=@{key='chrome_autolaunch';scope='guest';registry=$state;enforcement='not_verified'}
 return $items
}
function Guest-Task([string]$sid,[string]$action,[string]$instruction,[string]$suffix){
 $guest=Require-Guest $sid
 $taskName='RKA-Guest-'+$action+'-'+$suffix
 $script=Join-Path $script:RkaRoot 'Guest-Action.ps1'
 $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $args='-NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$script+'" -Action '+$action+' -InstructionFile "'+$instruction+'"'
 $user=$env:COMPUTERNAME+'\'+$guest.account_name
 $trigger=if($action -eq 'Announcement'){New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(10)}else{New-ScheduledTaskTrigger -AtLogOn -User $user}
 $principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 2)
 Register-ScheduledTask -TaskName $taskName -Action (New-ScheduledTaskAction -Execute $exe -Argument $args) -Principal $principal -Trigger $trigger -Settings $settings -Force -ErrorAction Stop|Out-Null
 if($action -ne 'Announcement'){try{Start-ScheduledTask -TaskName $taskName -ErrorAction Stop}catch{}}
 return @{task=$taskName;state='staged';note='Scheduled for interactive guest session; display/application not yet verified'}
}
function Guest-Instruction([string]$sid,[string]$action,$data,[string]$name){
 $dir=Join-Path $script:RkaRoot 'GuestActions'
 if(-not(Test-Path -LiteralPath $dir)){[void](New-Item -ItemType Directory -Path $dir -Force)}
 $path=Join-Path $dir ($name+'.json')
 $data.sid=$sid
 $data|ConvertTo-Json -Depth 5 |Set-Content -LiteralPath $path -Encoding UTF8
 # Allow Users to read only the specific guest instructions and approved images, never to modify them.
 & "$env:SystemRoot\System32\icacls.exe" $dir '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Cannot protect guest delivery directory'}
 return $path
}
# RKA Client 0.5+ reads messages from an inbox that SYSTEM writes and guests can
# only read. Each file is data (a kind, an id and plain text), never a command line.
function Client-Inbox {return (Join-Path $script:RkaClientData 'inbox')}
function Client-Running {return (@(Get-Process -Name 'RkaClient' -ErrorAction SilentlyContinue).Count -gt 0)}
function Send-ClientMessage([string]$kind,[string]$message,[string]$commandId,[int]$minutes){
 if($kind -notin @('announcement','reset','unlock','lock')){throw 'Unsupported RKA Client message'}
 if($commandId -notmatch '^[0-9a-fA-F-]{36}$'){throw 'Invalid command id'}
 $inbox=Client-Inbox
 if(-not(Test-Path -LiteralPath $inbox -PathType Container)){throw 'RKA Client 0.5 or later is not installed on this PC'}
 # Clear out messages older than a day so the inbox stays small.
 Get-ChildItem -LiteralPath $inbox -Filter '*.json' -File -ErrorAction SilentlyContinue|Where-Object {$_.LastWriteTimeUtc -lt [DateTime]::UtcNow.AddDays(-1)}|Remove-Item -Force -ErrorAction SilentlyContinue
 $now=[DateTime]::UtcNow
 $body=[ordered]@{schema=1;kind=$kind;id=$commandId.ToLowerInvariant();message=$message;sentUtc=$now.ToString('o');expiresUtc=$now.AddMinutes($minutes).ToString('o')}
 $final=Join-Path $inbox ($kind+'-'+$commandId.ToLowerInvariant()+'.json')
 $tmp=$final+'.tmp'
 try{
  [IO.File]::WriteAllText($tmp,($body|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination $final -Force
 }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}}
 $running=Client-Running
 return @{delivered_to='rka_client';client_running=$running;state=$(if($running){'queued_for_display'}else{'waiting_for_client'});enforcement='not_verified'}
}
function Reset-ClientSession([string]$commandId){
 if(-not(Client-Running)){throw 'RKA Client is not running on this PC'}
 return Send-ClientMessage 'reset' '' $commandId 5
}
function Set-ClientStaffMode([bool]$enabled,[string]$commandId){
 if(-not(Client-Running)){throw 'RKA Client is not running on this PC'}
 return Send-ClientMessage $(if($enabled){'unlock'}else{'lock'}) '' $commandId 2
}
function Announce-Guest([string]$sid,[string]$message,[string]$commandId){
 [void](Require-Guest $sid)
 if($message.Length -gt 240 -or $message.Length -eq 0 -or $message -match '[\x00-\x1f\x7f<>]' -or $message -match 'https?://'){throw 'Message format not allowed'}
 if(Test-Path -LiteralPath (Client-Inbox) -PathType Container){return Send-ClientMessage 'announcement' $message $commandId 15}
 $active=@(Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" -ErrorAction SilentlyContinue|ForEach-Object {try{(Invoke-CimMethod -InputObject $_ -MethodName GetOwnerSid -ErrorAction Stop).Sid}catch{$null}}|Where-Object {$_ -ceq $sid})
 if($active.Count -eq 0){throw 'Guest is not signed in; announcement not scheduled'}
 if($message.Length -gt 240 -or $message.Length -eq 0 -or $message -match '[\x00-\x1f\x7f<>]' -or $message -match 'https?://'){throw 'Message format not allowed'}
 $file=Guest-Instruction $sid 'Announcement' @{message=$message} ('note-'+$commandId)
 return Guest-Task $sid 'Announcement' $file ($commandId.Substring(0,8))
}
function Apply-GuestWallpaper([string]$sid,[string]$image,[string]$commandId){
 [void](Require-Guest $sid)
 $statePath=Snapshot-Path $sid 'wallpaper'
 $h=$null
 try{
  $h=Open-GuestHive $sid
  $old=Read-Value $h 'Control Panel\Desktop' 'WallPaper'
  if(-not(Test-Path -LiteralPath $statePath)){
   if(-not $old.exists -or -not(Test-Path -LiteralPath ([string]$old.value))){throw 'Cannot safely capture current wallpaper for restore'}
   [void](Save-First-Snapshot $sid 'wallpaper' @{sid=$sid;item='wallpaper';previous=[string]$old.value;createdAt=(Get-Date).ToUniversalTime().ToString('o')})
  }
 }finally{if($h){Close-GuestHive $h}}
 $file=Guest-Instruction $sid 'Wallpaper' @{image=$image} ('wallpaper-'+$sid)
 return Guest-Task $sid 'Wallpaper' $file ($sid.Split('-')[-1])
}
function Restore-GuestWallpaper([string]$sid){
 [void](Require-Guest $sid)
 $statePath=Snapshot-Path $sid 'wallpaper'
 if(-not(Test-Path -LiteralPath $statePath)){throw 'No safe original wallpaper snapshot'}
 $state=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json
 if($state.sid -cne $sid -or -not(Test-Path -LiteralPath ([string]$state.previous))){throw 'Original wallpaper unavailable'}
 $file=Guest-Instruction $sid 'Wallpaper' @{image=[string]$state.previous} ('wallpaper-'+$sid)
 return Guest-Task $sid 'Wallpaper' $file ($sid.Split('-')[-1])
}
function Acquire-Wallpaper($cmd,[string]$device){
 $meta=$cmd.wallpaper
 if($null -eq $meta -or ([string]$meta.sha256 -cnotmatch '^[a-f0-9]{64}$')){throw 'Missing trusted wallpaper metadata'}
 if($meta.mime -notin @('image/jpeg','image/png') -or [int]$meta.bytes -gt 10485760 -or [int]$meta.bytes -lt 128){throw 'Unsupported wallpaper image'}
 $grant=Post-Server @{action='wallpaper_grant';device_id=$device;command_id=[string]$cmd.id;nonce=[string]$cmd.nonce}
 if($grant.ok -ne $true -or $grant.sha256 -cne $meta.sha256){throw 'Wallpaper grant invalid'}
 $uri=[Uri][string]$grant.url
 if($uri.Scheme -cne 'https' -or $uri.Host -notmatch '(^|\.)supabase\.co$'){throw 'Wallpaper grant URL is not a trusted storage host'}
 $dir=Join-Path $script:RkaRoot 'GuestActions'
 if(-not(Test-Path -LiteralPath $dir)){[void](New-Item -ItemType Directory -Path $dir -Force)}
 $ext=$(if($meta.mime -eq 'image/png'){'.png'}else{'.jpg'})
 $output=Join-Path $dir ($meta.sha256+$ext)
 if(-not(Test-Path -LiteralPath $output)){
  $temp=Join-Path $script:RkaRoot ('wallpaper-'+[guid]::NewGuid().ToString('N')+'.tmp')
  try{
   Invoke-WebRequest -Uri $uri.AbsoluteUri -OutFile $temp -UseBasicParsing -TimeoutSec 25 -MaximumRedirection 0 -ErrorAction Stop
   if((Get-Item -LiteralPath $temp).Length -ne [int64]$meta.bytes){throw 'Wallpaper size differs from approved asset'}
   if((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$meta.sha256){throw 'Wallpaper checksum differs from approved asset'}
   Add-Type -AssemblyName System.Drawing
   $img=[System.Drawing.Image]::FromFile($temp)
   try{
    $actualMime=$(if($img.RawFormat.Guid -eq [System.Drawing.Imaging.ImageFormat]::Png.Guid){'image/png'}elseif($img.RawFormat.Guid -eq [System.Drawing.Imaging.ImageFormat]::Jpeg.Guid){'image/jpeg'}else{'invalid'})
    if($actualMime -ne $meta.mime -or $img.Width -ne [int]$meta.width -or $img.Height -ne [int]$meta.height){throw 'Wallpaper decoded format or dimensions mismatch'}
   }finally{$img.Dispose()}
   Move-Item -LiteralPath $temp -Destination $output -Force
  }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
 }
 & "$env:SystemRoot\System32\icacls.exe" $dir '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Failed to restrict wallpaper storage'}
 return $output
}
