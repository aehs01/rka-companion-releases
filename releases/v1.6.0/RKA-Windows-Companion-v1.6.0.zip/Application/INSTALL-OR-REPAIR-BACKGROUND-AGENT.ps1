# RKA v1.6.0 controlled maintenance launcher. Existing enrollment is never regenerated.
#Requires -Version 5.1
$ErrorActionPreference='Stop'
try{
 $p=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $launched=Start-Process -FilePath $ps -Verb RunAs -Wait -PassThru -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"')
  exit $launched.ExitCode
 }
 & (Join-Path $PSScriptRoot 'Remote-Setup.ps1') -Action Upgrade
 if(-not $?){throw 'Upgrade failed. See protected logs.'}
 Write-Host 'Background tasks repaired. Confirm Lovable reports a fresh v1.6.0 authenticated agent poll.' -ForegroundColor Green
 Read-Host 'Press Enter to close'
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;Read-Host 'Press Enter';exit 1}
