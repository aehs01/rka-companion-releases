# RKA remote command agent v1.9.1. SYSTEM task, separate from existing heartbeat.
# Polls ONLY typed commands accepted by the server. No arbitrary script, path, URL or payload.
# The installer explicitly opts in to unattended modifications; destructive operations off by default.
#Requires -Version 5.1
$ErrorActionPreference='Stop'
$agentVersion='1.9.1'
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
$configPath=Join-Path $root 'remote-config.json'
$heartbeatPath=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat\configuration.json'
$log=Join-Path $root 'remote.log'
$processed=Join-Path $root 'seen-command-ids'
# Set when Lovable rejects the 1.1 poll (it doesn't know the new fields yet).
$legacyMark=Join-Path $root 'lovable-legacy.json'
$clientStatusFile=Join-Path $env:ProgramData 'RKA-Client\status\status.json'
$staffCallFile=Join-Path $env:ProgramData 'RKA-Client\status\staff-call.json'
$staffCallSent=Join-Path $root 'staff-call-sent.txt'
# Lovable lists what else it accepts in its poll reply (features: ['staff_call']).
$featuresFile=Join-Path $root 'lovable-features.json'
$networkSent=Join-Path $root 'network-sent.json'
$scheduleFile=Join-Path $root 'power-schedule.json'
$scheduleDone=Join-Path $root 'power-schedule-done.txt'
$clientCatalogFile=Join-Path $env:ProgramData 'RKA-Client\status\lan-catalog.json'
$catalogSent=Join-Path $root 'lan-catalog-sent.txt'
$clientLauncherFile=Join-Path $env:ProgramData 'RKA-Client\status\launcher-games.json'
$launcherSent=Join-Path $root 'launcher-games-sent.txt'
$endpoint='https://zallpwnkizoxxxkufbfq.supabase.co/functions/v1/rka-pc-agent-command'
$mutex=$null;$mutexHeld=$false
. (Join-Path $PSScriptRoot 'Remote-Operations.ps1')
# 1.9.1: the admin guest (an administrator staff chose as the guest) and its lockdown copy.
$rkaGa=Join-Path $PSScriptRoot 'Guest-Accounts.ps1';if(Test-Path -LiteralPath $rkaGa){. $rkaGa}else{function Test-RkaAdminGuest{return $false};function Get-RkaAdminGuests{return @()};function Save-RkaPolicySnapshot{};function Clear-RkaPolicySnapshot{};function Repair-RkaPolicySnapshot{return 0};function Find-RkaGuestToAdopt{return $null};function Add-RkaAdminGuest{};function Test-RkaRunningAsAdminGuest{return $false}}
function Get-Capabilities($conf,[bool]$legacy=$false){
 $all=@('policy_status')
 if([bool]$conf.allowChanges){
  $all+=@('shutdown_pc','power_delay','set_guest_restriction','set_chrome_autolaunch','set_browser_allowlist','send_announcement','apply_wallpaper','restore_wallpaper')
  if([bool]$conf.allowUsb){$all+='set_usb_storage'}
  # 1.1 capabilities. Lovable refuses a poll that lists a capability it doesn't know,
  # so they are only sent once Lovable accepts them (see Poll-Once).
  if(-not $legacy){
   $all+='set_lan_firewall'
   if(Test-Path -LiteralPath (Client-Inbox) -PathType Container){$all+=@('reset_session','set_staff_mode')}
   # 1.7 (Control Room 0.3): only once Lovable lists lan_games, so an older
   # Lovable never sees capabilities it would refuse.
   if('lan_games' -in @(Lovable-Features)){
    $all+=@('lockdown_items_v2','set_windows_update','set_client_shell')
    if((Test-Path -LiteralPath (Client-Inbox) -PathType Container) -and (Client-Version) -ge [version]'1.8.0'){$all+=@('install_lan_game','remove_lan_game','set_session_timer')}
   }
  }
 }
 return @($all)
}
function Lovable-Legacy {
 if(-not(Test-Path -LiteralPath $legacyMark)){return $false}
 try{$m=Get-Content -LiteralPath $legacyMark -Raw -Encoding UTF8|ConvertFrom-Json;return (([DateTime]::UtcNow-([DateTime]::Parse([string]$m.since)).ToUniversalTime()).TotalHours -lt 1)}catch{return $false}
}
# A customer pressed Call staff in RKA Client (written as the guest, so checked
# and sent once). Calls older than 10 minutes are dropped.
# 1.8.1: -WithReason adds why the customer called and who's signed in (RKA
# Client 1.9.1's schema 2), only when Lovable lists 'staff_call_reason'.
function Get-StaffCall([switch]$WithReason) {
 try{
  if(-not(Test-Path -LiteralPath $staffCallFile)){return $null}
  if((Get-Item -LiteralPath $staffCallFile).Length -gt 1024){return $null}
  $c=Get-Content -LiteralPath $staffCallFile -Raw -Encoding UTF8|ConvertFrom-Json
  $id=([string]$c.id).ToLowerInvariant()
  if($id -cnotmatch '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'){return $null}
  $at=[datetimeoffset]::MinValue
  if(-not [datetimeoffset]::TryParse([string]$c.requestedUtc,[ref]$at) -or ([datetimeoffset]::UtcNow-$at).TotalMinutes -gt 10 -or $at -gt [datetimeoffset]::UtcNow.AddMinutes(1)){return $null}
  if((Test-Path -LiteralPath $staffCallSent) -and ([string](Get-Content -LiteralPath $staffCallSent -Raw)).Trim() -ceq $id){return $null}
  $call=@{id=$id;requested_at=$at.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')}
  if($WithReason){
   $why=([string]$c.reason).ToLowerInvariant()
   if($why -cin @('game','controls','account','question','other')){$call.reason=$why}
   $who=(([string]$c.lanUser) -replace '[^\x20-\x7E]','' -replace '[<>"''`\\]','').Trim()
   if($who.Length -gt 60){$who=$who.Substring(0,60).Trim()}
   if($who.Length -gt 0){$call.lan_user=$who}
  }
  return $call
 }catch{return $null}
}
function Lovable-Features {
 try{if(Test-Path -LiteralPath $featuresFile){return @((Get-Content -LiteralPath $featuresFile -Raw -Encoding UTF8|ConvertFrom-Json).features|ForEach-Object {[string]$_})}}catch{}
 return @()
}
# Tells RKA Client what Lovable can take, so Call staff only shows when someone
# will actually get the call. SYSTEM writes it; guests can only read the inbox.
function Save-LovableFeatures([string[]]$features){
 @{features=@($features);savedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $featuresFile -Encoding UTF8
 $inbox=Client-Inbox
 if(Test-Path -LiteralPath $inbox -PathType Container){
  # 1.2: also the agent's version, which the guest can't read from the agent's own folder.
  $body=@{schema=1;kind='features';staffCalls=('staff_call' -in $features);agentVersion=$agentVersion;updatedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Compress
  $tmp=Join-Path $inbox 'features.json.tmp'
  [IO.File]::WriteAllText($tmp,$body,(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination (Join-Path $inbox 'features.json') -Force
 }
}
function Is-BadRequest($err){try{return ([int]$err.Exception.Response.StatusCode -eq 400)}catch{return $false}}
# 1.5: Control Room's health report (RKA Client 1.7), sent only when Lovable's
# poll reply lists client_health. Every field is re-checked against a fixed
# shape; anything odd is left out. Launcher ids and counts only.
function Get-ClientHealth($h){
 if(-not $h){return $null}
 $out=@{}
 $drives=@()
 foreach($d in @($h.drives|Select-Object -First 4)){
  try{
   $name=[string]$d.name;$free=[double]$d.freeGb;$total=[double]$d.totalGb
   if($name -cmatch '^[A-Z]$' -and $free -ge 0 -and $total -ge 0 -and $free -le 1000000 -and $total -le 1000000){$drives+=@{name=$name;freeGb=[math]::Round($free,1);totalGb=[math]::Round($total,1)}}
  }catch{}
 }
 if($drives.Count){$out.drives=@($drives)}
 if($h.intranet -and $h.intranet.ok -is [bool]){$out.intranet=@{ok=[bool]$h.intranet.ok}}
 if($h.lastReset -and $h.lastReset.ok -is [bool]){
  $out.lastReset=@{ok=[bool]$h.lastReset.ok;failed=@($h.lastReset.failed|ForEach-Object {[string]$_}|Where-Object {$_ -cmatch '^[a-z0-9-]{1,24}$'}|Select-Object -Unique -First 16)}
 }
 $signed=@()
 foreach($e in @($h.signedIn|Select-Object -First 16)){
  $id=[string]$e.id;$state=[string]$e.state;$account=[string]$e.account
  if($id -cmatch '^[a-z0-9-]{1,24}$' -and $state -cin @('signedIn','saved')){
   $item=@{id=$id;state=$state};if($account -cin @('arcade','own')){$item.account=$account};$signed+=$item
  }
 }
 $out.signedIn=@($signed)
 if($h.errors){
  try{
   $count=[int]$h.errors.lastHour
   if($count -ge 0 -and $count -le 100000){
    $last=$null;if($h.errors.last){$last=(([string]$h.errors.last) -replace '[^\x20-\x7E]','').Trim();if($last.Length -gt 120){$last=$last.Substring(0,120)};if(-not $last){$last=$null}}
    $out.errors=@{lastHour=$count;last=$last}
   }
  }catch{}
 }
 try{$up=[int64]$h.uptimeMin;if($up -ge 0 -and $up -le 10000000){$out.uptimeMin=[int]$up}}catch{}
 if($h.games){try{$lan=[int]$h.games.lan;$launcher=[int]$h.games.launcher;if($lan -ge 0 -and $launcher -ge 0 -and $lan -le 100000 -and $launcher -le 100000){$out.games=@{lan=$lan;launcher=$launcher}}}catch{}}
 if($h.steamArcade -is [bool]){$out.steamArcade=[bool]$h.steamArcade}
 # 1.7: installed LAN games by catalog id (RKA Client 1.8).
 if($h.lanGames){$ids=@($h.lanGames|ForEach-Object {[string]$_}|Where-Object {$_ -cmatch '^[a-z0-9][a-z0-9-]{0,63}$'}|Select-Object -Unique -First 200);if($ids.Count){$out.lanGames=$ids}}
 return $out
}

# RKA Client writes this file as the guest, so every value is checked against a
# fixed shape and anything unexpected drops the whole report. It is never acted on.
# 1.6 (Control Room 0.2): this PC's network card addresses, so the Control Room
# app can wake it from off. Physical adapters only, unicast, at most 8; wired
# first. Sent when the list changes or every 6 hours, only when Lovable's poll
# reply lists network_macs.
function Get-NetworkMacs {
 $list=@()
 try{
  $list=@(Get-NetAdapter -Physical -ErrorAction Stop|Sort-Object @{e={if($_.Status -eq 'Up'){0}else{1}}},@{e={if($_.MediaType -match '802\.3'){0}else{1}}},Name|ForEach-Object {([string]$_.MacAddress).ToUpperInvariant().Replace(':','-')})
 }catch{return @()}
 return @($list|Where-Object {$_ -cmatch '^[0-9A-F]{2}(-[0-9A-F]{2}){5}$' -and $_ -ne 'FF-FF-FF-FF-FF-FF' -and $_ -ne '00-00-00-00-00-00' -and (([Convert]::ToInt32($_.Substring(0,2),16) -band 1) -eq 0)}|Select-Object -Unique|Select-Object -First 8)
}
function Get-NetworkReport {
 $macs=@(Get-NetworkMacs)
 if(-not $macs.Count){return $null}
 $sig=($macs -join ',')
 try{
  if(Test-Path -LiteralPath $networkSent){
   $last=Get-Content -LiteralPath $networkSent -Raw -Encoding UTF8|ConvertFrom-Json
   $at=[datetime]::MinValue
   if([string]$last.sig -ceq $sig -and [datetime]::TryParse([string]$last.sentUtc,[ref]$at) -and ([DateTime]::UtcNow-$at.ToUniversalTime()).TotalHours -lt 6){return $null}
  }
 }catch{}
 return @{macs=$macs}
}
function Get-ClientReport {
 try{
  if(-not(Test-Path -LiteralPath $clientStatusFile)){return $null}
  # 1.7: up to 16 KB, for the installed LAN games list.
  if((Get-Item -LiteralPath $clientStatusFile).Length -gt 16384){return $null}
  $s=Get-Content -LiteralPath $clientStatusFile -Raw -Encoding UTF8|ConvertFrom-Json
  $updated=[datetimeoffset]::MinValue
  if(([string]$s.version) -notmatch '^\d{1,3}\.\d{1,3}\.\d{1,3}$' -or ([string]$s.mode) -notin @('locked','staff','open') -or
     -not [datetimeoffset]::TryParse([string]$s.updatedUtc,[ref]$updated)){return $null}
  $reset=$null;$r=[datetimeoffset]::MinValue
  if($s.lastResetUtc -and [datetimeoffset]::TryParse([string]$s.lastResetUtc,[ref]$r)){$reset=$r.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')}
  $launchers=@($s.launchers|ForEach-Object {[string]$_}|Where-Object {$_ -cmatch '^[a-z0-9-]{1,24}$'}|Select-Object -Unique -First 16)
  $report=@{version=[string]$s.version;mode=[string]$s.mode;customer_active=[bool]$s.customerActive;last_reset_at=$reset;launchers_installed=$launchers;updated_at=$updated.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')}
  $features=@(Lovable-Features)
  if('client_health' -in $features){try{$health=Get-ClientHealth $s.health;if($health){if('lan_games' -notin $features){$health.Remove('lanGames')};$report.health=$health}}catch{}}
  # 1.7: who is signed in to the intranet (RKA Client 1.8), once Lovable asks for it.
  if('client_member' -in $features -and $s.member){
   $mid=[string]$s.member.id;$lu=[string]$s.member.lanUser
   $report.member=@{id=$(if($mid -match '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'){$mid.ToLowerInvariant()}else{$null});lan_user=$(if($lu -and $lu.Length -le 60 -and $lu -notmatch '[<>\x00-\x1f]'){$lu}else{$null})}
  }
  return $report
 }catch{return $null}
}

$secret=$null;$bytes=$null
function Write-Safe([string]$msg){
 try{if(Test-Path -LiteralPath $root){Add-Content -LiteralPath $log -Value ("$(Get-Date -Format o) "+($msg -replace 'rka_pc_[A-Za-z0-9_-]+','[REDACTED]')) -Encoding UTF8}}catch{}
}
function Is-ValidSid([string]$sid){return ($sid -match '^S-1-5-21-[0-9]{6,12}-[0-9]{6,12}-[0-9]{6,12}-[0-9]{3,6}$' -and $sid -notmatch '-(500|501|503|504)$')}
function StandardAccounts {
 $adminSids=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
 # 1.9.1: plus an administrator staff chose as this PC's admin guest.
 $adminGuests=@(Get-RkaAdminGuests|ForEach-Object {$_.sid})
 $accounts=@()
 foreach($a in @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop)){
  if($a.Disabled -or $a.Lockout -or (-not(Is-ValidSid ([string]$a.SID))) -or ($adminSids -contains $a.SID -and $adminGuests -notcontains [string]$a.SID)){continue}
  $accounts+=@{sid=[string]$a.SID;account_name=([string]$a.Name).Substring(0,[Math]::Min(64,([string]$a.Name).Length))}
 }
 return $accounts
}
function Verify-Target([string]$sid,[string]$profilePath){
 if(-not(Is-ValidSid $sid)){throw 'Remote guest SID does not satisfy local-account requirements.'}
 $match=@(StandardAccounts | Where-Object {$_.sid -ceq $sid})
 if($match.Count -ne 1){throw 'Guest SID no longer identifies one enabled local standard user.'}
 if(-not(Test-Path -LiteralPath $profilePath)){throw 'No administrator-approved remote policy profile; sync it locally.'}
 $profile=Get-Content -LiteralPath $profilePath -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$profile.account -cne [string]$match[0].account_name){throw 'Policy profile account does not match target SID.'}
 if(-not ($profile.blockSettings -or $profile.blockCmd -or $profile.blockRegistry -or $profile.blockTaskManager -or $profile.restrictEdge)){throw 'No locally approved supported policy actions configured.'}
 return $profile
}
function Post-Server([hashtable]$body){
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 return Invoke-RestMethod -Method POST -Uri $endpoint -Headers @{'X-RKA-Device-Token'=$secret} -Body ($body|ConvertTo-Json -Compress -Depth 8) -ContentType 'application/json' -TimeoutSec 12
}
function Simple-Diagnostics {
 $os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
 $disk=Get-CimInstance Win32_LogicalDisk -Filter 'DeviceID="C:"' -ErrorAction SilentlyContinue
 $hb=Get-ScheduledTask -TaskName 'RKA-Lockdown-ReadOnlyHeartbeat' -ErrorAction SilentlyContinue
 $guestCount=-1
 try{$guestCount=@(StandardAccounts).Count}catch{}
 return @{agent_version=$agentVersion;computer=$env:COMPUTERNAME;os=$os.Caption;uptime_minutes=$(if($os){[int]((Get-Date)-$os.LastBootUpTime).TotalMinutes}else{$null});free_gb=$(if($disk){[math]::Round($disk.FreeSpace/1GB,1)}else{$null});guest_count=$guestCount;heartbeat_task=$(if($hb){[string]$hb.State}else{'missing'});testedAt=(Get-Date -Format 'o')}
}
function Worker([string]$operation,[string]$targetSid,[string]$profile,[string]$item='',[string]$state=''){
 $policy=Join-Path $root 'PolicyWorker.ps1'
 if(-not(Test-Path -LiteralPath $policy)){throw 'Protected policy worker missing.'}
 $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $args='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$policy+'" -Operation '+$operation
 if($targetSid){$args+=' -TargetSid "'+$targetSid+'"'}
 if($profile){$args+=' -ProfilePath "'+$profile+'"'}
 # 1.7: single items and Windows Update, as the Companion window runs them.
 if($item){if($item -cnotmatch '^[a-z]{2,12}$'){throw 'Invalid item'};$args+=' -Item '+$item}
 if($state){if($state -notin @('Block','Allow')){throw 'Invalid state'};$args+=' -State '+$state}
 $proc=Start-Process -FilePath $exe -ArgumentList $args -PassThru -Wait -WindowStyle Hidden
 if($proc.ExitCode -ne 0){throw ('Policy worker returned '+$proc.ExitCode+'; consult local Recovery\worker.log.')}
}
function Execute-Typed($cmd,$conf){
 $kind=[string]$cmd.kind
 $sid=[string]$cmd.target_sid
 $profilePath=Join-Path $root 'approved-policy.json'
 $changes=[bool]$conf.allowChanges
 if($kind -ne 'refresh_diagnostics' -and -not $changes){throw 'Remote changes disabled by local administrator'}
 switch($kind){
  'refresh_diagnostics' {return @{ok=$true;result=(Simple-Diagnostics)}}
  {$_ -in @('restart_pc','shutdown_pc')} {
   $delay=90
   if($null -ne $cmd.delay_seconds){$delay=[int]$cmd.delay_seconds}
   if($delay -notin @(0,30,90,300)){throw 'Unrecognized power delay'}
   if($kind -eq 'shutdown_pc'){$flag='/s'}else{$flag='/r'}
   $exe=Join-Path $env:SystemRoot 'System32\shutdown.exe'
   $args=$flag+' /t '+$delay+' /f /c "RKA authorized remote request - save your work"'
   $p=Start-Process -FilePath $exe -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
   if($p.ExitCode -ne 0){throw 'Windows refused the requested power action'}
   return @{ok=$true;result=@{scheduled_for=[DateTime]::UtcNow.AddSeconds($delay).ToString('yyyy-MM-ddTHH:mm:ss.fffZ');action=$kind;state='scheduled'}}
  }
  'apply_guest_policy' {
   $profile=Verify-Target $sid $profilePath
   # 1.2: the worker blocks each chosen item and allows the rest; no snapshots.
   Worker 'Persistent' $sid $profilePath
   return @{ok=$true;result=@{guest=$profile.account;policy='applied';enforcement='not_verified'}}
  }
  'restore_guest_policy' {
   [void](Require-Guest $sid)
   # 1.2: Lovable's Restore is Unlock everything for that guest.
   Worker 'UnlockAll' $sid ''
   return @{ok=$true;result=@{policy='restored';enforcement='not_verified'}}
  }
  'set_guest_restriction' {
   # 1.7: the four Companion-only items go through the same policy worker as the Companion window.
   $r0=[string]$cmd.restriction
   if($script:RkaV2Items.Contains($r0)){
    if($null -eq $cmd.enabled){throw 'Invalid typed restriction'}
    [void](Require-Guest $sid)
    Worker 'Set' $sid '' $script:RkaV2Items[$r0] $(if([bool]$cmd.enabled){'Block'}else{'Allow'})
    return @{ok=$true;result=@{restriction=$r0;registry=$(if([bool]$cmd.enabled){'match'}else{'not_configured'});scope='guest';enforcement='not_verified';guest_sid=$sid}}
   }
   if($null -eq $cmd.enabled -or ([string]$cmd.restriction) -notin @('chrome_web','edge_web','control_panel','regedit','command_prompt','task_manager')){throw 'Invalid typed restriction'}
   $r=Set-GuestRestriction $sid ([string]$cmd.restriction) ([bool]$cmd.enabled)
   return @{ok=$true;result=$r}
  }
  'set_browser_allowlist' {
   if($null -eq $cmd.allowlist -or $cmd.allowlist.preserve_intranet -ne $true){throw 'Intranet preservation is mandatory'}
   $hosts=@($cmd.allowlist.hosts|ForEach-Object {[string]$_})
   $r=Set-BrowserAllowlist $sid ([string]$cmd.allowlist.mode) $hosts
   # 1.7: one approved-sites list for Chrome, Edge and RKA Client 1.8.
   try{if(Test-Path -LiteralPath (Client-Inbox) -PathType Container){[void](Send-ClientMessage 'sites' '' ([string]$cmd.id) 1440 @{hosts=@($r.hosts_effective|ForEach-Object {[string]$_})})}}catch{Write-Safe 'Could not pass the approved sites to RKA Client.'}
   return @{ok=$true;result=$r}
  }
  'set_chrome_autolaunch' {
   if($null -eq $cmd.enabled){throw 'Missing typed Chrome auto-launch value'}
   $r=Set-ChromeAutolaunch $sid ([bool]$cmd.enabled)
   return @{ok=$true;result=$r}
  }
  'set_usb_storage' {
   if(-not [bool]$conf.allowUsb){throw 'System-wide USB storage remote control not locally authorized'}
   if([string]$cmd.restriction -cne 'usb_storage' -or $null -eq $cmd.enabled){throw 'Invalid typed USB request'}
   if([bool]$cmd.enabled){Run-LocalScript 'USB-Storage.ps1' @('-Action','Enable')}
   else{Run-LocalScript 'USB-Storage.ps1' @('-Action','Restore')}
   return @{ok=$true;result=@{usb_storage=$(if($cmd.enabled){'block_requested'}else{'restore_requested'});scope='system';enforcement='not_verified'}}
  }
  'send_announcement' {
   # Announcements have no target SID. Only dispatch when exactly one standard guest is configured.
   $guests=@(StandardAccounts)
   if($guests.Count -ne 1){throw 'A single standard guest account is required for announcement delivery'}
   $r=Announce-Guest ([string]$guests[0].sid) ([string]$cmd.message) ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'reset_session' {
   # Same as RKA Client's walk-away reset: games close, the customer is signed out, settings go back.
   $r=Reset-ClientSession ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'set_staff_mode' {
   # Unlocks or locks RKA Client's staff mode; staff mode locks itself after 5 idle minutes.
   if($null -eq $cmd.enabled){throw 'Missing typed staff mode value'}
   $r=Set-ClientStaffMode ([bool]$cmd.enabled) ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'set_lan_firewall' {
   if($null -eq $cmd.enabled){throw 'Missing typed LAN play value'}
   Run-LocalScript 'LAN-Firewall.ps1' @('-Action',$(if([bool]$cmd.enabled){'Enable'}else{'Disable'}))
   return @{ok=$true;result=@{lan_play=$(if($cmd.enabled){'on'}else{'off'});scope='system';enforcement='not_verified'}}
  }
  'apply_wallpaper' {
   [void](Require-Guest $sid)
   $image=Acquire-Wallpaper $cmd ([string]$conf.deviceName)
   $r=Apply-GuestWallpaper $sid $image ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'restore_wallpaper' {
   $r=Restore-GuestWallpaper $sid
   return @{ok=$true;result=$r}
  }
  'set_windows_update' {
   if($null -eq $cmd.enabled){throw 'Missing typed Windows Update value'}
   Worker 'WindowsUpdate' '' '' '' $(if([bool]$cmd.enabled){'Block'}else{'Allow'})
   return @{ok=$true;result=@{windows_update=$(if([bool]$cmd.enabled){'after_closing_only'}else{'windows_default'});scope='system';enforcement='not_verified'}}
  }
  'set_client_shell' {
   if($null -eq $cmd.enabled){throw 'Missing typed RKA Client value'}
   $g=Require-Guest $sid
   return @{ok=$true;result=(Set-ClientShell $g ([bool]$cmd.enabled))}
  }
  {$_ -in @('install_lan_game','remove_lan_game')} {
   $ref=[string]$cmd.game_ref
   if($ref -cnotmatch '^[a-z0-9][a-z0-9-]{0,63}$'){throw 'Invalid LAN game'}
   if(-not(Client-Running)){throw 'RKA Client is not running on this PC'}
   return @{ok=$true;result=(Send-ClientMessage $kind '' ([string]$cmd.id) 60 @{game=$ref})}
  }
  'set_session_timer' {
   $m=-1;try{$m=[int]$cmd.session_minutes}catch{}
   if($m -lt 0 -or $m -gt 480){throw 'Invalid session length'}
   if(-not(Client-Running)){throw 'RKA Client is not running on this PC'}
   return @{ok=$true;result=(Send-ClientMessage 'session_timer' '' ([string]$cmd.id) 5 @{minutes=$m})}
  }
  default {throw 'Unsupported typed remote action refused'}
 }
}
function Check-Expired($cmd){
 $expiry=[datetimeoffset]::MinValue
 if(-not [datetimeoffset]::TryParse([string]$cmd.expires_at,[ref]$expiry)){return $true}
 return ([datetimeoffset]::UtcNow -ge $expiry)
}
# 1.7 (Control Room 0.3): the power schedule from Lovable. A set number of
# minutes after closing, each PC shows a 5-minute notice and shuts down,
# unless staff have it unlocked (it tries again each minute for half an hour).
# The Control Room app on the office PC wakes the PCs before opening.
function Save-PowerSchedule($schedule){
 try{
  if($null -eq $schedule){if(Test-Path -LiteralPath $scheduleFile){Remove-Item -LiteralPath $scheduleFile -Force};return}
  ($schedule|ConvertTo-Json -Depth 5 -Compress)|Set-Content -LiteralPath $scheduleFile -Encoding UTF8
 }catch{Write-Safe 'Could not save the power schedule.'}
}
function Check-PowerSchedule($conf){
 try{
  if(-not [bool]$conf.allowChanges -or -not(Test-Path -LiteralPath $scheduleFile)){return}
  $p=Get-Content -LiteralPath $scheduleFile -Raw -Encoding UTF8|ConvertFrom-Json
  if($p.enabled -ne $true){return}
  $after=15;try{$after=[int]$p.shutdown_after_close_min}catch{};if($after -lt 0 -or $after -gt 240){$after=15}
  $now=Get-Date
  foreach($back in @(0,1)){
   $day=$now.Date.AddDays(-$back)
   $key=@('sun','mon','tue','wed','thu','fri','sat')[[int]$day.DayOfWeek]
   $d=$p.days.$key
   if(-not $d -or -not $d.open -or -not $d.close){continue}
   $open=$day.Add([TimeSpan]::Parse([string]$d.open));$close=$day.Add([TimeSpan]::Parse([string]$d.close))
   if($close -le $open){$close=$close.AddDays(1)}
   $at=$close.AddMinutes($after)
   if($now -lt $at -or $now -ge $at.AddMinutes(30)){continue}
   $stamp=$at.ToString('yyyy-MM-ddTHH:mm')
   if((Test-Path -LiteralPath $scheduleDone) -and ([string](Get-Content -LiteralPath $scheduleDone -Raw)).Trim() -eq $stamp){return}
   if((Client-Mode) -eq 'staff'){return}
   try{[void](Send-ClientMessage 'announcement' 'Closing time: this PC shuts down in 5 minutes.' ([guid]::NewGuid().ToString()) 6)}catch{}
   $exe=Join-Path $env:SystemRoot 'System32\shutdown.exe'
   $proc=Start-Process -FilePath $exe -ArgumentList '/s /t 300 /c "Retro Knights Arcade closing time"' -Wait -PassThru -WindowStyle Hidden
   if($proc.ExitCode -eq 0){Set-Content -LiteralPath $scheduleDone -Value $stamp -Encoding ASCII;Write-Safe ('Closing time: shutdown in 5 minutes ('+$stamp+').')}
   return
  }
 }catch{Write-Safe 'Power schedule check failed.'}
}
# 1.7 (Control Room 0.3): the intranet's LAN games (ids and titles) as RKA
# Client 1.8 keeps them, sent to Lovable when they change or once a day, so
# Control Room can offer them for install. Only once Lovable lists lan_games.
function Send-LanCatalog($conf){
 try{
  if('lan_games' -notin @(Lovable-Features) -or -not(Test-Path -LiteralPath $clientCatalogFile)){return}
  if((Get-Item -LiteralPath $clientCatalogFile).Length -gt 65536){return}
  $c=Get-Content -LiteralPath $clientCatalogFile -Raw -Encoding UTF8|ConvertFrom-Json
  $games=@($c.games|Where-Object {([string]$_.id) -cmatch '^[a-z0-9][a-z0-9-]{0,63}$' -and ([string]$_.title).Length -ge 1 -and ([string]$_.title).Length -le 120 -and ([string]$_.title) -notmatch '[<>\x00-\x1f]'}|Select-Object -First 400|ForEach-Object {@{id=[string]$_.id;title=[string]$_.title}})
  if(-not $games.Count){return}
  $text=(@($games|ForEach-Object {$_.id+'='+$_.title}) -join "`n")
  $sig=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($text))).Replace('-','')
  if(Test-Path -LiteralPath $catalogSent){
   $last=([string](Get-Content -LiteralPath $catalogSent -Raw)).Trim() -split '\|'
   $at=[datetime]::MinValue
   if($last[0] -eq $sig -and $last.Count -gt 1 -and [datetime]::TryParse($last[1],[ref]$at) -and ([DateTime]::UtcNow-$at.ToUniversalTime()).TotalHours -lt 24){return}
  }
  $r=Post-Server @{action='lan_catalog';device_id=[string]$conf.deviceName;games=@($games)}
  if($r.ok -eq $true){Set-Content -LiteralPath $catalogSent -Value ($sig+'|'+[DateTime]::UtcNow.ToString('o')) -Encoding ASCII;Write-Safe ('LAN games list sent: '+$games.Count)}
 }catch{Write-Safe 'Could not send the LAN games list.'}
}
# 1.8: the launcher games on this PC with their state (RKA Client 1.9's
# status\launcher-games.json), for Control Room's games view. Every field is
# re-checked; sent only when the list changes, or once a day, and only to a
# Lovable that asks for it.
function Send-LauncherGames($conf){
 try{
  if('launcher_games' -notin @(Lovable-Features) -or -not(Test-Path -LiteralPath $clientLauncherFile)){return}
  if((Get-Item -LiteralPath $clientLauncherFile).Length -gt 65536){return}
  $c=Get-Content -LiteralPath $clientLauncherFile -Raw -Encoding UTF8|ConvertFrom-Json
  $states=@('ok','update','updating','broken')
  $games=@($c.games|Where-Object {
    ([string]$_.l) -cmatch '^[a-z][a-z0-9]{1,15}$' -and ([string]$_.id) -cmatch '^[A-Za-z0-9][A-Za-z0-9._:\-]{0,79}$' -and
    ([string]$_.n).Length -ge 1 -and ([string]$_.n).Length -le 100 -and ([string]$_.n) -notmatch '[<>\x00-\x1f]' -and ([string]$_.s) -in $states
   }|Select-Object -First 300|ForEach-Object {@{launcher=[string]$_.l;id=[string]$_.id;name=[string]$_.n;state=[string]$_.s}})
  $text=(@($games|ForEach-Object {$_.launcher+':'+$_.id+'='+$_.state+'|'+$_.name}) -join "`n")
  $sig=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($text))).Replace('-','')
  if(Test-Path -LiteralPath $launcherSent){
   $last=([string](Get-Content -LiteralPath $launcherSent -Raw)).Trim() -split '\|'
   $at=[datetime]::MinValue
   if($last[0] -eq $sig -and $last.Count -gt 1 -and [datetime]::TryParse($last[1],[ref]$at) -and ([DateTime]::UtcNow-$at.ToUniversalTime()).TotalHours -lt 24){return}
  }
  $r=Post-Server @{action='launcher_games';device_id=[string]$conf.deviceName;games=@($games)}
  if($r.ok -eq $true){Set-Content -LiteralPath $launcherSent -Value ($sig+'|'+[DateTime]::UtcNow.ToString('o')) -Encoding ASCII;Write-Safe ('Launcher games sent: '+$games.Count)}
 }catch{Write-Safe 'Could not send the launcher games.'}
}
function Poll-Once($conf){
 $legacy=Lovable-Legacy
 $body=@{action='poll';device_id=[string]$conf.deviceName;agent_version=$agentVersion;capabilities=@(Get-Capabilities $conf $legacy)}
 $call=$null
 if(-not $legacy){
  $client=Get-ClientReport;if($client){$body.client=$client}
  $features=@(Lovable-Features)
  if('staff_call' -in $features){$call=Get-StaffCall -WithReason:('staff_call_reason' -in $features);if($call){$body.staff_call=$call}}
  if('network_macs' -in @(Lovable-Features)){try{$net=Get-NetworkReport;if($net){$body.network=$net}}catch{}}
 }
 try{$reply=Post-Server $body}
 catch{
  if($legacy -or -not(Is-BadRequest $_)){throw}
  # This Lovable doesn't know the 1.1 fields yet. Use the 1.0 poll and try again in an hour.
  @{since=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $legacyMark -Encoding UTF8
  Write-Safe 'Lovable refused the 1.1 poll; using the 1.0 poll for an hour.'
  $legacy=$true
  $reply=Post-Server @{action='poll';device_id=[string]$conf.deviceName;agent_version=$agentVersion;capabilities=@(Get-Capabilities $conf $true)}
 }
 if($reply.ok -ne $true){throw 'Server did not accept device command poll.'}
 # 1.7: the power schedule rides on the reply when it's on; no schedule means none.
 Save-PowerSchedule $reply.power_schedule
 Check-PowerSchedule $conf
 Send-LanCatalog $conf
 Send-LauncherGames $conf
 if($call -and $body.ContainsKey('staff_call')){Set-Content -LiteralPath $staffCallSent -Value $call.id -Encoding ASCII;Write-Safe 'Staff call sent to Lovable.'}
 if($body.ContainsKey('network')){try{@{sig=(@($body.network.macs) -join ',');sentUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $networkSent -Encoding UTF8}catch{}}
 try{Save-LovableFeatures @($reply.features|Where-Object {$_ -is [string] -and $_ -cmatch '^[a-z_]{1,32}$'}|Select-Object -First 16)}catch{Write-Safe 'Could not save Lovable features.'}
 # Only a successful authenticated response qualifies this installed agent as healthy.
 # The heartbeat reads this protected status, NOT an installer-controlled version marker.
 $health=@{version=$agentVersion;confirmedUtc=[DateTime]::UtcNow.ToString('o');capabilities=@(Get-Capabilities $conf $legacy);lovable11=(-not $legacy)}
 $healthTmp=Join-Path $root ('agent-health-'+[guid]::NewGuid().ToString('N')+'.tmp')
 $healthDest=Join-Path $root 'agent-health.json'
 try{
  $health|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $healthTmp -Encoding UTF8 -NoNewline
  Move-Item -LiteralPath $healthTmp -Destination $healthDest -Force
 }finally{if(Test-Path -LiteralPath $healthTmp){Remove-Item -LiteralPath $healthTmp -Force -ErrorAction SilentlyContinue}}
 $cmd=$reply.command
 if($null -eq $cmd){return}
 if([string]$cmd.id -notmatch '^[0-9a-fA-F-]{36}$' -or [string]$cmd.nonce -notmatch '^[A-Za-z0-9_-]{32,64}$'){throw 'Invalid typed command envelope.'}
 $id=[string]$cmd.id
 $marker=Join-Path $processed ($id+'.json')
 if(Test-Path -LiteralPath $marker){
  # Never rerun a possibly destructive command following process crash or lost ack.
  $previous=Get-Content -LiteralPath $marker -Raw -Encoding UTF8|ConvertFrom-Json
  if($previous.status -eq 'complete'){
   try{[void](Post-Server @{action='ack';device_id=[string]$conf.deviceName;command_id=$id;nonce=[string]$cmd.nonce;status=[string]$previous.ackStatus;result=$previous.result;error=[string]$previous.error})}catch{}
  }else{
   try{[void](Post-Server @{action='ack';device_id=[string]$conf.deviceName;command_id=$id;nonce=[string]$cmd.nonce;status='failed';error='An earlier agent run was interrupted; command was not repeated.'})}catch{}
  }
  return
 }
 $mark=@{id=$id;status='started';startedAt=(Get-Date -Format 'o')}
 $mark|ConvertTo-Json|Set-Content -LiteralPath $marker -Encoding UTF8
 $status='failed';$result=@{};$problem=''
 try{
  if(Check-Expired $cmd){throw 'Command expired before local execution.'}
  $executed=Execute-Typed $cmd $conf
  if($executed.ok -ne $true){throw 'Operation failed'}
  $status='succeeded';$result=$executed.result
  # 1.9.1: the admin guest's lockdown copy follows what staff just set.
  foreach($g in @(Get-RkaAdminGuests)){try{Save-RkaPolicySnapshot $g.sid}catch{Write-Safe 'Could not update the admin guest lockdown copy.'}}
 }catch{$problem=($_.Exception.Message -replace '[\r\n]+',' ');if($problem.Length -gt 250){$problem=$problem.Substring(0,250)}}
 $mark.status='complete';$mark.ackStatus=$status;$mark.kind=[string]$cmd.kind;$mark.result=$result;$mark.error=$problem;$mark.finishedAt=(Get-Date -Format 'o')
 $mark|ConvertTo-Json|Set-Content -LiteralPath $marker -Encoding UTF8
 $body=@{action='ack';device_id=[string]$conf.deviceName;command_id=$id;nonce=[string]$cmd.nonce;status=$status;result=$result}
 if($status -eq 'failed'){$body.error=$problem}
 try{[void](Post-Server $body);Write-Safe ('Command '+[string]$cmd.kind+' settled '+$status+' id='+$id)}catch{Write-Safe ('Command acknowledgement unavailable for '+$id+'. Local execution not repeated.')}
}
function Register-Guests($conf){
 $accounts=@(StandardAccounts)
 $hash=(@($accounts|Sort-Object sid|ForEach-Object {$_.sid+':'+$_.account_name})-join '|')
 $cache=Join-Path $root 'guests-cache.json'
 $need=$true
 if(Test-Path -LiteralPath $cache){try{$old=Get-Content -LiteralPath $cache -Raw|ConvertFrom-Json;$need=($old.hash -cne $hash -or ([datetime]::UtcNow-[datetime]$old.lastSent).TotalMinutes -ge 30)}catch{}}
 if($need){
  $resp=Post-Server @{action='register_guests';device_id=[string]$conf.deviceName;guests=$accounts}
  if($resp.ok -ne $true){throw 'Guest account inventory not accepted.'}
  @{hash=$hash;lastSent=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $cache -Encoding UTF8
 }
}
try{
 $created=$false;$mutex=[System.Threading.Mutex]::new($true,'Global\RKA_Lovable_Remote_Agent_v1',[ref]$created)
 if(-not $created){exit 0};$mutexHeld=$true
 Add-Type -AssemblyName System.Security -ErrorAction Stop
 if(-not(Test-Path -LiteralPath $configPath)){throw 'Remote-control setup not installed.'}
 $conf=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8|ConvertFrom-Json
 $hb=Get-Content -LiteralPath $heartbeatPath -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$conf.deviceName -cne [string]$hb.deviceName -or [string]$conf.deviceName -cnotmatch '^[A-Z0-9-]{3,40}$'){throw 'Device enrollment changed; remote agent will not poll.'}
 if([string]$hb.endpoint -ne 'https://zallpwnkizoxxxkufbfq.supabase.co/functions/v1/rka-pc-heartbeat'){throw 'Unexpected heartbeat enrollment endpoint.'}
 $bytes=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String([string]$hb.tokenEncrypted),$null,[Security.Cryptography.DataProtectionScope]::LocalMachine)
 $secret=[Text.Encoding]::UTF8.GetString($bytes)
 if($secret -cnotmatch '^rka_pc_[A-Za-z0-9_-]{43}$'){throw 'Invalid enrollment token format.'}
 if(-not(Test-Path -LiteralPath $processed)){[void](New-Item -ItemType Directory -Path $processed -Force)}
 # 1.9.1: admin guests. A guest that became an administrator before 1.9.1 is
 # adopted only when it's the approved lockdown account AND Windows signs into
 # it automatically. Then any lockdown setting someone removed is put back.
 try{
  $adopt=Find-RkaGuestToAdopt (Join-Path $root 'approved-policy.json')
  if($adopt){Add-RkaAdminGuest $adopt.sid $adopt.name 'agent';Write-Safe ('Admin guest: '+$adopt.name+' (the approved lockdown account, signed in automatically) is now the admin guest.')}
 }catch{Write-Safe 'Admin guest check could not finish.'}
 foreach($g in @(Get-RkaAdminGuests)){
  try{$n=Repair-RkaPolicySnapshot $g.sid;if($n -gt 0){Write-Safe ('Admin guest: put back '+$n+' lockdown setting(s) removed on '+$g.name+'.')}}catch{Write-Safe 'Admin guest lockdown check could not finish.'}
 }
 try{Register-Guests $conf}catch{Write-Safe 'Guest registration failed; protected agent will retry.'}
 try{
  $guestAccounts=@(StandardAccounts)
  if($guestAccounts.Count -eq 1){
   # 1.7: the extra lockdown items only once Lovable lists lan_games (it refuses unknown keys).
   $items=@(Get-PolicyInventory ([string]$guestAccounts[0].sid) ('lan_games' -in @(Lovable-Features)))
   [void](Post-Server @{action='policy_status';device_id=[string]$conf.deviceName;agent_version=$agentVersion;observed_at=[DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ss.fffZ');target_sid=[string]$guestAccounts[0].sid;auto_logon_enabled=$null;items=$items})
  }
 }catch{Write-Safe 'Policy inventory could not be read or submitted; server status remains unknown.'}

 # Poll three times per minute. Service token never appears in logs or responses.
 for($attempt=0;$attempt -lt 3;$attempt++){
  try{Poll-Once $conf}catch{Write-Safe 'Remote poll could not complete; retry on next scheduled run.'}
  if($attempt -lt 2){Start-Sleep -Seconds 17}
 }
}catch{Write-Safe ('Agent stopped: '+($_.Exception.Message -replace 'rka_pc_[A-Za-z0-9_-]+','[REDACTED]'));exit 1}
finally{
 if($null -ne $bytes){[Array]::Clear($bytes,0,$bytes.Length)}
 $secret=$null
 if($mutexHeld -and $mutex){try{$mutex.ReleaseMutex()}catch{}}
 if($mutex){$mutex.Dispose()}
}
