# Admin-only one-time setup for independently scheduled, typed Lovable command polling.
# The existing DPAPI-encrypted heartbeat token remains in its protected SYSTEM/administrator directory.
#Requires -Version 5.1
param(
 [Parameter(Mandatory=$true)][ValidateSet('Install','EnableChanges','DisableChanges','SyncProfile','Remove','Status','Upgrade','EnableUsb','DisableUsb')][string]$Action,
 [string]$ProfilePath=''
)
$ErrorActionPreference='Stop'
$remoteRoot=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
$hbRoot=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'
$hbCfg=Join-Path $hbRoot 'configuration.json'
$hbClient=Join-Path $hbRoot 'Heartbeat-Client.ps1'
$confPath=Join-Path $remoteRoot 'remote-config.json'
$log=Join-Path $remoteRoot 'remote.log'
$taskName='RKA-Remote-Commands'
function Admin{
 $principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Local administrator elevation required.'}
}
function SecureFolder{
 if(-not(Test-Path -LiteralPath $remoteRoot)){[void](New-Item -ItemType Directory -Path $remoteRoot -Force)}
 & "$env:SystemRoot\System32\icacls.exe" $remoteRoot '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Unable to restrict remote agent files to SYSTEM and Administrators.'}
}
# Compile a minimal Win32 notification executable with the name/icon of the
# arcade. This avoids a system tray notification attributed to powershell.exe.
# Compile failure never breaks the working guest announcement fallback.
function Install-RkaNotificationHelper {
 $src=Join-Path $remoteRoot 'RKA-LAN-Notify.cs'
 $output=Join-Path $remoteRoot 'Retro Knights Arcade LAN.exe'
 $icon=Join-Path $remoteRoot 'rka.ico'
 $compilers=@((Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),(Join-Path $env:SystemRoot 'Microsoft.NET\Framework\v4.0.30319\csc.exe'))
 $compiler=$compilers|Where-Object {Test-Path -LiteralPath $_ -PathType Leaf}|Select-Object -First 1
 if(-not $compiler){WriteSafe 'No Windows .NET Framework C# compiler found; guest notifications will use PowerShell fallback.';return}
 try{
  $args='/nologo /target:winexe /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /win32icon:"'+$icon+'" /out:"'+$output+'" "'+$src+'"'
  $p=Start-Process -FilePath $compiler -ArgumentList $args -PassThru -Wait -WindowStyle Hidden -ErrorAction Stop
  if($p.ExitCode -ne 0 -or -not(Test-Path -LiteralPath $output -PathType Leaf)){throw 'C# compilation did not produce a notification helper'}
  # Make the fixed executable and its icon readable (not writable) to guests.
  foreach($f in @($output,$icon)){
   & "$env:SystemRoot\System32\icacls.exe" $f '/grant:r' '*S-1-5-32-545:R'|Out-Null
   if($LASTEXITCODE -ne 0){throw 'Cannot grant read-only guest access to notification helper'}
  }
  WriteSafe 'Branded Retro Knights Arcade LAN notification executable installed.'
 }catch{
  WriteSafe ('Branded notification helper unavailable; PowerShell guest fallback preserved: '+$_.Exception.Message)
  if(Test-Path -LiteralPath $output){Remove-Item -LiteralPath $output -Force -ErrorAction SilentlyContinue}
 }
}
function WriteSafe([string]$s){try{Add-Content -LiteralPath $log -Value "$(Get-Date -Format o) $s" -Encoding UTF8}catch{}}
function ReadCfg{if(-not(Test-Path -LiteralPath $confPath)){throw 'Enable remote diagnostics before using other remote controls.'};return Get-Content -LiteralPath $confPath -Raw -Encoding UTF8|ConvertFrom-Json}
function SaveCfg($c){$c|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $confPath -Encoding UTF8;SecureFolder}
function TaskXmlBackup([string]$task,[string]$folder){
 $existing=Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
 if($existing){
  $xml=Export-ScheduledTask -TaskName $task -ErrorAction Stop
  $xml|Set-Content -LiteralPath (Join-Path $folder ($task+'.xml')) -Encoding UTF8
 }
 return $null -ne $existing
}
function RestoreBackup([string]$folder,[string[]]$sources,[hashtable]$had){
 foreach($task in @('RKA-Remote-Commands','RKA-Lockdown-ReadOnlyHeartbeat')){
  $t=Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
  if($t){Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue}
 }
 foreach($pair in $sources){
  $parts=$pair -split '\|',2
  $name=$parts[0];$dest=$parts[1]
  $bak=Join-Path $folder ('files\'+$name)
  if(Test-Path -LiteralPath $bak){Copy-Item -LiteralPath $bak -Destination $dest -Force}
  elseif(-not $had[$name] -and (Test-Path -LiteralPath $dest)){Remove-Item -LiteralPath $dest -Force}
 }
 foreach($task in @('RKA-Lockdown-ReadOnlyHeartbeat','RKA-Remote-Commands')){
  $xml=Join-Path $folder ($task+'.xml')
  if(Test-Path -LiteralPath $xml){Register-ScheduledTask -TaskName $task -Xml (Get-Content -LiteralPath $xml -Raw -Encoding UTF8) -Force -ErrorAction Stop|Out-Null;Start-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue}
 }
}
function CopyProfile([string]$path){
 if(-not $path -or -not(Test-Path -LiteralPath $path)){throw 'Save a guest profile locally first, then Sync guest policy.'}
 $p=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]::IsNullOrEmpty([string]$p.account) -or [string]$p.account -notmatch '^[A-Za-z0-9_. -]{1,64}$'){throw 'Invalid local guest account in profile.'}
 $account=Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True'|Where-Object {$_.Name -ceq [string]$p.account -and (-not $_.Disabled)}|Select-Object -First 1
 if(-not $account -or $account.SID -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Approved profile must refer to an existing local guest account.'}
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop|Where-Object {$_.SID}|ForEach-Object {$_.SID.Value})
 if($admins -contains $account.SID){throw 'Refusing to store an administrator account as a remote policy target.'}
 $fields=@('account','blockSettings','blockCmd','blockRegistry','restrictEdge','urls','intranet')
 $safe=@{}
 foreach($field in $fields){$v=$p.$field;if($null -ne $v){$safe[$field]=$v}}
 $safe|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $remoteRoot 'approved-policy.json') -Encoding UTF8
 WriteSafe ('Approved guest profile staged for '+[string]$p.account+' SID '+[string]$account.SID)
}
try{
 Admin
 if($Action -eq 'Status'){
  $task=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  Write-Host ('Remote task: '+$(if($task){$task.State}else{'not installed'}))
  if(Test-Path -LiteralPath $confPath){$c=ReadCfg;Write-Host ('Device: '+$c.deviceName+'; remote changes locally allowed: '+$c.allowChanges+'; USB opt-in: '+[bool]$c.allowUsb)}
  $installedFile=Join-Path $remoteRoot 'Remote-Agent.ps1'
  if(Test-Path -LiteralPath $installedFile){
   $versionLine=Get-Content -LiteralPath $installedFile -TotalCount 12 | Where-Object {$_ -match '^\$agentVersion='} | Select-Object -First 1
   Write-Host ('Installed Remote-Agent.ps1 marker: '+$(if($versionLine){$versionLine.Trim()}else{'not readable'}))
  }
  $health=Join-Path $remoteRoot 'agent-health.json'
  if(Test-Path -LiteralPath $health){try{$report=Get-Content -LiteralPath $health -Raw|ConvertFrom-Json;Write-Host ('Authenticated agent: '+$report.version+' at '+$report.confirmedUtc)}catch{Write-Host 'Agent check-in report not readable'}}
  else{Write-Host 'No confirmed agent check-in yet'}
  if($task){try{Write-Host ('Task last result: '+(Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop).LastTaskResult)}catch{}}

  exit 0
 }
 if($Action -eq 'Remove'){
  $task=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if($task){Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop}
  $oldMarker=Join-Path $remoteRoot 'agent-version.txt'
  if(Test-Path -LiteralPath $oldMarker){Remove-Item -LiteralPath $oldMarker -Force -ErrorAction SilentlyContinue}
  $healthMarker=Join-Path $remoteRoot 'agent-health.json'
  if(Test-Path -LiteralPath $healthMarker){Remove-Item -LiteralPath $healthMarker -Force -ErrorAction SilentlyContinue}
  if(Test-Path -LiteralPath $confPath){$c=ReadCfg;$c.allowChanges=$false;SaveCfg $c}
  Write-Host 'Remote polling disabled; protected enrollment, profiles, snapshots and logs preserved.'
  exit 0
 }
 if(-not(Test-Path -LiteralPath $hbCfg)){throw 'Heartbeat enrollment missing. Run Connect to Lovable first.'}
 $hb=Get-Content -LiteralPath $hbCfg -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$hb.deviceName -cnotmatch '^[A-Z0-9-]{3,40}$'){throw 'Unexpected enrolled device name.'}
 if([string]::IsNullOrWhiteSpace([string]$hb.tokenEncrypted)){throw 'DPAPI enrollment credential not found.'}
 SecureFolder
 if($Action -in @('Install','Upgrade')){
  # Migration from ALL older packages: both tasks are explicitly stopped,
  # both installed scripts replaced, and both scheduled definitions rebuilt.
  # Existing DPAPI device token, local consent, policy/USB snapshots stay intact.
  $hbTaskName='RKA-Lockdown-ReadOnlyHeartbeat'
  $stamp=(Get-Date -Format 'yyyyMMdd-HHmmss-fff')
  $backupDir=Join-Path $remoteRoot ('UpgradeBackup-'+$stamp)
  [void](New-Item -ItemType Directory -Path (Join-Path $backupDir 'files') -Force)
  $toRemote=@('Remote-Agent.ps1','Remote-Operations.ps1','PolicyWorker.ps1','Lockdown-Items.ps1','USB-Storage.ps1','LAN-Firewall.ps1','Chrome-Portal-Setup.ps1','Chrome-Portal.ps1','Guest-Action.ps1','Remote-Recovery.ps1','RKA-LAN-Notify.cs','rka.ico')
  $pairs=@();foreach($filename in $toRemote){$pairs+=($filename+'|'+(Join-Path $remoteRoot $filename))}
  $pairs+=('Heartbeat-Client.ps1|'+$hbClient)
  $pairs+=('remote-config.json|'+$confPath)
  $pairs+=('agent-health.json|'+(Join-Path $remoteRoot 'agent-health.json'))
  $pairs+=('Retro Knights Arcade LAN.exe|'+(Join-Path $remoteRoot 'Retro Knights Arcade LAN.exe'))
  $had=@{}
  foreach($pair in $pairs){
   $split=$pair -split '\|',2;$name=$split[0];$dest=$split[1]
   $had[$name]=(Test-Path -LiteralPath $dest)
   if($had[$name]){Copy-Item -LiteralPath $dest -Destination (Join-Path $backupDir ('files\'+$name)) -Force -ErrorAction Stop}
  }
  $heartbeatWasInstalled=TaskXmlBackup $hbTaskName $backupDir
  $agentWasInstalled=TaskXmlBackup $taskName $backupDir
  # Current branding icon is bundled under Application/assets; stage it next
  # to fixed agent sources for backup, atomic replacement and checksum checks.
  $iconSource=Join-Path $PSScriptRoot 'assets\rka.ico'
  if(-not(Test-Path -LiteralPath $iconSource -PathType Leaf)){throw 'Missing RKA notification icon'}
  # Preflight all files before stopping existing tasks.
  foreach($filename in $toRemote+@('Heartbeat-Client.ps1')){
   $source=if($filename -eq 'rka.ico'){$iconSource}else{Join-Path $PSScriptRoot $filename}
   if(-not(Test-Path -LiteralPath $source)){throw ('Missing release file: '+$filename)}
  }
  try{
   foreach($task in @($hbTaskName,$taskName)){
    if(Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue){Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue}
   }
   foreach($filename in $toRemote){
    $source=if($filename -eq 'rka.ico'){$iconSource}else{Join-Path $PSScriptRoot $filename}
    Copy-Item -LiteralPath $source -Destination (Join-Path $remoteRoot $filename) -Force -ErrorAction Stop
   }
   Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Heartbeat-Client.ps1') -Destination $hbClient -Force -ErrorAction Stop
   if(Test-Path -LiteralPath $confPath){
    $cfg=ReadCfg
    if([string]$cfg.deviceName -cne [string]$hb.deviceName){throw 'Device enrollment mismatch. No new device token has been generated.'}
    if(-not $cfg.PSObject.Properties['allowUsb']){$cfg|Add-Member -NotePropertyName allowUsb -NotePropertyValue $false}
   }else{$cfg=[pscustomobject]@{deviceName=[string]$hb.deviceName;allowChanges=$false;allowUsb=$false;installedAt=(Get-Date -Format 'o')}}
   SaveCfg $cfg
   if($ProfilePath){CopyProfile $ProfilePath}
   # Invalidate any prior remote agent confirmation, so the heartbeat cannot
   # send an old/guessed version during installation.
   $healthFile=Join-Path $remoteRoot 'agent-health.json'
   if(Test-Path -LiteralPath $healthFile){Remove-Item -LiteralPath $healthFile -Force}
   $psExe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
   $when=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650)
   $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
   $settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 4) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
   $hbAction=New-ScheduledTaskAction -Execute $psExe -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$hbClient+'"')
   $remoteAction=New-ScheduledTaskAction -Execute $psExe -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $remoteRoot 'Remote-Agent.ps1')+'"')
   Register-ScheduledTask -TaskName $hbTaskName -Action $hbAction -Trigger $when -Principal $principal -Settings $settings -Description 'RKA v1.8.1 heartbeat. Reports confirmed remote agent status, not the GUI version.' -Force -ErrorAction Stop|Out-Null
   Register-ScheduledTask -TaskName $taskName -Action $remoteAction -Trigger $when -Principal $principal -Settings $settings -Description 'RKA v1.8.1 typed remote agent, SYSTEM service account.' -Force -ErrorAction Stop|Out-Null
   # Confirm task paths and both copied payloads before starting.
   foreach($expected in @(@($hbTaskName,$hbClient),@($taskName,(Join-Path $remoteRoot 'Remote-Agent.ps1')))){
    $actual=Get-ScheduledTask -TaskName $expected[0] -ErrorAction Stop
    if(-not $actual -or ($actual.Actions[0].Arguments -notlike ('*'+$expected[1]+'*'))){throw ('Scheduled task points to unexpected script: '+$expected[0])}
   }
   foreach($filename in $toRemote+@('Heartbeat-Client.ps1')){
    $dest=if($filename -eq 'Heartbeat-Client.ps1'){$hbClient}else{Join-Path $remoteRoot $filename}
    $source=if($filename -eq 'rka.ico'){$iconSource}else{Join-Path $PSScriptRoot $filename}
    if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -cne (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash){throw ('Copy checksum mismatch: '+$filename)}
   }
   SecureFolder
   # Always compile after copying/validating the source; if compilation fails,
   # the original proven PowerShell guest balloon notification remains usable.
   Install-RkaNotificationHelper
   & "$env:SystemRoot\System32\icacls.exe" (Join-Path $remoteRoot 'Guest-Action.ps1') '/grant:r' '*S-1-5-32-545:R' |Out-Null
   if($LASTEXITCODE -ne 0){throw 'Unable to grant read access for guest notification helper'}
   Start-ScheduledTask -TaskName $taskName -ErrorAction Stop
   Start-ScheduledTask -TaskName $hbTaskName -ErrorAction Stop
   $state=@{version='1.8.1';installedUtc=[DateTime]::UtcNow.ToString('o');heartbeatTask=$hbTaskName;remoteTask=$taskName;backupFolder=$backupDir;verification='pending_agent_poll'}
   $state|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $remoteRoot 'installation-state.json') -Encoding UTF8
   WriteSafe ('v1.8.1 task upgrade staged; files verified; backup: '+$backupDir)
   # A brief poll check distinguishes scheduled startup from authenticated
   # command-channel readiness. A network outage never silently erases consent.
   $verified=$false
   for($attempt=0;$attempt -lt 8;$attempt++){
    Start-Sleep -Seconds 3
    $file=Join-Path $remoteRoot 'agent-health.json'
    if(Test-Path -LiteralPath $file){
     try{$h=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json
      if($h.version -eq '1.8.1' -and ([datetimeoffset]::UtcNow-[datetimeoffset]::Parse($h.confirmedUtc)).TotalMinutes -lt 2){$verified=$true;break}
     }catch{}
    }
   }
   if($verified){$out='v1.8.1 installed: both tasks replaced; authenticated agent poll confirmed. Existing enrollment and consent preserved.'}
   else{$out='v1.8.1 files and both scheduled tasks installed, BUT authenticated agent poll not yet confirmed. Check connection/logs; Lovable might still report the old version until fresh successful communication.'}
   WriteSafe $out
  }catch{
   $detail=$_.Exception.Message
   WriteSafe ('v1.8.1 install failure, restoring prior installed scripts and BOTH task definitions: '+$detail)
   try{RestoreBackup $backupDir $pairs $had} catch{WriteSafe ('Rollback failed: '+$_.Exception.Message);throw ('Installation failed: '+$detail+'. Rollback ALSO failed; use local administrator recovery. Backup: '+$backupDir)}
   throw ('Installation failed; previous scheduled tasks/scripts restored: '+$detail+'. Backup: '+$backupDir)
  }
 }else{
  $conf=ReadCfg
  if([string]$conf.deviceName -cne [string]$hb.deviceName){throw 'Remote enrollment mismatch; reinstall remote setup.'}
  if($Action -eq 'EnableChanges'){$conf.allowChanges=$true;SaveCfg $conf;$out='Remote changes enabled. Authorized typed requests may modify validated guest policy or schedule power actions; test laptop first.'}
  elseif($Action -eq 'DisableChanges'){$conf.allowChanges=$false;SaveCfg $conf;$out='Remote changes disabled. Read-only diagnostics continue.'}
  elseif($Action -eq 'SyncProfile'){CopyProfile $ProfilePath;$out='Current admin guest profile copied into protected remote policy storage.'}
  elseif($Action -eq 'EnableUsb'){
   if(-not $conf.allowChanges){throw 'Enable remote changes first before allowing system-wide USB control'}
   $conf.allowUsb=$true;SaveCfg $conf;$out='SYSTEM-WIDE USB remote changes ENABLED. This affects administrators too. Test recovery first.'
  }
  elseif($Action -eq 'DisableUsb'){$conf.allowUsb=$false;SaveCfg $conf;$out='SYSTEM-WIDE USB remote changes disabled.'}
 }
 WriteSafe $out
 $out|Set-Content -LiteralPath (Join-Path $remoteRoot 'remote-status.txt') -Encoding UTF8
 Write-Host $out
}catch{
 WriteSafe ('SETUP ERROR '+$Action+': '+$_.Exception.Message)
 Write-Error $_.Exception.Message
 exit 1
}
