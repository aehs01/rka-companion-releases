# Retro Knights Arcade - guest lockdown worker (Companion 1.2), Windows PowerShell 5.1.
# Runs elevated, from the Companion window or as SYSTEM from Lovable's agent.
# Block writes an item's registry values for the guest; Allow deletes them, so
# Allow and Unlock everything always return the guest to Windows' defaults,
# however it was locked before. Before 1.2 the Companion restored a snapshot
# instead, which couldn't undo a lockdown applied before the snapshot existed.
# Registry policies stop normal use, not every workaround.
#Requires -Version 5.1
param(
 [Parameter(Mandatory=$true)][ValidateSet('Set','Persistent','UnlockAll','Restore','WindowsUpdate')][string]$Operation,
 [string]$TargetSid='',
 [string]$ProfilePath='',
 # 1.7: 'lock' was missing, so the Companion window's Lock on Ctrl+Alt+Del row
 # (added in 1.3) failed. It and Lovable's lock_workstation now work.
 [ValidateSet('','settings','cmd','registry','taskmgr','password','lock','popups','usb','browser')][string]$Item='',
 [ValidateSet('','Block','Allow')][string]$State='',
 # Accepted from older callers and ignored; snapshots aren't used any more.
 [string]$BackupPath=''
)
$ErrorActionPreference='Stop'
$Root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery'
$Pointer=Join-Path $Root 'current.json'
$LogPath=Join-Path $Root 'worker.log'
. (Join-Path $PSScriptRoot 'Lockdown-Items.ps1')
# Gaming sign-in, email-code and captcha sites, always allowed when Chrome and Edge are restricted,
# with the asset hosts their sign-in pages load from.
# Keep identical to $script:RkaGameSignInHosts in Remote-Operations.ps1.
$GameSignInSites=@('retroknightsarcade.com','riotgames.com','leagueoflegends.com','playvalorant.com','epicgames.com','ea.com','battle.net','blizzard.com','ubisoft.com','ubi.com','steampowered.com','steamcommunity.com','gog.com','xbox.com','account.sony.com','live.com','outlook.com','hotmail.com','account.microsoft.com','login.microsoftonline.com','msauth.net','msftauth.net','accounts.google.com','mail.google.com','gstatic.com','login.yahoo.com','mail.yahoo.com','guce.yahoo.com','yimg.com','appleid.apple.com','idmsa.apple.com','icloud.com','hcaptcha.com','arkoselabs.com','challenges.cloudflare.com','recaptcha.net','www.google.com/recaptcha')
function Write-Log([string]$msg){try{Add-Content -LiteralPath $LogPath -Value "$(Get-Date -Format o) $msg" -Encoding UTF8}catch{}}
function Assert-Admin {
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 $principal=[Security.Principal.WindowsPrincipal]$identity
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator elevation is required.'}
}
function Ensure-Root {
 if(-not(Test-Path -LiteralPath $Root)){New-Item -Path $Root -ItemType Directory -Force|Out-Null}
 # Explicitly remove inherited Users/Authenticated Users permissions: guests must not edit the log.
 & icacls.exe $Root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Cannot secure ProgramData recovery directory ACL.'}
}
function Open-Hive([string]$sid) {
 $usr=[Microsoft.Win32.Registry]::Users
 $h=$usr.OpenSubKey($sid,$true)
 if($h){return [pscustomobject]@{ Key=$h; Mounted=$false; MountId=$sid }}
 $p=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop | Select-Object -First 1
 if(-not $p -or -not $p.LocalPath){throw 'Could not find the selected Windows user profile. Sign into the guest account once first.'}
 $dat=Join-Path $p.LocalPath 'NTUSER.DAT'
 if(-not(Test-Path -LiteralPath $dat)){throw 'Guest registry hive was not found. Sign into the guest account once first.'}
 $mount='RKA_LOCKDOWN_'+([guid]::NewGuid().ToString('N'))
 & reg.exe load "HKU\$mount" $dat |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Could not load guest account registry hive. Sign the guest out and retry.'}
 $h=$usr.OpenSubKey($mount,$true)
 if(-not $h){throw 'Loaded guest account hive is inaccessible.'}
 return [pscustomobject]@{ Key=$h; Mounted=$true; MountId=$mount }
}
function Close-Hive($h){
 if($null -ne $h.Key){$h.Key.Dispose()}
 if($h.Mounted){[gc]::Collect();[gc]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 200; & reg.exe unload "HKU\$($h.MountId)" |Out-Null;if($LASTEXITCODE -ne 0){Write-Log "WARN unload hive: $($h.MountId)"}}
}
# The approved websites a browser Block writes: both allowlists, then '*' for each browser.
function Get-BrowserChanges($profile) {
 $l=New-Object System.Collections.ArrayList
 function Put($path,$name,$value,$kind){[void]$l.Add(@{Path=$path;Name=$name;Value=$value;Kind=$kind})}
 $approved=@()
 foreach($url in @($profile.urls)){
  if([string]::IsNullOrWhiteSpace($url)){continue}
  $u=$null
  if(-not [uri]::TryCreate([string]$url,[UriKind]::Absolute,[ref]$u) -or $u.Scheme -notin @('http','https') -or -not [string]::IsNullOrEmpty($u.UserInfo)){throw "Invalid approved website $url"}
  # Chromium URLFilter patterns: host-only covers http and https and all paths.
  $hostPattern=$u.Host.ToLowerInvariant()
  if($u.IsDefaultPort -eq $false){$hostPattern+=':'+$u.Port}
  $approved+=$hostPattern
  if($u.Host.ToLowerInvariant() -in @('discord.com','discord.gg','discordapp.com','cdn.discordapp.com')){$approved+='[*.]'+$u.Host.ToLowerInvariant()}
 }
 # The intranet is always allowed, even when an older profile omits it.
 $intranetUri=$null
 if(-not [uri]::TryCreate([string]$profile.intranet,[UriKind]::Absolute,[ref]$intranetUri) -or $intranetUri.Scheme -notin @('http','https')){throw 'Configured intranet URL is missing or invalid.'}
 $approved+= $intranetUri.Host.ToLowerInvariant()
 if(-not $intranetUri.IsDefaultPort){$approved+=($intranetUri.Host.ToLowerInvariant()+':'+$intranetUri.Port)}
 $approved+= @('discord.com','[*.]discord.com','discord.gg','[*.]discord.gg','cdn.discordapp.com','[*.]discordapp.com','edge://policy','chrome://policy')
 $approved+= $GameSignInSites
 $index=1
 foreach($url in ($approved|Select-Object -Unique)){Put 'Software\Policies\Microsoft\Edge\URLAllowlist' ([string]$index) $url 'String';$index++}
 $index=1
 foreach($url in ($approved|Select-Object -Unique)){Put 'Software\Policies\Google\Chrome\URLAllowlist' ([string]$index) $url 'String';$index++}
 # Security invariant: both allowlists are written before wildcard URL blocking.
 Put 'Software\Policies\Google\Chrome\URLBlocklist' '1' '*' 'String'
 Put 'Software\Policies\Microsoft\Edge\URLBlocklist' '1' '*' 'String'
 return $l.ToArray()
}
function Find-Sid($sid){
 if($sid -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Invalid local account SID.'}
 $account=Get-CimInstance Win32_UserAccount -Filter "SID='$sid' AND LocalAccount=True" |Select-Object -First 1
 if(-not $account){throw 'Guest account missing.'}
 $adminMembers=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
 foreach($member in $adminMembers){if($member.SID -and $member.SID.Value -eq $sid){throw 'Refusing to lock down an administrator account.'}}
 if($sid -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Refusing to lock down the current administrator.'}
 return $account
}
# Every local standard account with a profile, for Unlock everything with no account named.
function Find-StandardAccounts {
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop|Where-Object {$_.SID}|ForEach-Object {$_.SID.Value})
 $me=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
 return @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop|Where-Object {
  $_.SID -match '^S-1-5-21-(\d+-){3}\d+$' -and $_.SID -notmatch '-(500|501|503|504)$' -and $admins -notcontains $_.SID -and $_.SID -ne $me
 })
}
function Read-ProfileFile([string]$path,$account){
 if(-not $path -or -not(Test-Path -LiteralPath $path)){throw 'Lockdown choices not found.'}
 $p=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$p.account -ne [string]$account.Name){throw 'The saved lockdown choices are for another account.'}
 return $p
}
# "User cannot change password" on the account itself, beside the Ctrl+Alt+Del policy.
function Set-PasswordFlag([string]$name,[bool]$block){
 & net.exe user "$name" /passwordchg:$(if($block){'no'}else{'yes'}) |Out-Null
 if($LASTEXITCODE -ne 0){throw "Windows refused to change $name's password setting."}
}
# Pre-1.2 snapshots would make the old agent refuse changes; once unlocked they mean nothing.
function Retire-Snapshots {
 $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
 if(Test-Path -LiteralPath $Pointer){Move-Item -LiteralPath $Pointer -Destination (Join-Path $Root "current.retired-$stamp.json") -Force}
 $items=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl\ItemRecovery'
 if(Test-Path -LiteralPath $items){Move-Item -LiteralPath $items -Destination ($items+".retired-$stamp") -Force}
}
function Set-GuestItem([string]$sid,$account,[string]$item,[bool]$block,$profile){
 $values=@()
 if($item -eq 'browser' -and $block){$values=@(Get-BrowserChanges $profile)}
 $h=$null
 try{
  $h=Open-Hive $sid
  Set-RkaItem $h.Key $item $block $values
  $now=Get-RkaItemState $h.Key $item
 }finally{if($h){Close-Hive $h}}
 if($item -eq 'password'){Set-PasswordFlag $account.Name $block}
 $expected=$(if($block){'Blocked'}else{'Allowed'})
 if($now -ne $expected){throw "$($script:RkaGuestItems[$item].Label) reads back as $now, not $expected."}
 return $now
}
function Unlock-Guest([string]$sid,[string]$name){
 $h=$null
 try{
  $h=Open-Hive $sid
  foreach($item in $script:RkaGuestItems.Keys){Set-RkaItem $h.Key $item $false}
  $left=@($script:RkaGuestItems.Keys|Where-Object {(Get-RkaItemState $h.Key $_) -ne 'Allowed'})
 }finally{if($h){Close-Hive $h}}
 Set-PasswordFlag $name $false
 if($left.Count){throw "$name still has: $($left -join ', ')"}
}
# Windows Update restarts only after closing (latest close is midnight, earliest
# open 10 AM), and never while someone is signed in; the PCs restart each night.
$UpdatePolicy='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
function Set-AfterHoursUpdates([bool]$block){
 $au=Join-Path $UpdatePolicy 'AU'
 if($block){
  foreach($p in @($UpdatePolicy,$au)){if(-not(Test-Path -LiteralPath $p)){New-Item -Path $p -Force|Out-Null}}
  Set-ItemProperty -LiteralPath $UpdatePolicy -Name SetActiveHours -Value 1 -Type DWord
  Set-ItemProperty -LiteralPath $UpdatePolicy -Name ActiveHoursStart -Value 9 -Type DWord
  Set-ItemProperty -LiteralPath $UpdatePolicy -Name ActiveHoursEnd -Value 1 -Type DWord
  Set-ItemProperty -LiteralPath $au -Name NoAutoRebootWithLoggedOnUsers -Value 1 -Type DWord
 }else{
  foreach($n in @('SetActiveHours','ActiveHoursStart','ActiveHoursEnd')){Remove-ItemProperty -LiteralPath $UpdatePolicy -Name $n -ErrorAction SilentlyContinue}
  Remove-ItemProperty -LiteralPath $au -Name NoAutoRebootWithLoggedOnUsers -ErrorAction SilentlyContinue
 }
}
try{
 Assert-Admin; Ensure-Root
 switch($Operation){
  'Set' {
   if(-not $Item -or -not $State){throw 'Set needs -Item and -State.'}
   $account=Find-Sid $TargetSid
   $profile=$null
   if($Item -eq 'browser' -and $State -eq 'Block'){$profile=Read-ProfileFile $ProfilePath $account}
   $now=Set-GuestItem $TargetSid $account $Item ($State -eq 'Block') $profile
   Write-Log "$State $Item for $($account.Name): $now"
   Write-Output "$($script:RkaGuestItems[$Item].Label): $now"
  }
  'Persistent' {
   # The saved choices, all at once (Lovable's Apply lockdown, or an imported file).
   $account=Find-Sid $TargetSid
   $profile=Read-ProfileFile $ProfilePath $account
   foreach($entry in $script:RkaProfileFlags.GetEnumerator()){
    [void](Set-GuestItem $TargetSid $account $entry.Key ([bool]$profile.($entry.Value)) $profile)
   }
   Retire-Snapshots
   Write-Log "Applied saved choices for $($account.Name)"
  }
  {$_ -in @('UnlockAll','Restore')} {
   if($TargetSid){$targets=@(Find-Sid $TargetSid)}else{$targets=@(Find-StandardAccounts)}
   $failed=@()
   foreach($a in $targets){
    try{Unlock-Guest ([string]$a.SID) ([string]$a.Name);Write-Log "Unlocked everything for $($a.Name)";Write-Output "Unlocked: $($a.Name)"}
    catch{$failed+="$($a.Name): $($_.Exception.Message)";Write-Log "Unlock failed for $($a.Name): $($_.Exception.Message)"}
   }
   Retire-Snapshots
   if($failed.Count){throw ('Unlock everything finished with problems: '+($failed -join '; '))}
  }
  'WindowsUpdate' {
   if(-not $State){throw 'WindowsUpdate needs -State.'}
   Set-AfterHoursUpdates ($State -eq 'Block')
   Write-Log "Windows Update after closing only: $State"
   Write-Output "Windows Update: $(if($State -eq 'Block'){'restarts only after closing'}else{'Windows default'})"
  }
 }
 exit 0
}catch{
 Write-Log "FAILED $Operation $Item $State : $($_.Exception.ToString())"
 Write-Output ('ERROR: '+$_.Exception.Message)
 exit 1
}
