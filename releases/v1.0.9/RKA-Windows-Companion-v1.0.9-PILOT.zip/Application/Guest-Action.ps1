﻿# Windows user-session helper. Run ONLY as validated standard guest from RKA's installed scheduled task.
# The SYSTEM agent creates the protected instruction file; no remote supplied file paths are allowed.
#Requires -Version 5.1
param([ValidateSet('Wallpaper','Announcement')][string]$Action,[string]$InstructionFile)
$ErrorActionPreference='Stop'
try{
 $base=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl\GuestActions'
 $full=[IO.Path]::GetFullPath($InstructionFile)
 if(-not $full.StartsWith(([IO.Path]::GetFullPath($base)+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected instruction location'}
 $data=Get-Content -LiteralPath $full -Raw -Encoding UTF8|ConvertFrom-Json
 if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -cne [string]$data.sid){throw 'Guest SID mismatch'}
 if($Action -eq 'Wallpaper'){
  $path=[string]$data.image
  if(-not [IO.Path]::IsPathRooted($path)){throw 'Image must be local'}
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw 'Wallpaper file unavailable'}
  Add-Type @'
using System;
using System.Runtime.InteropServices;
public class RkaWallpaperApi {
 [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
 public static extern bool SystemParametersInfo(int action, int param, string path, int flags);
}
'@
  $ok=[RkaWallpaperApi]::SystemParametersInfo(20,0,$path,3)
  if(-not $ok){throw 'Windows did not apply wallpaper'}
 }else{
  $msg=[string]$data.message
  if($msg.Length -lt 1 -or $msg.Length -gt 240){throw 'Message length invalid'}
  # Prefer a dedicated Windows executable rather than a PowerShell notification
  # identity. Windows displays the executable's brand/description as the sender.
  # It is compiled locally at agent install, runs as the verified guest, and has
  # no ability to execute remote commands. Keep the proven balloon fallback.
  $app=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl\Retro Knights Arcade LAN.exe'
  $displayed=$false
  if(Test-Path -LiteralPath $app -PathType Leaf){
   try{
    $encoded=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($msg))
    $p=Start-Process -FilePath $app -ArgumentList $encoded -PassThru -Wait -WindowStyle Hidden -ErrorAction Stop
    $displayed=($p.ExitCode -eq 0)
   }catch{$displayed=$false}
  }
  if(-not $displayed){
   Add-Type -AssemblyName System.Windows.Forms
   Add-Type -AssemblyName System.Drawing
   $toast=New-Object System.Windows.Forms.NotifyIcon
   try{
    $toast.Icon=[System.Drawing.SystemIcons]::Information
    $toast.Visible=$true
    $toast.BalloonTipTitle='Retro Knights Arcade LAN'
    $toast.BalloonTipText=$msg
    # Windows 10/11 may override notification timing with user Accessibility settings.
    $toast.ShowBalloonTip(30000)
    Start-Sleep -Seconds 32
   }finally{$toast.Visible=$false;$toast.Dispose()}
  }
 }
}catch{
 # Guest-session delivery is best-effort. Never create a focus-stealing MessageBox.
 exit 1
}
