﻿# RKA Windows Companion - modern WPF (.NET Framework / PresentationFramework) preview.
# Windows PowerShell 5.1, Windows 10/11; uses existing audited local scripts.
#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$script:AppVersion = '1.0.9'
$script:UpdateAvailableVersion = $null
$script:AppRoot = $PSScriptRoot
$script:DataRoot = Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent'
$script:ProfileFile = Join-Path $script:DataRoot 'profile.json'
$script:LogFile = Join-Path $script:DataRoot 'wpf-ui.log'
$script:RecoveryRoot = Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery'
$script:RecoveryPointer = Join-Path $script:RecoveryRoot 'current.json'
$script:ChromeStatusFile = Join-Path $env:ProgramData 'RKA-Lockdown-Agent\chrome-setup-last-result.txt'
$script:HeartbeatStatusFile = Join-Path $script:DataRoot 'heartbeat-ui-status.txt'
$script:PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$script:AllowExit = $false
$script:SavedProfile = $null
$script:GuestAccounts = @()
$script:ApprovedUrls = @()
# Canonical first-run defaults. These are shown in the editor but do not change Windows until Apply Restrictions.
# Keep the five originally tested local LAN/Discord dependencies together in one place.
$script:DefaultApprovedUrls = @('http://rkaserver/','https://discord.com/','https://discord.gg/','https://cdn.discordapp.com/','https://media.discordapp.net/')
$script:TrayIcon = $null
$script:Mutex = $null
$script:MutexAcquired = $false

function Write-RkaLog([string]$message) {
 try {
  if(-not(Test-Path -LiteralPath $script:DataRoot)){New-Item -Path $script:DataRoot -ItemType Directory -Force|Out-Null}
  Add-Content -LiteralPath $script:LogFile -Value ('{0:o} {1}' -f (Get-Date),$message) -Encoding UTF8
 } catch {}
}
function Show-Notice([string]$message, [string]$title = 'RKA Windows Companion') {
 [System.Windows.MessageBox]::Show($script:Window,$message,$title,[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Information)|Out-Null
}
function Show-Failure([string]$message, [string]$title = 'Operation failed') {
 Write-RkaLog "FAIL: $message"
 [System.Windows.MessageBox]::Show($script:Window,$message,$title,[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Error)|Out-Null
}
function Ask-YesNo([string]$message,[string]$title='Confirm action') {
 return ([System.Windows.MessageBox]::Show($script:Window,$message,$title,[System.Windows.MessageBoxButton]::YesNo,[System.Windows.MessageBoxImage]::Warning) -eq [System.Windows.MessageBoxResult]::Yes)
}
function Set-Footer([string]$message,[bool]$error=$false) {
 $script:Ui.FooterStatus.Text = $(if($error){'ERROR: '}else{'STATUS: '})+$message
 $script:Ui.FooterStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($error){'#FF768A'}else{'#8AE5FF'}))
 $script:Ui.LatestActionLabel.Text = $message
}
function Assert-Admin {
 $principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  throw 'The WPF Control Center requires an ELEVATED local administrator session. Right-click Launch-RKA-WPF.cmd and choose Run as administrator. The standard guest account cannot manage lockdown.'
 }
}
function Check-Url([string]$value) {
 $uri=$null
 return (($value.Length -le 500) -and ($value -notmatch '[*\s#"<>]') -and [Uri]::TryCreate($value,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -in @('http','https') -and -not $uri.UserInfo)
}
# Chrome Startup > Portal URL is the shared live destination for all guest portal shortcuts.
# Never use a retired hardcoded hostname or silently change the saved browser allowlist.
function Get-CurrentPortalUrl {
 $url=[string]$script:Ui.ChromeUrl.Text.Trim()
 if(-not(Check-Url $url)){throw 'Set a valid Portal URL under Chrome Startup before deploying an intranet shortcut.'}
 return $url
}
function Sync-PortalUrl([string]$source) {
 if($script:PortalUrlSyncing){return}
 try{
  $script:PortalUrlSyncing=$true
  if($source -eq 'Chrome'){
   $url=[string]$script:Ui.ChromeUrl.Text
   if($script:Ui.GamePortalUrl.Text -cne $url){$script:Ui.GamePortalUrl.Text=$url}
  }else{
   $url=[string]$script:Ui.GamePortalUrl.Text
   if($script:Ui.ChromeUrl.Text -cne $url){$script:Ui.ChromeUrl.Text=$url}
  }
 }finally{$script:PortalUrlSyncing=$false}
}
function Read-Profile {
 $default=[pscustomobject]@{account='';intranet='http://rkaserver/';urls=@($script:DefaultApprovedUrls);blockSettings=$false;blockCmd=$false;blockRegistry=$false;restrictEdge=$false;networkBrowse=$false;hideThisPc=$false}
 if(Test-Path -LiteralPath $script:ProfileFile){
  try {
   $p=Get-Content -LiteralPath $script:ProfileFile -Raw -Encoding UTF8|ConvertFrom-Json
   foreach($prop in $default.PSObject.Properties){if(-not $p.PSObject.Properties[$prop.Name]){$p|Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value}}
   # Migrate ONLY the obsolete test hostname; preserve all other user-entered addresses.
   if([string]$p.intranet -match '^https?://tyrant/?$'){$p.intranet='http://rkaserver/'}
   $loadedUrls=@($p.urls | Where-Object {-not [string]::IsNullOrWhiteSpace([string]$_)} | ForEach-Object {if(([string]$_) -match '^https?://tyrant/?$'){'http://rkaserver/'}else{[string]$_}} | Select-Object -Unique)
   # A legacy/partially initialized profile may contain urls: [] even though the packaged
   # defaults are present. Repair ONLY an empty list; keep nonempty custom lists intact.
   if($loadedUrls.Count -eq 0){
    $loadedUrls=@($script:DefaultApprovedUrls)
    Write-RkaLog 'Missing/empty approved-websites profile: recommended RKA defaults loaded in memory; Windows policy unchanged.'
   }
   # Keep the chosen intranet (including a customized hostname) visible in the editor.
   # Never restore the retired Tyrant name or overwrite other custom websites.
   if((Check-Url ([string]$p.intranet)) -and $loadedUrls -notcontains [string]$p.intranet){$loadedUrls=@([string]$p.intranet)+$loadedUrls}
   $p.urls=@($loadedUrls | Select-Object -Unique)
   # v1.0.2: import the approved host list last verified and changed remotely.
   # This changes only the in-memory editor view until the administrator saves;
   # no user profile files or registry rules are silently overwritten.
   $remoteSites=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl\approved-websites-state.json'
   if((Test-Path -LiteralPath $remoteSites) -and -not [string]::IsNullOrWhiteSpace([string]$p.account)){
    try{
     $rs=Get-Content -LiteralPath $remoteSites -Raw -Encoding UTF8|ConvertFrom-Json
     $matching=@(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop|Where-Object {$_.Name -ceq [string]$p.account -and $_.SID -ceq [string]$rs.sid})
     if($matching.Count -eq 1 -and [int]$rs.schema -eq 1 -and $rs.source -eq 'authenticated_remote_command'){
      $sites=@(([string]$p.intranet))
      foreach($hostName in @($rs.hosts)){
       $hostName=[string]$hostName
       if($hostName -match '^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'){$sites+=('https://'+$hostName+'/')}
      }
      $p.urls=@($sites|Select-Object -Unique)
      Write-RkaLog 'Loaded remote-approved website snapshot into editor; Save Profile Only persists to this administrator profile. Actual policy was not changed.'
     }
    }catch{Write-RkaLog 'Remote website projection unavailable or invalid; preserving local saved list.'}
   }
   return $p
  }catch{Write-RkaLog "Profile load failed: $($_.Exception.Message)"}
 }
 return $default
}
function Find-GuestAccounts {
 $script:GuestAccounts=@()
 $script:Ui.NoGuestMessage.Text=''
 try {
  $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
  $currentSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  foreach($a in @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop)) {
   if($a.Disabled -or $a.Lockout -or $a.SID -match '-(500|501|503|504)$' -or $admins -contains $a.SID -or $a.SID -eq $currentSid){continue}
   $script:GuestAccounts+= [pscustomobject]@{Name=[string]$a.Name;SID=[string]$a.SID;Label=([string]$a.Name+' - Standard user')}
  }
 }catch{Write-RkaLog "Account discovery failed: $($_.Exception.Message)"}
 $script:Ui.GuestSelector.ItemsSource = $script:GuestAccounts
 if($script:GuestAccounts.Count -eq 0){
  $script:Ui.NoGuestMessage.Text='No standard guest account found. Create a local standard account and sign into it once.'
  $script:Ui.GuestSelector.IsEnabled=$false
  foreach($name in @('SaveProfileButton','ApplyRestrictionsButton','VerifyPolicyButton','ChromeInstall','DeployIntranetButton','SaveDesktopBackupButton','RestoreDesktopBackupButton')){if($script:Ui.ContainsKey($name)){$script:Ui[$name].IsEnabled=$false}}
 } else {$script:Ui.GuestSelector.IsEnabled=$true}
 $preferred=[string]$script:SavedProfile.account
 $index=-1
 for($i=0;$i -lt $script:GuestAccounts.Count;$i++){if($script:GuestAccounts[$i].Name -ieq $preferred){$index=$i;break}}
 if($index -lt 0 -and $script:GuestAccounts.Count -eq 1){$index=0}
 if($index -ge 0){$script:Ui.GuestSelector.SelectedIndex=$index}
}
function Selected-Guest {
 $guest=$script:Ui.GuestSelector.SelectedItem
 if(-not $guest -or -not $guest.SID){throw 'Select a verified standard guest account. Check the account under Windows Settings and restart this window if it is missing.'}
 # Reconfirm account is not in Administrators at the moment of every privileged action.
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
 if($admins -contains $guest.SID){throw 'Cannot use an administrator as a guest. Operation canceled.'}
 if($guest.SID -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Cannot target the current admin account.'}
 return $guest
}
function Profile-From-UI {
 $g=Selected-Guest
 $url=Get-CurrentPortalUrl
 if(-not(Check-Url $url)){throw 'Please enter a valid http(s) LAN intranet URL with no wildcard, spaces or embedded credentials.'}
 $old=$script:SavedProfile
 $urls=@($script:ApprovedUrls | Where-Object {$_ -and (Check-Url ([string]$_))})
 if($urls -notcontains $url){$urls=@($url)+$urls}
 return [ordered]@{version=$script:AppVersion;account=$g.Name;intranet=$url;urls=$urls;blockSettings=[bool]$script:Ui.ChkSettings.IsChecked;blockCmd=[bool]$script:Ui.ChkCmd.IsChecked;blockRegistry=[bool]$script:Ui.ChkRegistry.IsChecked;restrictEdge=[bool]$script:Ui.ChkEdge.IsChecked;networkBrowse=$false;hideThisPc=$false}
}
function Edit-ApprovedSites {
 try {
  $dialog=New-Object System.Windows.Window
  $dialog.Title='Guest browser approved websites'
  $dialog.Width=670; $dialog.Height=480
  $dialog.MinWidth=530; $dialog.MinHeight=360
  $dialog.WindowStartupLocation='CenterOwner';$dialog.Owner=$script:Window
  $dialog.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0B1C2B')
  $dialog.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#E8F4FF')
  $dialog.FontFamily='Segoe UI'
  $grid=New-Object System.Windows.Controls.Grid
  $grid.Margin='20'
  $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))
  $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=([System.Windows.GridLength]::new(1,[System.Windows.GridUnitType]::Star))}))
  $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))
  $desc=New-Object System.Windows.Controls.TextBlock
  $desc.Text='One complete http(s) URL per line. First-run RKA defaults include the LAN portal and four Discord sites. Add RKA defaults merges missing sites without deleting custom entries. Save the list, then Apply Restrictions to update Windows.'
  $desc.TextWrapping='Wrap';$desc.Margin='0,0,0,12'
  [System.Windows.Controls.Grid]::SetRow($desc,0);[void]$grid.Children.Add($desc)
  $urlBox=New-Object System.Windows.Controls.TextBox
  $urlBox.Text=@($script:ApprovedUrls) -join "`r`n"
  $urlBox.AcceptsReturn=$true;$urlBox.VerticalScrollBarVisibility='Auto';$urlBox.FontFamily='Consolas';$urlBox.FontSize=15
  $urlBox.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#102D41')
  $urlBox.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#F5FBFF')
  $urlBox.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#2184A6')
  [System.Windows.Controls.Grid]::SetRow($urlBox,1);[void]$grid.Children.Add($urlBox)
  $panel=New-Object System.Windows.Controls.StackPanel
  $panel.Orientation='Horizontal';$panel.HorizontalAlignment='Right';$panel.Margin='0,14,0,0'
  # Explicit opt-in for existing profiles with a nonempty custom list: merge missing RKA
  # defaults without deleting any entries. The editor still requires Save before applying.
  $defaultsButton=New-Object System.Windows.Controls.Button
  $defaultsButton.Content='Add RKA defaults';$defaultsButton.Padding='10,9';$defaultsButton.Margin='0,0,10,0'
  $defaultsButton.Add_Click({
   $entries=@($urlBox.Text -split '\r?\n' | ForEach-Object {$_.Trim()} | Where-Object {$_})
   foreach($defaultUrl in $script:DefaultApprovedUrls){if($entries -notcontains $defaultUrl){$entries+= $defaultUrl}}
   $urlBox.Text=(@($entries|Select-Object -Unique) -join "`r`n")
  })
  $save=New-Object System.Windows.Controls.Button
  $save.Content='Save website list';$save.Padding='10,9';$save.Margin='0,0,10,0'
  $cancel=New-Object System.Windows.Controls.Button
  $cancel.Content='Cancel';$cancel.Padding='14,9'
  $save.Add_Click({
   try{
    $raw=@($urlBox.Text -split '\r?\n' | ForEach-Object {$_.Trim()} | Where-Object {$_})
    if($raw.Count -gt 20){throw 'Limit the browser allowlist to 20 specific websites.'}
    foreach($u in $raw){if(-not(Check-Url ([string]$u))){throw "Invalid approved website: $u"}}
    if($script:Ui.ChkEdge.IsChecked -and $raw.Count -eq 0){throw 'Browser restrictions require at least one approved URL.'}
    $script:ApprovedUrls=@($raw|Select-Object -Unique)
    $dialog.DialogResult=$true
   }catch{[System.Windows.MessageBox]::Show($dialog,$_.Exception.Message,'Approved websites',[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Warning)|Out-Null}
  })
  $cancel.Add_Click({$dialog.DialogResult=$false})
  [void]$panel.Children.Add($defaultsButton);[void]$panel.Children.Add($save);[void]$panel.Children.Add($cancel)
  [System.Windows.Controls.Grid]::SetRow($panel,2);[void]$grid.Children.Add($panel)
  $dialog.Content=$grid
  if($dialog.ShowDialog() -eq $true){Save-Profile $false;Set-Footer ('Guest browser website list saved ('+$script:ApprovedUrls.Count+' addresses). Apply restrictions to update Windows.')}
 }catch{Show-Failure $_.Exception.Message 'Website editor failed'}
}
function Save-Profile([bool]$notify=$true) {
 $p=Profile-From-UI
 $p | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
 $script:SavedProfile=Get-Content -LiteralPath $script:ProfileFile -Raw -Encoding UTF8|ConvertFrom-Json
 Set-Footer ('Profile saved for '+$p.account+'  -  Windows policy NOT applied')
 if($notify){Show-Notice 'Profile saved. No Windows registry restrictions were applied. Choose Apply Restrictions separately after confirming recovery.' 'Saved (no policy change)'}
}
function Start-RkaWorker([string]$scriptName,[string]$arguments='',[bool]$elevate=$true) {
 $path=Join-Path $script:AppRoot $scriptName
 if(-not(Test-Path -LiteralPath $path)){throw "Missing required backend: $scriptName. Extract the entire ZIP first."}
 # Only fixed, locally-shipped script filenames are accepted. Arguments are authored by this app; no input goes to a shell.
 $cmd='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$path+'" '+$arguments
 if($elevate){$p=Start-Process -FilePath $script:PowerShellExe -ArgumentList $cmd -Verb RunAs -Wait -PassThru -ErrorAction Stop}
 else{$p=Start-Process -FilePath $script:PowerShellExe -ArgumentList $cmd -Wait -PassThru -ErrorAction Stop}
 Write-RkaLog ('Worker: '+$scriptName+' exit='+$p.ExitCode)
 if($p.ExitCode -ne 0){throw "$scriptName exited with code $($p.ExitCode). Check the corresponding persistent log for the exact error."}
}
function Read-RkaLog([string]$path, [int]$tail=80) {
 if(-not(Test-Path -LiteralPath $path)){return 'No log file found at '+$path}
 return (@(Get-Content -LiteralPath $path -Tail $tail -ErrorAction Stop)-join "`r`n")
}
function Get-RegistrySnapshot([string]$sid) {
 # Read-only evidence from selected guest hive. Mount only when Windows has unloaded the guest hive.
 $base=[Microsoft.Win32.Registry]::Users
 $root=$base.OpenSubKey($sid,$false)
 $mountId=''
 if(-not $root){
  $wp=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop | Select-Object -First 1
  if(-not $wp -or -not $wp.LocalPath){throw 'Guest has no local Windows profile yet; sign into it once.'}
  $dat=Join-Path $wp.LocalPath 'NTUSER.DAT'
  if(-not(Test-Path -LiteralPath $dat)){throw 'NTUSER.DAT missing for guest profile.'}
  $mountId='RKA_WPF_READ_'+[Guid]::NewGuid().ToString('N')
  & reg.exe load "HKU\$mountId" $dat | Out-Null
  if($LASTEXITCODE -ne 0){throw 'Could not mount guest registry for read-only verification; sign out guest first.'}
  $root=$base.OpenSubKey($mountId,$false)
  if(-not $root){& reg.exe unload "HKU\$mountId" | Out-Null;throw 'Guest registry mounted but could not be opened.'}
 }
 try{
  $paths=@{
   Settings=@('Software\Microsoft\Windows\CurrentVersion\Policies\Explorer','NoControlPanel')
   Cmd=@('Software\Policies\Microsoft\Windows\System','DisableCMD')
   Registry=@('Software\Microsoft\Windows\CurrentVersion\Policies\System','DisableRegistryTools')
   Edge=@('Software\Policies\Microsoft\Edge\URLBlocklist','1')
   Chrome=@('Software\Policies\Google\Chrome\URLBlocklist','1')
  }
  $result=@{}
  foreach($key in $paths.Keys){
   $entry=$paths[$key];$sub=$root.OpenSubKey($entry[0],$false)
   try{if($sub -and $sub.GetValueNames() -contains $entry[1]){$result[$key]=[string]$sub.GetValue($entry[1])}else{$result[$key]=$null}}
   finally{if($sub){$sub.Dispose()}}
  }
  $approved=$root.OpenSubKey('Software\Policies\Microsoft\Edge\URLAllowlist',$false)
  try{$result.EdgeAllowCount=if($approved){@($approved.GetValueNames()).Count}else{0}}
  finally{if($approved){$approved.Dispose()}}
  $chromeAllowed=$root.OpenSubKey('Software\Policies\Google\Chrome\URLAllowlist',$false)
  try{$result.ChromeAllowCount=if($chromeAllowed){@($chromeAllowed.GetValueNames()).Count}else{0}}finally{if($chromeAllowed){$chromeAllowed.Dispose()}}
  return $result
 }finally{
  if($root){$root.Dispose()}
  if($mountId){
   [GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 150
   & reg.exe unload "HKU\$mountId" |Out-Null
   if($LASTEXITCODE -ne 0){Write-RkaLog "WARN: Unable to unmount read-only status hive $mountId"}
  }
 }
}
function Set-OneStatus([string]$name,$actual,[string]$expected,[bool]$desired,[string]$guest) {
 $ctrl=$script:Ui[$name]
 if($null -eq $actual){
  $ctrl.Text= $(if($desired){'Not applied'}else{'Off (no policy found)'})
  $color=$(if($desired){'#FF6979'}else{'#A0B3C4'})
  $tip="Guest: $guest`nRegistry restriction: absent`nRequested in checkbox: $desired`nOff means no matching restriction value was detected; this is a read-only observation."
 }elseif($actual -ceq $expected){
  $ctrl.Text='Applied';$color='#34E79B'
  $tip="Guest: $guest`nActual policy value: $actual`nRequested in checkbox: $desired`nThis is an observed registry value, not a simulation."
 }else{
  $ctrl.Text='Different value';$color='#F7BF58'
  $tip="Guest: $guest`nActual value: $actual (expected $expected)`nRequested in checkbox: $desired"
 }
 $ctrl.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
 $ctrl.ToolTip=$tip
}
function Refresh-PolicyStatuses {
 try{
  $g=Selected-Guest
  $values=Get-RegistrySnapshot $g.SID
  Set-OneStatus 'StatusSettings' $values.Settings '1' ([bool]$script:Ui.ChkSettings.IsChecked) $g.Name
  Set-OneStatus 'StatusCmd' $values.Cmd '2' ([bool]$script:Ui.ChkCmd.IsChecked) $g.Name
  Set-OneStatus 'StatusRegistry' $values.Registry '1' ([bool]$script:Ui.ChkRegistry.IsChecked) $g.Name
  # Chrome and Edge browser policies are inspected separately; neither proves other browsers are blocked.
  Set-OneStatus 'StatusEdge' $values.Edge '*' ([bool]$script:Ui.ChkEdge.IsChecked) $g.Name
  if([bool]$script:Ui.ChkEdge.IsChecked -and ($values.Chrome -ne '*' -or $values.ChromeAllowCount -lt 1 -or $values.Edge -ne '*' -or $values.EdgeAllowCount -lt 1)){
   $script:Ui.StatusEdge.Text='Browser policy incomplete';$script:Ui.StatusEdge.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#F8BE5A')
   $script:Ui.StatusEdge.ToolTip='Chrome block='+$values.Chrome+' allow entries='+$values.ChromeAllowCount+'; Edge block='+$values.Edge+' allow entries='+$values.EdgeAllowCount+'; review browser policies after sign-out/sign-in.'
  }
  if($values.Edge -eq '*' -and $values.EdgeAllowCount -lt 1){
   $script:Ui.StatusEdge.Text='Edge allowlist missing'
   $script:Ui.StatusEdge.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#F8BE5A')
   $script:Ui.StatusEdge.ToolTip='Edge URLBlocklist exists but no URLAllowlist values were observed. Browsing may be unusable.'
  }
  $summary="Registry values read for $($g.Name). Applied = policy value exists; browser/app bypass protection is NOT verified."
  $script:Ui.PolicySummary.Text=$summary
  Set-Footer ('Registry status checked for '+$g.Name)
 }catch{
  foreach($name in @('StatusSettings','StatusCmd','StatusRegistry','StatusEdge')){
   $c=$script:Ui[$name];$c.Text='Unable to verify';$c.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#F8BE5A');$c.ToolTip=$_.Exception.Message
  }
  $script:Ui.PolicySummary.Text=$(if($script:GuestAccounts.Count -eq 0){'No guest account found. Create a standard guest account first.'}else{'Cannot read guest registry: '+$_.Exception.Message})
  Write-RkaLog ('Registry status failure: '+$_.Exception.Message)
 }
}
function Check-RecoverySnapshot {
 if(Test-Path -LiteralPath $script:RecoveryPointer){
  $script:Ui.PolicySummary.Text += "`nExisting active recovery snapshot detected. Restore previous settings before applying a new snapshot."
  $script:Ui.RestorePolicyButton.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#FFBE54')
 }
}
function Handle-Apply {
 try{
  Assert-Admin
  $g=Selected-Guest
  $p=Profile-From-UI
  if(-not($p.blockSettings -or $p.blockCmd -or $p.blockRegistry -or $p.restrictEdge)){throw 'Select at least one implemented guest restriction first.'}
  if($p.restrictEdge -and @($p.urls).Count -lt 1){throw 'Browser restriction requires a reviewed allowlist URL.'}
  if(Test-Path -LiteralPath $script:RecoveryPointer){throw 'An earlier guest policy snapshot still exists. Choose Restore Previous Settings first. Never delete its files manually.'}
  $ok=Ask-YesNo ("Apply persistent registry restrictions to guest $($g.Name)?`n`nThey will remain until an administrator restores the snapshot. Verify separate administrator sign-in and Emergency-Restore.cmd first. Keep your separate administrator recovery available.") 'Guest policy  -  recovery required'
  if(-not $ok){return}
  $phrase=[Microsoft.VisualBasic.Interaction]::InputBox('Type RESTORE READY to confirm you have a separate working administrator account and know how to restore guest restrictions.','Administrator recovery confirmation','')
  if($phrase -cne 'RESTORE READY'){Set-Footer 'Apply canceled; confirmation not entered';return}
  Save-Profile $false
  Start-RkaWorker 'PolicyWorker.ps1' ('-Operation Persistent -TargetSid "'+$g.SID+'" -ProfilePath "'+$script:ProfileFile+'"')
  Refresh-PolicyStatuses; Check-RecoverySnapshot
  Show-Notice "Policy worker finished successfully. Verify status and sign in to $($g.Name) to test Windows behavior. Separate administrator recovery remains required." 'Policy applied'
 }catch{Show-Failure $_.Exception.Message 'Apply restrictions failed';Check-RecoverySnapshot}
}
function Handle-Restore {
 try{
  Assert-Admin
  if(-not(Test-Path -LiteralPath $script:RecoveryPointer)){Show-Notice 'No active recovery snapshot is registered. No changes made.' 'No snapshot';return}
  if(-not(Ask-YesNo 'Restore the prior guest registry values from the active protected snapshot? Windows may need guest sign-out/sign-in afterward.' 'Restore guest restrictions')){return}
  Start-RkaWorker 'PolicyWorker.ps1' '-Operation Restore'
  Refresh-PolicyStatuses
  Show-Notice 'Snapshot restoration completed and registry keys verified. Sign out/in as the guest to refresh Windows policy.' 'Guest policy restored'
 }catch{Show-Failure ($_.Exception.Message+"`n`nSee C:\ProgramData\RKA-Lockdown-Agent\Recovery\worker.log") 'Restore failed'}
}
function Handle-Verify {
 try{
  $g=Selected-Guest
  $p=Profile-From-UI
  if(-not($p.blockSettings -or $p.blockCmd -or $p.blockRegistry -or $p.restrictEdge)){
   Refresh-PolicyStatuses
   Show-Notice 'No requested restrictions selected. Status still shows the guest registry values where readable.' 'Registry status'
   return
  }
  Save-Profile $false
  Start-RkaWorker 'PolicyWorker.ps1' ('-Operation Verify -TargetSid "'+$g.SID+'" -ProfilePath "'+$script:ProfileFile+'"')
  $path=Join-Path $script:DataRoot 'verification.json'
  if(-not(Test-Path $path)){throw 'Backend verification report not created.'}
  $report=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
  if($report.sid -ne $g.SID){throw 'Verification report SID does not match the selected guest.'}
  Refresh-PolicyStatuses
  $summary=@('Guest: '+$g.Name,'Registry entries matching selected restrictions: '+$report.matchCount+'/'+$report.total,'')
  if($report.groups){foreach($prop in $report.groups.PSObject.Properties){$summary+=($prop.Name+': '+$prop.Value.matched+'/'+$prop.Value.total+' entries match')}}
  $summary+=@('','These results verify registry entries only, NOT whether sites load or applications are blocked.','To inspect all individual keys, see verification.json under %LOCALAPPDATA%\RKA-Lockdown-Agent.','Browser policy changes require guest browser restart/sign-out and a new policy snapshot after Restore.')
  Show-Notice ($summary -join "`n") 'Guest restriction verification'
 }catch{Show-Failure $_.Exception.Message 'Verification failed';Refresh-PolicyStatuses}
}
function Check-Heartbeat {
 try{
  Start-RkaWorker 'Heartbeat-Ui-Status.ps1' '' $true
  $detail=Read-RkaLog $script:HeartbeatStatusFile 100
  $script:Ui.ConnectionReport.Text=$detail
  $device='Device status: local report available'
  if($detail -match '(?m)^DEVICE:\s*(.+)$'){$device=$Matches[1].Trim()}
  $script:Ui.HeartbeatLabel.Text='Connected: '+$device
  $script:Ui.HeartbeatLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#7AE6FA')
  Set-Footer 'Local Lovable heartbeat inspected; check server-side Online in Partner Dashboard'
 }catch{$script:Ui.ConnectionReport.Text="Check failed: $($_.Exception.Message)";Show-Failure $_.Exception.Message 'Connection check failed'}
}
function Refresh-ChromeQuickStatus {
 try{
  $task=Get-ScheduledTask -TaskName 'RKA-Guest-Chrome-Portal' -ErrorAction SilentlyContinue
  $failure=$false
  if(Test-Path -LiteralPath $script:ChromeStatusFile){
   $msg=Read-RkaLog $script:ChromeStatusFile 30
   $failure=($msg -match '(?m)^Outcome:\s*ERROR')
  }
  if($failure){$script:Ui.ChromeQuickLabel.Text='Setup error - view log';$color='#FF7289'}
  elseif($task){$script:Ui.ChromeQuickLabel.Text='Task configured - '+$task.State;$color='#38E5A3'}
  else{$script:Ui.ChromeQuickLabel.Text='Not configured';$color='#A6B6C8'}
  $script:Ui.ChromeQuickLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
 }catch{$script:Ui.ChromeQuickLabel.Text='Status unavailable';Write-RkaLog $_.Exception.Message}
}
function Check-Chrome([string]$operation) {
 try{
  Assert-Admin
  $g=Selected-Guest
  $url=$script:Ui.ChromeUrl.Text.Trim()
  if($operation -eq 'Install'){
   if(-not(Check-Url $url)){throw 'Invalid portal URL. Must use http(s).'}
   $delay=0;if(-not[int]::TryParse($script:Ui.ChromeDelay.Text,[ref]$delay) -or $delay -lt 0 -or $delay -gt 120){throw 'Delay must be an integer from 0 to 120.'}
   $mode=([System.Windows.Controls.ComboBoxItem]$script:Ui.ChromeMode.SelectedItem).Content
   Start-RkaWorker 'Chrome-Portal-Setup.ps1' ('-Action Install -UserName "'+$g.Name+'" -Url "'+$url+'" -Mode '+$mode+' -Delay '+$delay)
  } else {Start-RkaWorker 'Chrome-Portal-Setup.ps1' ('-Action '+$operation)}
  $script:Ui.ChromeReport.Text=Read-RkaLog $script:ChromeStatusFile 100
  Refresh-ChromeQuickStatus
  Set-Footer ('Chrome '+$operation+' completed; guest sign-in test required')
 }catch{
  $script:Ui.ChromeReport.Text=Read-RkaLog $script:ChromeStatusFile 100
  Refresh-ChromeQuickStatus
  Set-Footer ('Chrome '+$operation+' failed: '+$_.Exception.Message) $true
  Show-Failure ($_.Exception.Message+"`n`n"+$script:Ui.ChromeReport.Text) 'Chrome Startup failed'
 }
}
function Run-Health {
 try{
  $target=Join-Path $script:AppRoot 'Run-Preflight.ps1'
  $reportDir=Join-Path $env:TEMP 'RKA-Companion';if(-not(Test-Path $reportDir)){New-Item $reportDir -ItemType Directory -Force|Out-Null}
  $file=Join-Path $reportDir 'health-latest.json'
  # Read-only diagnostic script, no UAC operation needed; capture stdout and stderr permanently.
  $e=Join-Path $reportDir 'health-last-error.txt'
  $p=Start-Process -FilePath $script:PowerShellExe -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$target+'"') -RedirectStandardOutput $file -RedirectStandardError $e -Wait -PassThru
  $script:Ui.HealthReport.Text=$(if(Test-Path $file){Get-Content -LiteralPath $file -Raw -Encoding UTF8}else{'No output generated.'})
  if($p.ExitCode -ne 0){$script:Ui.HealthReport.Text+="`r`nERROR:`r`n"+(Read-RkaLog $e 50);throw 'Diagnostic exited with code '+$p.ExitCode}
  Set-Footer 'Local system preflight completed'
 }catch{Show-Failure $_.Exception.Message 'Diagnostics failed'}
}
function Export-Profile {
 try{
  $dialog=New-Object Microsoft.Win32.SaveFileDialog
  $dialog.FileName='RKA-Guest-Profile.json';$dialog.Filter='JSON profile (*.json)|*.json';$dialog.OverwritePrompt=$true
  if($dialog.ShowDialog($script:Window) -ne $true){return}
  $p=Profile-From-UI
  $export=[ordered]@{schema='RKA-PROFILE-PORTABLE-v1';account=$p.account;intranet=$p.intranet;urls=$p.urls;blockSettings=$p.blockSettings;blockCmd=$p.blockCmd;blockRegistry=$p.blockRegistry;restrictEdge=$p.restrictEdge}
  $export|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $dialog.FileName -Encoding UTF8
  Show-Notice "Exported a profile WITHOUT Lovable credentials or Windows passwords.`n`n$($dialog.FileName)" 'Profile exported'
 }catch{Show-Failure $_.Exception.Message 'Export failed'}
}
function Import-Profile {
 try{
  $dialog=New-Object Microsoft.Win32.OpenFileDialog;$dialog.Filter='JSON profile (*.json)|*.json'
  if($dialog.ShowDialog($script:Window) -ne $true){return}
  $p=Get-Content -LiteralPath $dialog.FileName -Raw -Encoding UTF8|ConvertFrom-Json
  if($p.schema -ne 'RKA-PROFILE-PORTABLE-v1'){throw 'Only profiles created by the RKA WPF Export Profile command can be imported.'}
  if(-not(Check-Url ([string]$p.intranet))){throw 'Invalid intranet URL in imported profile.'}
  $script:Ui.ChkSettings.IsChecked=[bool]$p.blockSettings
  $script:Ui.ChkCmd.IsChecked=[bool]$p.blockCmd
  $script:Ui.ChkRegistry.IsChecked=[bool]$p.blockRegistry
  $script:Ui.ChkEdge.IsChecked=[bool]$p.restrictEdge
  $script:Ui.GamePortalUrl.Text=[string]$p.intranet
  $script:Ui.ChromeUrl.Text=[string]$p.intranet
  $validUrls=@()
  foreach($url in @($p.urls)){if(-not(Check-Url ([string]$url))){throw "Invalid Edge allowed URL in imported profile: $url"};$validUrls+=([string]$url)}
  $script:ApprovedUrls=$validUrls
  Refresh-PolicyStatuses
  Show-Notice 'Imported selections into this window ONLY. No policy has been saved or applied. Check the guest account, then Save Profile Only.' 'Profile imported'
 }catch{Show-Failure $_.Exception.Message 'Import failed'}
}
function Open-Legacy {
 try{
  $path=Join-Path $script:AppRoot 'RKA-Lockdown.ps1'
  Start-Process -FilePath $script:PowerShellExe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -STA -File "'+$path+'"') -Verb RunAs
  Set-Footer 'Legacy WinForms Control Center launched separately'
 }catch{Show-Failure $_.Exception.Message 'Legacy UI failed'}
}
function Open-LogFile([string]$path) {
 if(Test-Path -LiteralPath $path){Start-Process notepad.exe -ArgumentList ('"'+$path+'"')}
 else{Show-Notice "No log has been written yet:`n$path" 'Log unavailable'}
}
function Show-Page([string]$pageName) {
 foreach($name in @('Policies','Games','Lovable','Chrome','Diagnostics','Settings')){
  $script:Ui['Page'+$name].Visibility=if($name -eq $pageName){[System.Windows.Visibility]::Visible}else{[System.Windows.Visibility]::Collapsed}
  $nav=$script:Ui['Nav'+$name]
  if($name -eq $pageName){$nav.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#073B54');$nav.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#14CDF1')}
  else{$nav.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0B1A29');$nav.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#245169')}
 }
}

function Invoke-AutologonSetup([string]$action) {
 try {
  Assert-Admin
  $guest=Selected-Guest
  $scriptFile=Join-Path $script:AppRoot 'Autologon-Setup.ps1'
  $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$scriptFile,'-Action',$action,'-GuestName',$guest.Name,'-GuestSid',$guest.SID)
  $out=& powershell.exe @args 2>&1 | Out-String
  $script:Ui.AutologonReport.Text=($out.Trim())
  if($LASTEXITCODE -ne 0){throw ('Autologon setup failed: '+$out)}
  if($action -eq 'Configure'){Show-Notice 'Microsoft Sysinternals Autologon has opened. Enter the selected guest password there and click Enable. Reboot later to verify. RKA never collects the password.' 'Guest auto sign-in'}
 }catch{Show-Failure $_.Exception.Message 'Automatic sign-in';$script:Ui.AutologonReport.Text=$_.Exception.Message}
}


function Show-CompanionHelp {
 $helpText=@'
RKA WINDOWS COMPANION - HELP AND DOCUMENTATION

GETTING STARTED
Launch Retro Knights PC Control Center.vbs as administrator. Choose a local STANDARD guest account. Save Profile Only stores settings without applying them. Apply Restrictions creates a protected recovery snapshot before making changes. Refresh Policy Status checks registry evidence, not actual app behavior. Save Profile Only records chosen checkboxes/allowlist without changing Windows. Apply Restrictions writes those selected settings and creates a protected recovery snapshot. Restore Previous Settings rolls back that guest-policy snapshot.

GUEST RESTRICTIONS
Control Panel: blocks Settings and Control Panel for the selected guest.
Command Prompt: uses Windows guest policy to restrict cmd.exe; it is not full application allowlisting.
Registry Editor: restricts regedit for the selected guest.
Chrome / Edge: browser URL policies block general websites, with configured approved-site exceptions. Browser restrictions DO NOT block internet access from Steam, Epic, or other applications. Browser policy diagnostics are not proof that websites load.
USB storage: device-wide policy (including administrators). USB keyboards, mice and controllers should remain unaffected. USB block and restore are separate from guest policy snapshots; use the USB Restore button to revert USB changes, and reconnect removable drives if needed. The guest Emergency Restore button does not itself restore USB storage.

APPROVED WEBSITES
The default intranet is http://rkaserver/. You may edit it and add any custom hostnames. Old saved profiles are preserved and are not silently rewritten. To change an applied allowlist, restore the existing protected snapshot first, edit approved websites, save, then reapply. Test from the guest session after sign-out/sign-in. edge://policy and chrome://policy can help troubleshoot effective policies.

AUTO SIGN-IN
Settings > Configure Sysinternals Autologon launches Microsoft's utility. The Companion never collects the password. Use a dedicated guest password. Windows auto sign-in is separate from Chrome's timed intranet startup.

CHROME STARTUP
Chrome Startup schedules the intranet page to open when the selected guest signs in. The startup delay is separate from any remote restart grace period. The Chrome Startup Portal URL is also used when you deploy the guest LAN Portal desktop shortcut. Game Installers LAN URL stays synchronized with it. Create Desktop Shortcut installs the administrator Companion launcher, not a web shortcut.

LOVABLE REMOTE MANAGEMENT
v1.0.8: Remote individual policy and website updates journal original states into the active protected full-policy recovery snapshot; test on ONE PC and keep recovery accessible. v1.0.8: Remote individual policy and website updates journal original states into the active protected full-policy recovery snapshot; test on ONE PC and keep recovery accessible. The background remote agent can work while the administrator window is closed. Local administrator opt-in is required for remote changes. Background agent v1.0 supports typed remote commands, individual guest policy changes, approved browser sites, Chrome auto-launch, wallpaper staging, announcements, and power scheduling when locally enabled. Desktop UI and installed background task versions are separate; verify reported agent version and capability list in Lovable after upgrading. Remote wallpaper and announcement delivery require a logged-in guest session and must be tested on the laptop. Task Manager restriction is deferred.

EMERGENCY RECOVERY
From an administrator account run Emergency Restore.cmd in the top folder. Keep a working local admin sign-in. Never delete protected recovery snapshots manually. Registry restoration may require guest sign-out and sign-in.

STATUS DEFINITIONS
Applied/match = expected registry setting observed, not necessarily tested in the actual application. Off (no policy found) = no matching restriction value detected. Incomplete = some expected registry values missing. Unverified = cannot confirm from current evidence. Test each feature in the guest account.

RELEASE
Announcement timeout: Windows controls notification banner visibility. On the GUEST account, Settings > Accessibility > Visual effects > Dismiss notifications after this amount of time > 30 seconds. The agent requests 30 seconds, but Windows may show a shorter banner.

Windows Companion v1.0.8. Verify browser allowlists, guest notifications, and local recovery on each target PC before arcade rollout. Only actual agent capabilities reported to Lovable are eligible for remote use.
'@
 $dialog=New-Object System.Windows.Window
 $dialog.Title='RKA Companion - Help and Documentation'
 $dialog.Width=880;$dialog.Height=700;$dialog.MinWidth=620;$dialog.MinHeight=430
 $dialog.WindowStartupLocation='CenterOwner';$dialog.Owner=$script:Window
 $dialog.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#08121F')
 $layout=New-Object System.Windows.Controls.DockPanel
 $content=New-Object System.Windows.Controls.TextBox
 $content.Text=$helpText;$content.IsReadOnly=$true;$content.AcceptsReturn=$true;$content.TextWrapping='Wrap'
 $content.VerticalScrollBarVisibility='Auto';$content.HorizontalScrollBarVisibility='Auto'
 $content.Margin='12';$content.Padding='14';$content.FontSize=14
 $content.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#EAF5FF')
 $content.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0A2032')
 [void]$layout.Children.Add($content)
 $dialog.Content=$layout
 [void]$dialog.ShowDialog()
}

function Exit-App {
 $script:AllowExit=$true
 if($script:TrayIcon){$script:TrayIcon.Visible=$false;$script:TrayIcon.Dispose();$script:TrayIcon=$null}
 if($script:Window){$script:Window.Close()}
}
function Setup-Tray {
 try {
  $tray=New-Object System.Windows.Forms.NotifyIcon
  $icon=Join-Path $script:AppRoot 'assets\rka.ico'
  if(Test-Path $icon){$tray.Icon=[System.Drawing.Icon]::new($icon)}else{$tray.Icon=[System.Drawing.SystemIcons]::Application}
  $tray.Text='RKA Windows Companion v0.4.6'
  $menu=New-Object System.Windows.Forms.ContextMenuStrip
  [void]$menu.Items.Add('Open Companion')
  [void]$menu.Items.Add('Exit Companion')
  $menu.Items[0].Add_Click({$script:Window.Show();$script:Window.WindowState='Normal';$script:Window.Activate()})
  $menu.Items[1].Add_Click({Exit-App})
  $tray.ContextMenuStrip=$menu
  $tray.Add_DoubleClick({$script:Window.Show();$script:Window.WindowState='Normal';$script:Window.Activate()})
  $tray.Visible=$true
  $script:TrayIcon=$tray
 }catch{Write-RkaLog ('Tray setup failed: '+$_.Exception.Message)}
}
function Update-UsbStatus {
 try {
  $path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices'
  $value=(Get-ItemProperty -LiteralPath $path -Name 'Deny_All' -ErrorAction SilentlyContinue).Deny_All
  $state=if($value -eq 1){'Policy applied (device-wide)'}else{'USB block not applied (device-wide)'}
  $script:Ui.UsbStatus.Text=$state
  $script:Ui.UsbStatus.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($value -eq 1){'#32E7A1'}else{'#F8BE5A'}))
  $script:Ui.UsbStatus.ToolTip='Observed HKLM removable-storage policy only; requires actual USB device testing. Affects all user accounts.'
 }catch{$script:Ui.UsbStatus.Text='Unable to verify'}
}
function Get-AgentState {
 $remote=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
 $remoteCfg=Join-Path $remote 'remote-config.json'
 $agentHealth=Join-Path $remote 'agent-health.json'
 $t=Get-ScheduledTask -TaskName 'RKA-Remote-Commands' -ErrorAction SilentlyContinue
 $enabled=$false;$usbEnabled=$false
 if(Test-Path -LiteralPath $remoteCfg){try{$cfg=Get-Content -LiteralPath $remoteCfg -Raw|ConvertFrom-Json;$enabled=[bool]$cfg.allowChanges;$usbEnabled=[bool]$cfg.allowUsb}catch{}}
 # Read installed payload independently of last authenticated remote check-in.
 # Do not present the GUI release as proof that SYSTEM tasks were upgraded.
 $installedPayload='Unknown'
 $agentScript=Join-Path $remote 'Remote-Agent.ps1'
 if(Test-Path -LiteralPath $agentScript){
  try { $head=Get-Content -LiteralPath $agentScript -TotalCount 14 -ErrorAction Stop
   $line=$head | Where-Object {$_ -match '^\$agentVersion='} | Select-Object -First 1
   if($line -match "'([0-9]+\.[0-9]+\.[0-9]+)'$"){$installedPayload=$matches[1]}
  }catch{}
 }
 $agentVersion='Unknown';$healthy=$false;$lastPoll='never'
 if(Test-Path -LiteralPath $agentHealth){
  try{
   $h=Get-Content -LiteralPath $agentHealth -Raw -Encoding UTF8|ConvertFrom-Json
   $agentVersion=[string]$h.version
   $lastPoll=[string]$h.confirmedUtc
   $healthy=(($t -ne $null) -and ($t.State -ne 'Disabled') -and ([datetimeoffset]::UtcNow-[datetimeoffset]::Parse($lastPoll)).TotalMinutes -le 4)
  }catch{$agentVersion='Unverified';$healthy=$false}
 }
 if(-not $t){$healthy=$false; if($agentVersion -eq 'Unknown'){$agentVersion='Not installed'}}
 return [pscustomobject]@{Version=$agentVersion;PayloadVersion=$installedPayload;Healthy=$healthy;RemoteEnabled=$enabled;UsbEnabled=$usbEnabled;Installed=($null -ne $t);LastPoll=$lastPoll}
}
function Refresh-AgentIndicators {
 $a=Get-AgentState
 $script:Ui.FooterVersion.Text='Companion v'+$script:AppVersion+'  |  Agent '+$(if($a.Version -match '^\d+\.\d+\.\d+$'){'v'+$a.Version}else{$a.Version})+$(if($script:UpdateAvailableVersion){'  |  UPDATE v'+$script:UpdateAvailableVersion+' available'}else{''})
 $script:Ui.FooterVersion.ToolTip='Actual installed agent version is confirmed by its last successful authenticated command poll. Last poll: '+$a.LastPoll
 $label=if(-not $a.Installed){'Agent not installed'}elseif(-not $a.Healthy){'Agent status stale / unverified'}elseif($a.RemoteEnabled){'Remote changes ENABLED'}else{'Remote changes OFF'}
 $script:Ui.RemoteConsentLabel.Text=$label
 $brush=if(-not $a.Installed -or -not $a.Healthy){'#F8BE5A'}elseif($a.RemoteEnabled){'#32E7A1'}else{'#9BB1C4'}
 $script:Ui.RemoteConsentLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($brush)
 $usbText=if(-not $a.Installed){'USB remote: Agent not installed'}elseif(-not $a.RemoteEnabled){'USB remote: Remote Changes must be enabled first'}elseif($a.UsbEnabled){'USB remote: Authorized locally (await agent check-in)'}else{'USB remote: Not authorized locally'}
 if($a.UsbEnabled -and $a.Healthy -and $a.Version -eq $a.PayloadVersion){$usbText='USB remote: Local permission ENABLED; verify capability in Lovable'}
 $script:Ui.RemoteUsbConsentLabel.Text=$usbText
 $script:Ui.RemoteUsbConsentLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($a.UsbEnabled -and $a.RemoteEnabled){'#32E7A1'}else{'#F8BE5A'}))
 $script:Ui.FooterVersion.ToolTip+=' | Installed agent payload: '+$a.PayloadVersion+' | Remote USB permission: '+$a.UsbEnabled
 $script:Ui.FooterVersion.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($a.Healthy){'#32E7A1'}else{'#F8BE5A'}))
}
function Invoke-UpdaterProcess([string]$action,[string]$channel='Stable',[string]$zip='') {
 Assert-Admin
 $stdout=Join-Path $script:DataRoot 'updater-stdout.log'
 $stderr=Join-Path $script:DataRoot 'updater-stderr.log'
 $args='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $script:AppRoot 'Update-Manager.ps1')+'" -Action '+$action+' -Channel '+$channel
 if($zip){$args+=' -ZipPath "'+$zip+'"'}
 $process=Start-Process -FilePath $script:PowerShellExe -ArgumentList $args -Wait -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr -ErrorAction Stop
 $out=(Get-Content -LiteralPath $stdout -Raw -ErrorAction SilentlyContinue)+"`r`n"+(Get-Content -LiteralPath $stderr -Raw -ErrorAction SilentlyContinue)
 $script:Ui.UpdateReport.Text=$out
 if($process.ExitCode -ne 0){throw ('Updater '+$action+' failed (exit '+$process.ExitCode+'). See Software Updates output.')}
 return $out
}
function Current-UpdateChannel {if($script:Ui.UpdateIncludePilots.IsChecked){return 'Pilot'}return 'Stable'}
function Invoke-UpdateCheck {
 try{
  $script:Ui.UpdateReport.Text='Checking public GitHub releases...'
  $out=Invoke-UpdaterProcess 'Check' (Current-UpdateChannel)
  if($out -match 'UPDATE AVAILABLE: v(\d+\.\d+\.\d+)'){$script:UpdateAvailableVersion=$matches[1]}
  else{$script:UpdateAvailableVersion=$null}
  Refresh-AgentIndicators
  Set-Footer 'Public GitHub release check completed. No software installed.'
 }catch{$script:Ui.UpdateReport.Text+="`r`n"+$_.Exception.Message;Show-Failure $_.Exception.Message 'Update check failed'}
}
function Invoke-PublicUpdate {
 try{
  Assert-Admin
  $channel=Current-UpdateChannel
  if(-not(Ask-YesNo ("Check GitHub ($channel channel) and download a newer RKA Companion release if one exists?`n`nThe ZIP will be checked against the public GitHub asset SHA-256. An additional confirmation is required before installation.`n`nNo GitHub account or token required.") 'Download RKA update')){return}
  $script:Ui.UpdateReport.Text='Downloading and verifying GitHub release...'
  $out=Invoke-UpdaterProcess 'Download' $channel
  if($out -notmatch 'STAGED RELEASE: (v\d+\.\d+\.\d+(?:-PILOT)?)'){throw 'Verified download was not reported by the updater.'}
  $version=$matches[1]
  if(-not(Ask-YesNo ("The official public GitHub release $version was downloaded and its SHA-256 matched GitHub metadata.`n`nInstall on this PC now? This will update the Companion, upgrade enrolled agent tasks, and back up replaced files. Close any other open Companion windows after installation.`n`nThe update is NOT independently code-signed. Proceed only if you trust the GitHub release repository.") 'Install verified RKA update')){Set-Footer ('Verified '+$version+' staged; installation was not approved.');return}
  $out=Invoke-UpdaterProcess 'InstallStaged' $channel
  if($out -notmatch 'UPDATE INSTALLED:'){throw 'Updater did not confirm installation.'}
  Show-Notice 'Update installed. Close and reopen the Companion, then check Lovable agent authenticated version before updating other arcade PCs.' 'RKA update completed'
 }catch{$script:Ui.UpdateReport.Text+="`r`n"+$_.Exception.Message;Show-Failure $_.Exception.Message 'Public update failed'}
}
function Update-RemoteStatus {
 $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent'
 $remote=Join-Path $root 'RemoteControl'
 $text="Control Center: v$($script:AppVersion)"
 $a=Get-AgentState
 $text+="`r`nInstalled SYSTEM agent file: v$($a.PayloadVersion) (from protected Remote-Agent.ps1)"
 $text+="`r`nLast authenticated agent poll: v$($a.Version) at $($a.LastPoll)"
 $text+="`r`nRemote Changes: $($a.RemoteEnabled); USB remote permission: $($a.UsbEnabled)"
 if($a.PayloadVersion -ne 'Unknown' -and $a.Version -ne $a.PayloadVersion){$text+="`r`nWARNING: Installed agent file and confirmed poll differ; use Install / Repair Agent, then refresh. Do not treat the GUI version as the installed agent."}
 foreach($spec in @(@('RKA-Lockdown-ReadOnlyHeartbeat','Heartbeat'),@('RKA-Remote-Commands','RemoteControl'))){
  $task=Get-ScheduledTask -TaskName $spec[0] -ErrorAction SilentlyContinue
  $text+="`r`n$($spec[0]): " + $(if($task){[string]$task.State}else{'Not installed'})
  if($task){$text+="`r`n  Script path: " + [string]$task.Actions[0].Arguments}
 }
 $health=Join-Path $remote 'agent-health.json'
 if(Test-Path -LiteralPath $health){
  try{$j=Get-Content -LiteralPath $health -Raw|ConvertFrom-Json;$text+="`r`nAgent authenticated poll: v$($j.version) at $($j.confirmedUtc)"}
  catch{$text+="`r`nAgent health: unreadable"}
 }else{$text+="`r`nAgent authenticated poll: Not yet confirmed"}
 $file=Join-Path $remote 'remote-status.txt'
 $log=Join-Path $remote 'remote.log'
 if(Test-Path -LiteralPath $file){$text+="`r`n"+(Get-Content -LiteralPath $file -Raw -ErrorAction SilentlyContinue)}
 if(Test-Path -LiteralPath $log){$text+="`r`nRecent events:`r`n"+((Get-Content -LiteralPath $log -Tail 5 -ErrorAction SilentlyContinue)-join "`r`n")}
 $script:Ui.RemoteReport.Text=$text
 Refresh-AgentIndicators
}
function Invoke-RemoteSetup([string]$operation) {
 try {
  Assert-Admin
  if($operation -in @('Install','Upgrade')){
   if(-not(Ask-YesNo 'Install or repair BOTH SYSTEM background tasks (heartbeat and remote agent). This will preserve your existing Lovable enrollment and local consent settings. The remote agent polls the Lovable command endpoint. Diagnostics are read-only; remote restart and policy changes stay OFF until separately enabled on this PC. Existing heartbeat token is reused, never displayed.' 'Enable remote diagnostics')){return}
   $guest=$null;try{$guest=Selected-Guest}catch{}
   $p=Join-Path $script:DataRoot 'profile.json'
   if($guest){Save-Profile $false}
   $args='-Action Upgrade'
   if(Test-Path -LiteralPath $p){$args+=' -ProfilePath "'+$p+'"'}
  }elseif($operation -eq 'EnableChanges'){
   if(-not(Ask-YesNo 'Permit REMOTE restart and guest-only Apply/Restore from the verified Lovable owner admin? There is no extra confirmation when a remote command later arrives. Existing separate Windows administrator recovery is essential.' 'Enable remote changes')){return}
   $typed=[Microsoft.VisualBasic.Interaction]::InputBox('Type ENABLE REMOTE CHANGES to confirm that owner-issued remote restarts and guest registry-policy modifications may take place unattended.','Remote operations - local opt-in','')
   if($typed -cne 'ENABLE REMOTE CHANGES'){return}
   $args='-Action EnableChanges'
  }elseif($operation -eq 'EnableUsb'){
   $a=Get-AgentState
   if(-not $a.RemoteEnabled){throw 'Enable Remote Changes locally before authorizing remote USB commands.'}
   if(-not(Ask-YesNo 'Authorize Lovable to BLOCK or RESTORE USB storage on this WHOLE PC, including the administrator account? This does NOT block USB now. You must keep an independent administrator login and test RESTORE using a physical flash drive. Continue?' 'Authorize system-wide USB control')){return}
   $typed=[Microsoft.VisualBasic.Interaction]::InputBox('Type ALLOW REMOTE USB to authorize remote USB storage commands. This affects ALL Windows users.','Separate local USB opt-in','')
   if($typed -cne 'ALLOW REMOTE USB'){Set-Footer 'Remote USB authorization canceled';return}
   $args='-Action EnableUsb'
  }elseif($operation -eq 'DisableUsb'){
   if(-not(Ask-YesNo 'Withdraw permission for NEW remote USB storage actions? This will NOT restore a USB block already active on this PC. Use Policies -> USB Restore separately to undo an applied block.' 'Disable remote USB permission')){return}
   $args='-Action DisableUsb'
  }elseif($operation -eq 'SyncProfile'){
   $guest=Selected-Guest;Save-Profile $false
   $args='-Action SyncProfile -ProfilePath "'+$script:ProfileFile+'"'
  }else{$args='-Action '+$operation}
  Start-RkaWorker 'Remote-Setup.ps1' $args
  Update-RemoteStatus
  $a=Get-AgentState
  if($operation -in @('Install','Upgrade') -and (-not $a.Healthy -or $a.Version -ne $script:AppVersion -or $a.PayloadVersion -ne $script:AppVersion)){
   Show-Notice ('Both background tasks were processed, but CURRENT agent confirmation is not complete. Installed agent file: '+$a.PayloadVersion+'; last authenticated agent: '+$a.Version+'. Check Remote Status, confirm the task and network, and only then approve the version in Lovable.') 'Agent upgrade needs verification'
  }else{
   Show-Notice ('Remote management action completed: '+$operation+'. Review the remote status box and refresh Lovable after an authenticated poll.') 'Remote setup'
  }  }catch {Update-RemoteStatus;Show-Failure $_.Exception.Message 'Remote management setup failed'}
}
try {
 if(-not(Test-Path $script:DataRoot)){New-Item -Path $script:DataRoot -ItemType Directory -Force|Out-Null}
 Add-Type -AssemblyName PresentationFramework
 Add-Type -AssemblyName PresentationCore
 Add-Type -AssemblyName WindowsBase
 Add-Type -AssemblyName System.Xaml
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 Add-Type -AssemblyName Microsoft.VisualBasic
 Assert-Admin
 $created=$false
 $script:Mutex=[System.Threading.Mutex]::new($true,'Local\RKA.Companion.WPF.v040',[ref]$created)
 $script:MutexAcquired=$created
 if(-not $created){[System.Windows.MessageBox]::Show('RKA WPF Companion is already running; open its system tray icon.','Already running')|Out-Null;exit 0}
 $reader=[System.Xml.XmlReader]::Create((Join-Path $script:AppRoot 'RKA-Window.xaml'))
 try{$script:Window=[System.Windows.Markup.XamlReader]::Load($reader)}finally{$reader.Dispose()}
 # Fit smaller laptop displays while preserving a comfortable minimum layout.
 $work=[System.Windows.SystemParameters]::WorkArea
 if($work.Width -gt 1120){$script:Window.Width=[math]::Min($script:Window.Width,$work.Width-28)}
 if($work.Height -gt 750){$script:Window.Height=[math]::Min($script:Window.Height,$work.Height-35)}
 $script:Ui=@{}
 foreach($name in @('CopyAdminShortcutsButton','GameCompatibilityScanButton','GameCompatibilityReport','UpdateInstallZipButton','UsbStatus','UsbEnableButton','UsbRestoreButton','RemoteInstall','RemoteEnableChanges','RemoteDisableChanges','RemoteEnableUsb','RemoteDisableUsb','RemoteUsbConsentLabel','RemoteSyncProfile','RemoteRemove','RemoteStatus','RemoteReport','AppLogo','NoGuestMessage','InstallDiscordButton','EditApprovedSitesButton','SaveDesktopBackupButton','RestoreDesktopBackupButton','DeployIntranetButton','TitleBar','MinimizeButton','MaximizeButton','CloseButton','NavPolicies','NavGames','NavLovable','NavChrome','NavDiagnostics','NavSettings','PageSettings','OpenHelpButton','ConfigureAutologonButton','AutologonStatusButton','DisableAutologonButton','AutologonReport','SettingsApprovedSitesButton','PagePolicies','PageGames','PageLovable','PageChrome','PageDiagnostics','GuestSelector','ChkSettings','ChkCmd','ChkRegistry','ChkEdge','StatusSettings','StatusCmd','StatusRegistry','StatusEdge','PolicySummary','ComputerLabel','HeartbeatLabel','ChromeQuickLabel','QuickCheckHeartbeat','LatestActionLabel','ViewPolicyLog','GamePortalUrl','OpenPortalButton','OpenSteamButton','CheckConnectionButton','ConnectDeviceButton','ViewHeartbeatLog','ConnectionReport','ChromeUrl','ChromeMode','ChromeDelay','ChromeInstall','ChromeRemove','ChromeStatus','ChromeReport','RunHealthButton','ExportProfileButton','ImportProfileButton','CreateShortcutButton','HealthReport','OpenLogsButton','SaveProfileButton','ApplyRestrictionsButton','VerifyPolicyButton','RestorePolicyButton','EmergencyRestoreButton','FooterStatus','FooterVersion','RemoteConsentLabel','UpdateIncludePilots','UpdateCheckButton','UpdateInstallOnlineButton','UpdateOpenGithubButton','UpdateReport')){
  $c=$script:Window.FindName($name)
  if($null -eq $c){throw "XAML control missing: $name"}
  $script:Ui[$name]=$c
 }
 $logoFile=Join-Path $script:AppRoot 'assets\rka-icon-preview.png'
 if(Test-Path -LiteralPath $logoFile){
  $bmp=New-Object System.Windows.Media.Imaging.BitmapImage
  $bmp.BeginInit();$bmp.UriSource=[System.Uri]::new($logoFile);$bmp.CacheOption=[System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad;$bmp.EndInit()
  $script:Ui.AppLogo.Source=$bmp
 }
 $script:Ui.ComputerLabel.Text=$env:COMPUTERNAME
 Update-UsbStatus
 Update-RemoteStatus
 $script:Ui.ChromeMode.SelectedIndex=0
 $script:SavedProfile=Read-Profile
 $script:ApprovedUrls=@($script:SavedProfile.urls)
 $script:Ui.ChkSettings.IsChecked=[bool]$script:SavedProfile.blockSettings
 $script:Ui.ChkCmd.IsChecked=[bool]$script:SavedProfile.blockCmd
 $script:Ui.ChkRegistry.IsChecked=[bool]$script:SavedProfile.blockRegistry
 $script:Ui.ChkEdge.IsChecked=[bool]$script:SavedProfile.restrictEdge
 $script:Ui.GamePortalUrl.Text=[string]$script:SavedProfile.intranet
 $script:Ui.ChromeUrl.Text=[string]$script:SavedProfile.intranet
 $script:PortalUrlSyncing=$false
 $script:Ui.ChromeUrl.Add_TextChanged({Sync-PortalUrl 'Chrome'})
 $script:Ui.GamePortalUrl.Add_TextChanged({Sync-PortalUrl 'Games'})
 Find-GuestAccounts
 $script:Ui.GuestSelector.Add_SelectionChanged({Refresh-PolicyStatuses;Check-RecoverySnapshot})
 $script:Ui.TitleBar.Add_MouseLeftButtonDown({if($_.ClickCount -eq 2){if($script:Window.WindowState -eq 'Maximized'){$script:Window.WindowState='Normal'}else{$script:Window.WindowState='Maximized'}}else{try{$script:Window.DragMove()}catch{}}})
 $script:Ui.MinimizeButton.Add_Click({$script:Window.WindowState='Minimized'})
 $script:Ui.MaximizeButton.Add_Click({if($script:Window.WindowState -eq 'Maximized'){$script:Window.WindowState='Normal'}else{$script:Window.WindowState='Maximized'}})
 $script:Ui.CloseButton.Add_Click({$script:Window.Hide();Set-Footer 'Window hidden to tray. Background heartbeat remains independent.'})
 $script:Window.Add_Closing({if(-not $script:AllowExit){$_.Cancel=$true;$script:Window.Hide()}})
 foreach($page in @('Policies','Games','Lovable','Chrome','Diagnostics','Settings')){$localPage=$page;switch($page){
  'Policies' {$script:Ui.NavPolicies.Add_Click({Show-Page 'Policies'})}
  'Games' {$script:Ui.NavGames.Add_Click({Show-Page 'Games'})}
  'Lovable' {$script:Ui.NavLovable.Add_Click({Show-Page 'Lovable'})}
  'Chrome' {$script:Ui.NavChrome.Add_Click({Show-Page 'Chrome'})}
  'Diagnostics' {$script:Ui.NavDiagnostics.Add_Click({Show-Page 'Diagnostics'})}
  'Settings' {$script:Ui.NavSettings.Add_Click({Show-Page 'Settings'})}
 }}
 $script:Ui.EditApprovedSitesButton.Add_Click({Edit-ApprovedSites})
 $script:Ui.SettingsApprovedSitesButton.Add_Click({Edit-ApprovedSites})
 $script:Ui.OpenHelpButton.Add_Click({Show-CompanionHelp})
 $script:Ui.ConfigureAutologonButton.Add_Click({Invoke-AutologonSetup 'Configure'})
 $script:Ui.AutologonStatusButton.Add_Click({Invoke-AutologonSetup 'Status'})
 $script:Ui.DisableAutologonButton.Add_Click({Invoke-AutologonSetup 'Disable'})
 $script:Ui.SaveProfileButton.Add_Click({try{Save-Profile $true;Refresh-PolicyStatuses}catch{Show-Failure $_.Exception.Message 'Save profile failed'}})
 $script:Ui.ApplyRestrictionsButton.Add_Click({Handle-Apply})
 $script:Ui.VerifyPolicyButton.Add_Click({Handle-Verify})
 $script:Ui.RestorePolicyButton.Add_Click({Handle-Restore})
 $script:Ui.EmergencyRestoreButton.Add_Click({
  try{if(-not(Ask-YesNo 'Run the administrator recovery worker now? This restores the active snapshot if one exists; it does NOT touch Lovable enrollment.' 'Emergency restoration')){return};Handle-Restore}catch{Show-Failure $_.Exception.Message}
 })
 $script:Ui.UsbEnableButton.Add_Click({
  try {
   Assert-Admin
   if(-not (Ask-YesNo 'Block removable USB storage for this ENTIRE PC? This may affect administrator accounts and removable drives; keyboards, mice, and game controllers should not be blocked. Use Restore before deploying elsewhere.' 'Device-wide USB storage restriction')){return}
   $confirm=[Microsoft.VisualBasic.Interaction]::InputBox('Type BLOCK STORAGE to confirm the system-wide change. Keep an administrator login available.','Confirm system-wide USB rule','')
   if($confirm -cne 'BLOCK STORAGE'){return}
   Start-RkaWorker 'USB-Storage.ps1' '-Action Enable'
   Update-UsbStatus; Show-Notice 'USB storage rule written. Verify with a test USB flash drive AND a controller, then restore before production use.' 'USB storage rule updated'
  } catch {Show-Failure $_.Exception.Message 'USB storage setup failed'}
 })
 $script:Ui.UsbRestoreButton.Add_Click({
  try {if(-not (Ask-YesNo 'Restore the exact previous removable-storage Windows policy state from the protected snapshot?' 'Restore USB storage')){return};Start-RkaWorker 'USB-Storage.ps1' '-Action Restore';Update-UsbStatus;Show-Notice 'USB storage policy restored from its snapshot. Check removable drives.' 'USB access restore'} catch{Show-Failure $_.Exception.Message 'USB restore failed'}
 })
 $script:Ui.RemoteInstall.Add_Click({Invoke-RemoteSetup 'Upgrade'})
 $script:Ui.RemoteEnableChanges.Add_Click({Invoke-RemoteSetup 'EnableChanges'})
 $script:Ui.RemoteDisableChanges.Add_Click({Invoke-RemoteSetup 'DisableChanges'})
 $script:Ui.RemoteEnableUsb.Add_Click({Invoke-RemoteSetup 'EnableUsb'})
 $script:Ui.RemoteDisableUsb.Add_Click({Invoke-RemoteSetup 'DisableUsb'})
 $script:Ui.RemoteSyncProfile.Add_Click({Invoke-RemoteSetup 'SyncProfile'})
 $script:Ui.RemoteRemove.Add_Click({if(Ask-YesNo 'Disable remote command polling on this PC? Existing Lovable heartbeat will continue.' 'Disable remote commands'){Invoke-RemoteSetup 'Remove'}})
 $script:Ui.RemoteStatus.Add_Click({Update-RemoteStatus})
 $script:Ui.UpdateCheckButton.Add_Click({Invoke-UpdateCheck})
 $script:Ui.UpdateInstallOnlineButton.Add_Click({Invoke-PublicUpdate})
 $script:Ui.UpdateOpenGithubButton.Add_Click({try{Start-Process 'https://github.com/aehs01/rka-companion-releases/releases'}catch{Show-Failure $_.Exception.Message 'Could not open GitHub'}})
 $script:Ui.ViewPolicyLog.Add_Click({Open-LogFile (Join-Path $script:RecoveryRoot 'worker.log')})
 $script:Ui.QuickCheckHeartbeat.Add_Click({Show-Page 'Lovable';Check-Heartbeat})
 $script:Ui.CheckConnectionButton.Add_Click({Check-Heartbeat})
 $script:Ui.ConnectDeviceButton.Add_Click({
  try {
   if(-not(Ask-YesNo 'This opens the EXISTING heartbeat setup. Your working Lovable connection does not require reinstalling. Continue only if re-enrollment is necessary.' 'Reconnect?')){return}
   Start-Process -FilePath $script:PowerShellExe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:AppRoot 'Heartbeat-Setup.ps1')+'"') -Verb RunAs -Wait
   Check-Heartbeat
  }catch{Show-Failure $_.Exception.Message 'Reconnect failed'}
 })
 $script:Ui.ViewHeartbeatLog.Add_Click({Open-LogFile (Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat\status.log')})
 $script:Ui.ChromeInstall.Add_Click({Check-Chrome 'Install'})
 $script:Ui.ChromeRemove.Add_Click({if(Ask-YesNo 'Disable the guest Chrome startup task? This does not uninstall Chrome.' 'Disable Chrome startup'){Check-Chrome 'Remove'}})
 $script:Ui.ChromeStatus.Add_Click({Check-Chrome 'Status'})
 $script:Ui.RunHealthButton.Add_Click({Run-Health})
 $script:Ui.ExportProfileButton.Add_Click({Export-Profile})
 $script:Ui.ImportProfileButton.Add_Click({Import-Profile})
 $script:Ui.DeployIntranetButton.Add_Click({
  try{
   $guest=Selected-Guest
   $url=Get-CurrentPortalUrl
   if(-not(Ask-YesNo ("Deploy the RKA-branded LAN portal shortcut to $($guest.Name)'s desktop using Chrome Startup > Portal URL?`n`nIt will open $url in Chrome App Mode, maximized. Only the guest will see this shortcut. Existing shortcut of the same name will be updated.") 'Deploy Intranet Shortcut')){return}
   $args='-TargetSid "'+$guest.SID+'" -Url "'+$url+'"'
   Start-RkaWorker 'Deploy-Guest-Intranet.ps1' $args
   Set-Footer ('LAN portal shortcut deployed for '+$guest.Name)
   Show-Notice ("RKA LAN Portal shortcut deployed to guest $($guest.Name).`nNext: log in as that guest, double-click the shortcut, and verify it opens a maximized Chrome app window.") 'Guest shortcut created'
  }catch{Show-Failure $_.Exception.Message 'Deploy intranet shortcut failed'}
 })
 $script:Ui.SaveDesktopBackupButton.Add_Click({
  try{$g=Selected-Guest;Start-RkaWorker 'Guest-Desktop-Backup.ps1' ('-Action Save -TargetSid "'+$g.SID+'"');Show-Notice 'Guest + Public desktop shortcut files backed up. This does NOT save exact icon positions.' 'Desktop shortcut backup saved'}catch{Show-Failure $_.Exception.Message 'Backup shortcuts failed'}
 })
 $script:Ui.RestoreDesktopBackupButton.Add_Click({
  try{$g=Selected-Guest;if(-not(Ask-YesNo ("Restore backed-up guest + Public shortcuts for $($g.Name)? Matching shortcut files will be overwritten, but new files will not be deleted. Icon positions are NOT restored.") 'Restore shortcut files')){return};Start-RkaWorker 'Guest-Desktop-Backup.ps1' ('-Action Restore -TargetSid "'+$g.SID+'"');Show-Notice 'Saved desktop shortcut files restored. Sign into guest to refresh desktop; exact icon positions are not restored.' 'Desktop shortcuts restored'}catch{Show-Failure $_.Exception.Message 'Restore shortcuts failed'}
 })
 $script:Ui.CopyAdminShortcutsButton.Add_Click({
  try{
   Assert-Admin
   $g=Selected-Guest
   $adminDesktop=[Environment]::GetFolderPath('DesktopDirectory')
   $candidates=@(Get-ChildItem -LiteralPath $adminDesktop -File -ErrorAction Stop|Where-Object {$_.Extension -in @('.lnk','.url')})
   if($candidates.Count -eq 0){Show-Notice 'No .lnk or .url shortcuts found on the current administrator desktop.' 'Copy game shortcuts';return}
   $preview=(@($candidates|Select-Object -First 16|ForEach-Object {$_.Name}) -join "`n")
   if(-not(Ask-YesNo ("Copy game shortcuts from administrator desktop to guest $($g.Name)?`n`nCandidates ($($candidates.Count)):`n$preview`n`nSafety: existing guest shortcuts will NOT be overwritten, private-admin paths and Windows admin tools will be skipped. Copying a shortcut does NOT elevate the program.") 'Copy shortcuts to guest')){return}
   Start-RkaWorker 'Copy-Admin-Shortcuts.ps1' ('-TargetSid "'+$g.SID+'"')
   Show-Notice ('Shortcut copy completed for '+$g.Name+'. Check the guest Desktop; unsafe shortcuts and existing files were skipped. See the protected copy report under ProgramData\RKA-Lockdown-Agent\DesktopBackup.') 'Copy game shortcuts'
  }catch{Show-Failure $_.Exception.Message 'Copy game shortcuts failed'}
 })
 $script:Ui.GameCompatibilityScanButton.Add_Click({
  try{
   Assert-Admin
   $g=Selected-Guest
   $cmd='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:AppRoot 'Game-Compatibility.ps1')+'" -TargetSid "'+$g.SID+'"'
   $output=@(& $script:PowerShellExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:AppRoot 'Game-Compatibility.ps1') -TargetSid $g.SID 2>&1 | ForEach-Object {[string]$_}) -join "`r`n"
   $script:Ui.GameCompatibilityReport.Text=$output
   Set-Footer 'Read-only compatibility scan completed; no launch or UAC policy changed'
  }catch{Show-Failure $_.Exception.Message 'Game compatibility scan failed'}
 })
 $script:Ui.UpdateInstallZipButton.Add_Click({
  try{
   Assert-Admin
   $picker=New-Object Microsoft.Win32.OpenFileDialog
   $picker.Title='Select a trusted RKA Companion release ZIP (local or administrator-accessible LAN share)'
   $picker.Filter='ZIP release archives (*.zip)|*.zip'
   $picker.CheckFileExists=$true
   $picker.Multiselect=$false
   if($picker.ShowDialog($script:Window) -ne $true){return}
   $zip=[string]$picker.FileName
   $hash=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
   if(-not(Ask-YesNo ("Upgrade this PC from this release ZIP?`n`nFile: $zip`nSHA256: $hash`n`nOnly use official RKA releases. The ZIP is not code-signed; checksum alone does NOT establish publisher authenticity. This creates a backup, copies files and upgrades both agent tasks if enrolled. You must review results and restart the Companion after successful installation.") 'Install trusted ZIP update')){return}
   $out=Invoke-UpdaterProcess 'InstallLocal' 'Stable' $zip
   if($out -notmatch 'UPDATE INSTALLED:'){throw 'Update output did not verify a successful install.'}
   Show-Notice 'Update installed and agent upgrade attempted. Close this old Companion window and reopen the administrator shortcut; check installed agent file and latest authenticated poll version before updating other PCs.' 'RKA update completed'
  }catch{Show-Failure $_.Exception.Message 'RKA package update failed'}
 })
 $script:Ui.CreateShortcutButton.Add_Click({
  try{Start-RkaWorker 'Create-Desktop-Shortcut.ps1' '' $false;Show-Notice 'Administrator Control Center shortcut created; it opens the Companion, not the guest LAN portal. Keep the extracted package in a permanent folder.' 'Shortcut created'}catch{Show-Failure $_.Exception.Message 'Shortcut failed'}
 })
 $script:Ui.OpenLogsButton.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$script:DataRoot+'"')})
 $script:Ui.OpenPortalButton.Add_Click({try{$url=Get-CurrentPortalUrl;if(-not(Check-Url $url)){throw 'Invalid intranet URL.'};Start-Process $url}catch{Show-Failure $_.Exception.Message}})
 $script:Ui.OpenSteamButton.Add_Click({try{Start-Process 'steam://open/main'}catch{Show-Failure $_.Exception.Message 'Steam not available'}})
 $script:Ui.InstallDiscordButton.Add_Click({try{Start-Process 'https://discord.com/download'}catch{Show-Failure $_.Exception.Message 'Could not open Discord download page'}})
 Setup-Tray
 Refresh-PolicyStatuses;Check-RecoverySnapshot;Refresh-ChromeQuickStatus
 Write-RkaLog 'WPF v1.0.8 opening'
 [void]$script:Window.ShowDialog()
}catch{
 $msg=$_.Exception.ToString()
 Write-RkaLog 'FATAL WPF STARTUP: '+$msg
 try{[System.Windows.MessageBox]::Show($msg,'RKA WPF Startup Error')|Out-Null}catch{Write-Host $msg}
}finally{
 try{if($script:TrayIcon){$script:TrayIcon.Visible=$false;$script:TrayIcon.Dispose()}}catch{}
 try{if($script:MutexAcquired -and $script:Mutex){$script:Mutex.ReleaseMutex()}}catch{}
 try{if($script:Mutex){$script:Mutex.Dispose()}}catch{}
}
