# Administrator-operated recovery for individually backed-up v1.0 remote settings.
# Run elevated on the test PC. This is separate from the original full policy Emergency Restore.
#Requires -Version 5.1
param([ValidateSet('RestoreGuestItems','Status')][string]$Action='Status')
$ErrorActionPreference='Stop'
$principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator elevation required'}
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
$script=Join-Path $root 'Remote-Operations.ps1'
if(-not(Test-Path -LiteralPath $script)){throw 'Installed v1 agent helper missing; update agent first'}
function Is-ValidSid([string]$sid){return ($sid -match '^S-1-5-21-[0-9]{6,12}-[0-9]{6,12}-[0-9]{6,12}-[0-9]{3,6}$' -and $sid -notmatch '-(500|501|503|504)$')}
function StandardAccounts {
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop|Where-Object {$_.SID}|ForEach-Object {$_.SID.Value})
 foreach($a in @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True')){
  if((-not $a.Disabled) -and (Is-ValidSid ([string]$a.SID)) -and $a.SID -notin $admins){@{sid=[string]$a.SID;account_name=[string]$a.Name}}
 }
}
. $script
$dir=Join-Path $root 'ItemRecovery'
$backups=@(Get-ChildItem -LiteralPath $dir -Filter '*.json' -ErrorAction SilentlyContinue)
if($Action -eq 'Status'){Write-Host ('Pending protected remote item snapshots: '+$backups.Count);$backups|Select-Object Name,LastWriteTime;exit 0}
foreach($file in $backups){
 $state=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
 $sid=[string]$state.sid
 [void](Require-Guest $sid)
 $item=[string]$state.item
 if($item -eq 'wallpaper'){
  [void](Restore-GuestWallpaper $sid)
  Write-Host 'Original wallpaper restore staged for guest logon; snapshot retained for verification.'
  continue
 }
 $h=$null
 try{
  $h=Open-GuestHive $sid
  if($item -eq 'browser_allowlist'){
   Set-HostList $h 'Google\Chrome' @($state.chrome)
   Set-HostList $h 'Microsoft\Edge' @($state.edge)
   if((@((Read-HostList $h 'Google\Chrome')|ConvertTo-Json -Compress) -join '') -eq ''){throw 'Failed to read restored allowlist'}
  }elseif($item -in $script:RkaAllowList){
   $spec=Registry-Spec $item
   if($state.before.path -cne $spec.path -or $state.before.name -cne $spec.name){throw 'Snapshot registry target mismatch'}
   if($state.before.state.exists){
    $v=$state.before.state.value
    if($state.before.state.kind -eq 'DWord'){$v=[int]$v}
    if($state.before.state.kind -eq 'MultiString'){$v=[string[]]@($v)}
    Write-Value $h $spec.path $spec.name $v ([string]$state.before.state.kind)
   }else{Delete-Value $h $spec.path $spec.name}
   $now=Read-Value $h $spec.path $spec.name
   if([bool]$now.exists -ne [bool]$state.before.state.exists){throw 'Restore verification mismatch'}
  }else{throw 'Unknown recovery item; refusing'}
 }finally{if($h){Close-GuestHive $h}}
 Remove-Item -LiteralPath $file.FullName -Force
 Write-Host ('Restored '+$item+' for protected guest SID; behavior must still be checked.')
}
