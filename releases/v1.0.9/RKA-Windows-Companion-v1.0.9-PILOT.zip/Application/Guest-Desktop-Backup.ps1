﻿# Backup / restore ONLY .lnk and .url files for selected local standard guest + Public desktop.
# Does not capture/restore icon XY positions, ACLs, arbitrary files, or delete new shortcuts.
#Requires -Version 5.1
param([Parameter(Mandatory=$true)][ValidateSet('Save','Restore')][string]$Action,[Parameter(Mandatory=$true)][string]$TargetSid)
$ErrorActionPreference='Stop'
try{
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'An elevated administrator account is required.'}
 if($TargetSid -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Invalid local guest SID.'}
 $guest=Get-CimInstance Win32_UserAccount -Filter "SID='$TargetSid' AND LocalAccount=True" -ErrorAction Stop|Select-Object -First 1
 if(-not $guest -or $guest.Disabled){throw 'Guest account missing or disabled.'}
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
 if(@($admins | Where-Object {$_.SID -and $_.SID.Value -eq $TargetSid}).Count -gt 0){throw 'Cannot back up administrator account as guest.'}
 if($TargetSid -eq $identity.User.Value){throw 'Refusing to target current administrator account.'}
 $wp=Get-CimInstance Win32_UserProfile -Filter "SID='$TargetSid'" -ErrorAction Stop|Select-Object -First 1
 if(-not $wp -or -not $wp.LocalPath){throw 'Guest profile must be created by signing in once.'}
 $guestDesktop=Join-Path $wp.LocalPath 'Desktop'
 $publicDesktop=[Environment]::GetFolderPath('CommonDesktopDirectory')
 if(-not(Test-Path -LiteralPath $guestDesktop -PathType Container)){throw 'Guest Desktop folder missing or redirected; cannot safely identify its location.'}
 if(-not(Test-Path -LiteralPath $publicDesktop -PathType Container)){throw 'Public Desktop folder not found.'}
 $root=Join-Path $env:ProgramData ('RKA-Lockdown-Agent\DesktopBackup\'+$TargetSid)
 if(-not(Test-Path -LiteralPath $root)){New-Item -Path $root -ItemType Directory -Force|Out-Null}
 & icacls.exe $root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Could not secure desktop backup folder.'}
 if($Action -eq 'Save'){
  $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
  $backup=Join-Path $root $stamp
  if(Test-Path $backup){$backup+='-'+[Guid]::NewGuid().ToString('N').Substring(0,6)}
  [void](New-Item -Path $backup -ItemType Directory -ErrorAction Stop)
  $total=0
  foreach($entry in @(@{Name='Guest';From=$guestDesktop},@{Name='Public';From=$publicDesktop})){
   $to=Join-Path $backup $entry.Name
   [void](New-Item -Path $to -ItemType Directory -ErrorAction Stop)
   foreach($file in @(Get-ChildItem -LiteralPath $entry.From -File -ErrorAction Stop|Where-Object {$_.Extension -in @('.lnk','.url')})){
    Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $to $file.Name) -ErrorAction Stop
    $total++
   }
  }
  [ordered]@{account=$guest.Name;sid=$TargetSid;time=(Get-Date).ToString('o');count=$total} | ConvertTo-Json|Set-Content -LiteralPath (Join-Path $backup 'manifest.json') -Encoding UTF8
  Write-Host "SUCCESS: $total guest/Public shortcut files saved at $backup. Positions are NOT included." -ForegroundColor Cyan
 }else{
  $latest=Get-ChildItem -LiteralPath $root -Directory -ErrorAction Stop|Sort-Object Name -Descending|Select-Object -First 1
  if(-not $latest){throw 'No saved shortcut files exist for this guest. Click Save Shortcuts first.'}
  $manifest=Get-Content -LiteralPath (Join-Path $latest.FullName 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
  if($manifest.sid -ne $TargetSid){throw 'Backup SID does not match selected guest.'}
  $restored=0
  foreach($entry in @(@{Name='Guest';To=$guestDesktop},@{Name='Public';To=$publicDesktop})){
   $from=Join-Path $latest.FullName $entry.Name
   foreach($file in @(Get-ChildItem -LiteralPath $from -File -ErrorAction Stop|Where-Object {$_.Extension -in @('.lnk','.url')})){
    Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $entry.To $file.Name) -Force -ErrorAction Stop
    $restored++
   }
  }
  Write-Host "SUCCESS: Restored $restored guest/Public shortcut files from $($latest.Name). New shortcuts were not deleted. Positions unchanged." -ForegroundColor Cyan
 }
 exit 0
}catch{
 try{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Guest Desktop Backup','OK','Error')|Out-Null}catch{Write-Host $_.Exception.Message -ForegroundColor Red}
 exit 1
}
