@echo off
cd /d "%~dp0"
call "Emergency-Restore.cmd"
