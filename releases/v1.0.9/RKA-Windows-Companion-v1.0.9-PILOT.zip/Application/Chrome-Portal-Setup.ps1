﻿# Chrome guest-only autostart task manager. Must run from an elevated administrator account.
#Requires -Version 5.1
param([ValidateSet('Install','Remove','Status')][string]$Action='Status',[string]$UserName,[string]$Url='http://rkaserver/',[ValidateSet('App','Normal','Fullscreen')][string]$Mode='App',[int]$Delay=10)
$ErrorActionPreference='Stop'
$taskName='RKA-Guest-Chrome-Portal'
$base=Join-Path $env:ProgramData 'RKA-Lockdown-Agent'
$folder=Join-Path $base 'ChromePortal'
$config=Join-Path $folder 'config.json'
$worker=Join-Path $folder 'Chrome-Portal.ps1'
$status=Join-Path $base 'chrome-setup-last-result.txt'
function Record([string]$message,[bool]$ok){
  $msg=('Time: '+(Get-Date -Format o)+[Environment]::NewLine+'Action: '+$Action+[Environment]::NewLine+'Outcome: '+$(if($ok){'SUCCESS'}else{'ERROR'})+[Environment]::NewLine+'Details: '+$message)
  try{if(-not(Test-Path $base)){New-Item -Path $base -ItemType Directory -Force|Out-Null};Set-Content -LiteralPath $status -Value $msg -Encoding UTF8 -ErrorAction Stop}catch{}
  Write-Host $msg
}
try{
  $me=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
  if(-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Run from an elevated administrator account.'}
  if($Action -eq 'Status'){
    $task=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    Record $(if($task){'Installed; state: '+$task.State}else{'Not installed'}) $true;exit 0
  }
  if($Action -eq 'Remove'){
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'Task still exists after removal attempt.'}
    if(Test-Path $config){Remove-Item -LiteralPath $config -Force -ErrorAction Stop}
    Record 'Guest Chrome auto-start task removed. Browser itself was not uninstalled.' $true;exit 0
  }
  if([string]::IsNullOrWhiteSpace($UserName)){throw 'Select a standard user in Settings first.'}
  $uri=$null
  if(-not [Uri]::TryCreate($Url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.UserInfo){throw 'Enter a valid http(s) portal URL without credentials.'}
  if($Delay -lt 0 -or $Delay -gt 120){throw 'Delay must be 0–120 seconds.'}
  $acct=Get-LocalUser -Name $UserName -ErrorAction Stop
  if(-not $acct.Enabled){throw 'Selected account is disabled.'}
  if(-not $acct.SID){throw 'Selected account SID unavailable.'}
  $sid=$acct.SID.Value
  # Membership check must succeed. Never infer standard status from an error.
  $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
  if(@($admins|Where-Object {$_.SID -and $_.SID.Value -eq $sid}).Count -gt 0){throw 'An administrator account cannot be selected for Chrome auto-start.'}
  if($sid -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Refusing to schedule Chrome for the current administrator.'}
  $source=Join-Path $PSScriptRoot 'Chrome-Portal.ps1'
  if(-not(Test-Path -LiteralPath $source)){throw 'Missing Chrome-Portal.ps1. Extract the entire ZIP.'}
  if(-not(Test-Path $folder)){New-Item -Path $folder -ItemType Directory -Force|Out-Null}
  & icacls.exe $folder /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' |Out-Null
  if($LASTEXITCODE -ne 0){throw 'Unable to secure ChromePortal folder permissions.'}
  Copy-Item -LiteralPath $source -Destination $worker -Force -ErrorAction Stop
  $cfg=[ordered]@{enabled=$true;sid=$sid;url=$uri.AbsoluteUri;mode=$Mode;delay=$Delay}
  $cfg|ConvertTo-Json|Set-Content -LiteralPath $config -Encoding UTF8 -ErrorAction Stop
  $arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$worker+'" -ConfigPath "'+$config+'"'
  $taskAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $arguments
  $trigger=New-ScheduledTaskTrigger -AtLogOn -User "$env:COMPUTERNAME\$($acct.Name)"
  $principal=New-ScheduledTaskPrincipal -UserId "$env:COMPUTERNAME\$($acct.Name)" -LogonType Interactive -RunLevel Limited
  $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 3)
  Register-ScheduledTask -TaskName $taskName -Action $taskAction -Trigger $trigger -Principal $principal -Settings $settings -Force -ErrorAction Stop|Out-Null
  $installed=Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
  Record ('Installed for '+$acct.Name+' (standard user SID '+$sid+'); '+$uri.AbsoluteUri+'; mode '+$Mode+'; delay '+$Delay+' sec; state '+$installed.State+'. Guest logon required for actual Chrome launch test.') $true
  exit 0
}catch{
  Record $_.Exception.ToString() $false
  exit 1
}
