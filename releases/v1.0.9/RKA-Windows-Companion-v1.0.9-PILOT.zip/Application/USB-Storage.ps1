﻿# Administrator-operated USB *storage* policy only; does NOT disable USB ports, HID keyboards, mice or controllers.
# Policy is potentially MACHINE WIDE even on Windows Home. Test real devices; registry evidence is not proof of enforcement.
#Requires -Version 5.1
param([Parameter(Mandatory=$true)][ValidateSet('Enable','Restore','Status')][string]$Action)
$ErrorActionPreference='Stop'
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\USBStorage'
$backup=Join-Path $root 'original.json'
$registry='HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices'
$log=Join-Path $root 'storage.log'
function Log([string]$s){try{Add-Content -LiteralPath $log -Value "$(Get-Date -Format o) $s" -Encoding UTF8}catch{}}
function AdminRequired {
 $pr=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Local administrator elevation required for system-wide removable-storage policy.'}
}
function SecureRoot {
 [void](New-Item -ItemType Directory -Path $root -Force)
 & "$env:SystemRoot\System32\icacls.exe" $root '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Cannot secure USB storage recovery directory.'}
}
try {
 AdminRequired
 if($Action -eq 'Status'){
  $v=(Get-ItemProperty -LiteralPath $registry -Name Deny_All -ErrorAction SilentlyContinue).Deny_All
  Write-Output "HKLM removable storage Deny_All: $v (not proof of real device behavior)";exit 0
 }
 SecureRoot
 if($Action -eq 'Enable'){
  if(Test-Path -LiteralPath $backup){throw 'A previous USB storage policy snapshot exists; Restore it before applying again.'}
  $old=Get-ItemProperty -LiteralPath $registry -Name Deny_All -ErrorAction SilentlyContinue
  $present=$null -ne $old
  $saved=@{existed=$present;value=$(if($present){[int]$old.Deny_All}else{$null});recordedAt=(Get-Date).ToString('o')}
  $saved|ConvertTo-Json|Set-Content -LiteralPath $backup -Encoding UTF8
  if(-not(Test-Path -LiteralPath $registry)){[void](New-Item -Path $registry -Force)}
  New-ItemProperty -LiteralPath $registry -Name Deny_All -PropertyType DWord -Value 1 -Force|Out-Null
  $actual=(Get-ItemProperty -LiteralPath $registry -Name Deny_All -ErrorAction Stop).Deny_All
  if($actual -ne 1){throw 'USB storage registry setting could not be verified. Restore from original snapshot.'}
  Log 'Machine-wide removable storage Deny_All=1 written; not yet device-tested.'
  Write-Output 'USB storage registry rule applied. Verify removable drive, gaming controller, keyboard and mouse.'
 }else{
  if(-not(Test-Path -LiteralPath $backup)){
   $current=(Get-ItemProperty -LiteralPath $registry -Name Deny_All -ErrorAction SilentlyContinue).Deny_All
   if($null -eq $current -or [int]$current -eq 0){Log 'Restore requested with no snapshot; USB block already absent.';Write-Output 'Already restored: no active USB block and no snapshot. No changes made.';exit 0}
   throw 'USB block remains enabled but protected snapshot is missing; refusing to guess original policy.'
  }
  $original=Get-Content -LiteralPath $backup -Raw -Encoding UTF8|ConvertFrom-Json
  if($original.existed){
   if(-not(Test-Path -LiteralPath $registry)){[void](New-Item -Path $registry -Force)}
   New-ItemProperty -LiteralPath $registry -Name Deny_All -PropertyType DWord -Value ([int]$original.value) -Force|Out-Null
  }else{
   if(Test-Path -LiteralPath $registry){Remove-ItemProperty -LiteralPath $registry -Name Deny_All -ErrorAction SilentlyContinue}
  }
  $now=Get-ItemProperty -LiteralPath $registry -Name Deny_All -ErrorAction SilentlyContinue
  if(([bool]$original.existed -ne ($null -ne $now)) -or ($original.existed -and [int]$now.Deny_All -ne [int]$original.value)){throw 'Verification failed; original policy snapshot retained for recovery.'}
  Remove-Item -LiteralPath $backup -Force
  Log 'Original removable storage policy restored and checked.'
  Write-Output 'USB storage policy restored. Verify real removable drives.'
 }
}catch{
 Log ('FAIL '+$Action+': '+$_.Exception.Message)
 Write-Error $_.Exception.Message
 exit 1
}
