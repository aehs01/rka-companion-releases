@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Manager.ps1" -Action Check
if errorlevel 1 pause
