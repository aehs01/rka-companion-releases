# RKA Windows Companion v1.0.7 — LAN Portal shortcut consistency

- Unified guest portal URL: the URL shown under Chrome Startup is the destination for Deploy Guest LAN Portal Shortcut, with Game Installers URL synchronized bidirectionally. No old Tyrant default is introduced; existing profile migrations preserve customized addresses.
- Corrected shortcut labels: **Create Admin Companion Shortcut** opens the admin app; **Deploy Guest LAN Portal Shortcut** creates a Chrome App Mode link for the selected standard user.
- The deployment confirmation displays the exact destination URL. Installing or updating the guest Chrome auto-start task remains a separate explicit action.
- No changes to enforced policies, approved websites, remote commands, USB authorization or Windows notification behavior. Existing enrollment and recovery preserved.
- Companion, heartbeat, background agent and installer version labels are aligned at 1.0.7. Because installed Windows agents are separate, use Lovable Connection > Install / Repair Agent and wait for the authenticated v1.0.7 report before approving in Lovable.
- ZIP and static file/markup validation completed; no live Windows execution has been performed for v1.0.7. Test on the spare laptop, then on one arcade guest PC before expanding.
