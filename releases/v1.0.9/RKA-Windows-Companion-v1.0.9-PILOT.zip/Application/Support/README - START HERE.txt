﻿RETRO KNIGHTS ARCADE — WINDOWS COMPANION v1.0.1 PATCH RELEASE
21 October 2026

START HERE: See Application\Support\RELEASE-NOTES-v1.0.1.txt for patch details and safe laptop validation.
Existing enrolled test laptop: double-click INSTALL OR UPDATE AGENT v1.0.1.cmd to upgrade its background agent without re-enrollment.
Desktop WPF GUI: Retro Knights PC Control Center.vbs
Recovery: Emergency Restore.cmd (old broad policy), RESTORE REMOTE v1.0 SETTINGS.cmd (new per-item changes), Application\RESTORE-USB-STORAGE.cmd (machine-wide USB).

IMPORTANT: Static build validated only; Windows 11 end-to-end test is still required before deploying to all arcade PCs. Lovable's dashboard recognizes real agent capabilities, not this package label.

RETRO KNIGHTS PC CONTROL CENTER — v1.0.1 LAPTOP-VALIDATION RELEASE

Launch: Retro Knights PC Control Center.vbs (administrator approval required).

POLICY WORKFLOW
Save Profile Only = save selected options, no Windows restrictions applied.
Apply Restrictions = enforce selected guest restrictions, create protected recovery snapshot.
Refresh Policy Status = read-only registry check. Off (no policy found) means the checked registry value is absent, NOT unknown. Actual guest behavior should be tested.
Restore Previous Settings = revert saved guest policy snapshot; restore before applying a new policy snapshot.
Emergency Restore = guest policy snapshot recovery. IMPORTANT: USB storage is DEVICE-WIDE and has its OWN Block/Restore controls. Restore USB separately, including after guest Emergency Restore; reconnect the flash drive if needed.

VALIDATED BY OWNER IN v1.0 TESTING: root launcher, guest browser allowlist, intranet launch/startup, command-prompt restriction, USB block/restore in prior release.

RECOMMENDED BROWSER DEFAULTS
On fresh start or an empty saved website list, the WPF editor shows http://rkaserver/ and the four Discord domains. Existing nonempty custom lists are kept; use Add RKA defaults to merge missing entries manually. Save Profile Only does not apply Windows restrictions.

REMOTE MANAGEMENT LIMITATION
HISTORICAL NOTE: Only the four original agent commands were previously proven end-to-end. The new v1.0.1 agent implements the extended typed commands, but they require controlled Windows laptop testing. Do not roll out fleet-wide until verified.

The application has NOT been executed on Windows in this build environment. Keep a working administrator account and your prior known-good package for recovery.
