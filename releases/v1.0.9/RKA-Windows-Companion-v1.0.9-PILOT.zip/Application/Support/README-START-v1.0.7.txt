RKA Windows Companion v1.0.7

Important: the Control Center version does NOT automatically update the installed background agent.

1. Extract the entire ZIP to a NEW, permanent folder. Run Retro Knights PC Control Center.vbs as administrator.
2. On Lovable Connection click Install / Repair Agent; this replaces BOTH scheduled SYSTEM tasks. Enrollment and prior local permissions are preserved.
3. Click Check remote status. Confirm Installed SYSTEM agent file is 1.0.7 AND last authenticated agent poll is 1.0.7. A stale 1.0.2 poll means the background agent did not yet check in or the old task is still installed. Do not approve a version based on the window label alone.
4. For USB remote control, Enable Remote Changes, then separately click Allow remote USB control and type ALLOW REMOTE USB. This only authorizes REMOTE USB BLOCK/RESTORE commands; no drive is blocked until a command is issued. Look for set_usb_storage capability in Lovable after the next authenticated poll. On a spare machine, test actual USB block and restore before deploying the feature broadly. USB block affects ALL Windows users.
5. If a branded guest announcement disappears quickly, Windows guest account Settings > Accessibility > Visual effects > Dismiss notifications after this amount of time > 30 seconds. A requested 30-second balloon is not guaranteed on-screen for 30 seconds. Full-screen games may suppress it.
6. Open GitHub Releases for downloads. This package does not silently auto-update software. Keep administrator recovery and prior build available.
7. Do an end-to-end pilot on one real arcade PC before the full rollout.

Diagnostics: Application\CHECK-INSTALLED-AGENT-VERSION.cmd prints installed marker, last authenticated version, and scheduled-task status.

SHORTCUTS AND PORTAL URL (v1.0.7):
- Chrome Startup > Portal URL is the shared URL for the guest LAN portal shortcut and Game Installers. Editing either field updates the other. Existing Windows browser restrictions are NOT changed by editing the URL.
- Diagnostics > Deploy Guest LAN Portal Shortcut writes to the selected standard guest's Desktop and launches Chrome App Mode. It uses the current Chrome Startup Portal URL. Default http://rkaserver/. Verify on actual guest account.
- Diagnostics > Create Admin Companion Shortcut creates a local Control Center shortcut for the current administrator account. This intentionally opens the Companion and does not browse to the intranet. Keep the extracted v1.0.7 folder in a permanent location or recreate the admin shortcut after moving it.
- If guest Chrome startup was installed earlier with a different URL, use Chrome Startup > Install / Update to update the existing startup task; creating a guest shortcut does not change the startup task.
