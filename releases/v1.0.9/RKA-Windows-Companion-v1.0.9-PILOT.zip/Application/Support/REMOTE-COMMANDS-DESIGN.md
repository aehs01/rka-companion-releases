# Remote commands: not activated in v0.3.0

The working heartbeat proves outbound connectivity, **not** remote command authenticity. The existing token is only a heartbeat credential; do not reuse it as a general-purpose remote command authorization.

Proposed sequence: Supabase authenticated owner/admin creates an allowlisted command for one device; server stores command id, nonce, issue/expiry time (short TTL), typed parameters, issuer and audit; Windows privileged worker polls over authenticated TLS using a separate scoped device credential; worker verifies server authorization, command nonce/expiry, local target account SID and group membership; rejects admin/SYSTEM/unknown SID and unsupported command; returns idempotent acknowledgement with result and error. Persist processed nonces to block replay. Commands are disabled until protocol end-to-end test and review.

Proposed commands: RefreshDiagnostics (read-only), RestartPC (explicit confirmation and cancellation delay), ApplyGuestPolicy and RestoreGuestPolicy (per-standard-user SID only, prior-state backup and tested local recovery). Never provide remote shell, arbitrary PowerShell, download-and-run, blanket firewall/Defender disable, or policy affecting administrator accounts.

Do not test destructive commands on production gaming PCs before a supervised recovery test on the laptop. The owner-facing Lovable UI can show planned commands disabled until the backend and agent have been independently verified.
