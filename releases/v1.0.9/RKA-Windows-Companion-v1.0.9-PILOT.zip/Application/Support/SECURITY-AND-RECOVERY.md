# RKA v0.3.2 BETA security / recovery

Only applies to selected, verified **local standard** Windows account. UI access is administrator-only, policy worker requests elevation and validates SID on the machine. Saving a profile NEVER changes Windows.

**No timer:** Apply Restrictions uses persistent mode, saves a protected snapshot of each changed registry value in `C:\ProgramData\RKA-Lockdown-Agent\Recovery\snapshot-*.json`, and requires typed `RESTORE READY` confirmation. Until **Restore Previous Settings** or **Emergency-Restore.cmd** runs successfully the policy remains applied. Do NOT activate until the independent administrator login and emergency restore mechanism are available and tested. Windows guest sign-out / sign-in may be needed before changes take effect.

Legacy timed-trial data (from 0.3.1 or earlier) can still be restored by the worker if a previous snapshot is active. New UI does not create timed trials.

**Read-only verification:** Verify Policy reads the actual target user's HKCU policy registry values, using an elevated worker, and writes the elevated admin user's `LOCALAPPDATA\RKA-Lockdown-Agent\verification.json`. It does not prove the restriction has taken effect in every Windows component; testing from inside the guest account is still necessary.

Chrome Startup uses an admin-owned scheduled task for only the intended standard user's interactive logon; its script/configuration are placed in admin-writable `C:\ProgramData\RKA-Lockdown-Agent\ChromePortal`. Guests can read/execute but not edit, and the task does not run under SYSTEM. Report errors are in `C:\ProgramData\RKA-Lockdown-Agent\chrome-setup-last-result.txt`.

**Scope limit:** Control Panel, Command Prompt, Registry Editor and optional Edge policies are supported. Other browsers, scripts, installation from USB, real process lockdown, remote commands, and generic application allowlisting are NOT implemented. Protect game accounts with account controls and device security separately. Windows 10 support is not verified.

**Emergency restoration:** sign into a separate administrator account; run `Emergency-Restore.cmd`, approve UAC, wait for exit result 0, and sign the guest out/in. If it fails, check `C:\ProgramData\RKA-Lockdown-Agent\Recovery\worker.log`, do not delete backups. Keep backups until verified restored.
