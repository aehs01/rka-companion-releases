@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check-Running.ps1"
echo.
echo If the icon is missing, click ^ near the clock to show hidden tray icons.
pause
