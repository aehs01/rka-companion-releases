# v1.0.8 administrator-only, guest-targeted shortcut import.
# Copies only .lnk/.url files from the current administrator's Desktop.
# Existing guest files never overwritten. No EXE, scripts or privilege changes.
#Requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$TargetSid)
$ErrorActionPreference='Stop'
try {
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator elevation required'}
 if($TargetSid -notmatch '^S-1-5-21-(\d+-){3}\d+$' -or $TargetSid -eq $identity.User.Value){throw 'Select a different, standard local guest account'}
 $adminMembers=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
 if(@($adminMembers|Where-Object {$_.SID -and $_.SID.Value -eq $TargetSid}).Count -ne 0){throw 'Cannot copy into an administrator account'}
 $guest=Get-CimInstance Win32_UserAccount -Filter "SID='$TargetSid' AND LocalAccount=True" -ErrorAction Stop|Select-Object -First 1
 if(-not $guest -or $guest.Disabled){throw 'Guest account unavailable'}
 $profile=Get-CimInstance Win32_UserProfile -Filter "SID='$TargetSid'" -ErrorAction Stop|Select-Object -First 1
 if(-not $profile -or -not $profile.LocalPath){throw 'Guest profile missing; sign in as guest once'}
 $dst=Join-Path $profile.LocalPath 'Desktop'
 $src=[Environment]::GetFolderPath('DesktopDirectory')
 if(-not(Test-Path -LiteralPath $src -PathType Container) -or -not(Test-Path -LiteralPath $dst -PathType Container)){throw 'Administrator or guest desktop is unavailable or redirected'}
 if([IO.Path]::GetFullPath($src) -eq [IO.Path]::GetFullPath($dst)){throw 'Source and destination desktops are identical'}
 $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\DesktopBackup'
 if(-not(Test-Path -LiteralPath $root)){[void](New-Item -ItemType Directory -Path $root -Force)}
 & "$env:SystemRoot\System32\icacls.exe" $root '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F'|Out-Null
 if($LASTEXITCODE -ne 0){throw 'Could not secure shortcut audit directory'}
 $skip=@('cmd.exe','powershell.exe','pwsh.exe','regedit.exe','mmc.exe','control.exe','taskmgr.exe','wt.exe','runas.exe','wscript.exe','cscript.exe','mshta.exe')
 $copied=0;$skipped=@();$shell=New-Object -ComObject WScript.Shell
 foreach($f in @(Get-ChildItem -LiteralPath $src -File -Force -ErrorAction Stop|Where-Object {$_.Extension -in @('.lnk','.url')})){
  try{
   if(($f.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Reparse-point shortcut skipped'}
   $dest=Join-Path $dst $f.Name
   if(Test-Path -LiteralPath $dest){throw 'Already on guest desktop'}
   if($f.Extension -eq '.lnk'){
    $lnk=$shell.CreateShortcut($f.FullName)
    $target=[string]$lnk.TargetPath
    if(-not $target){throw 'Shortcut target not resolvable'}
    $leaf=[IO.Path]::GetFileName($target).ToLowerInvariant()
    if($leaf -in $skip){throw 'Administrative Windows tool'}
    if($target -match '^(?i)\\\\'){throw 'Remote path — review manually'}
    $adminPrivate=[IO.Path]::Combine([Environment]::GetFolderPath('UserProfile'),'AppData')
    if($target.StartsWith($adminPrivate,[StringComparison]::OrdinalIgnoreCase)){throw 'References administrator-private AppData'}
    # Shell link header flags: SLDF_RUNAS_USER 0x2000, DWORD at byte 0x14.
    $raw=[IO.File]::ReadAllBytes($f.FullName)
    if($raw.Length -ge 24 -and (([BitConverter]::ToUInt32($raw,20) -band 0x2000) -ne 0)){throw 'Shortcut explicitly requests elevation'}
   }
   Copy-Item -LiteralPath $f.FullName -Destination $dest -ErrorAction Stop
   $copied++
  }catch{$skipped+=($f.Name+': '+$_.Exception.Message)}
 }
 $report=@{at=(Get-Date).ToString('o');guest=$guest.Name;sid=$TargetSid;copied=$copied;skipped=$skipped;source=$src;destination=$dst}
 $report|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $root ('shortcut-copy-'+$TargetSid+'.json')) -Encoding UTF8
 Write-Host ("Copied $copied shortcuts to guest $($guest.Name). Skipped $($skipped.Count). Source: $src")
 $skipped|ForEach-Object {Write-Host ('  SKIPPED '+$_)}
 exit 0
}catch{Write-Error $_.Exception.Message;exit 1}
