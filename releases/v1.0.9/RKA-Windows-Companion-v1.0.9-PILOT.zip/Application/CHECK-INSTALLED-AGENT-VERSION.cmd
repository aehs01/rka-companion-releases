﻿@echo off
echo RKA v1.0.9 - installed agent verification
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Remote-Setup.ps1" -Action Status
pause
