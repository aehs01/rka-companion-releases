@echo off
cd /d "%~dp0"
echo Restore original machine-wide USB storage policy from RKA protected snapshot.
echo IMPORTANT: Right-click this file and select Run as administrator.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0USB-Storage.ps1" -Action Restore
echo.
pause
