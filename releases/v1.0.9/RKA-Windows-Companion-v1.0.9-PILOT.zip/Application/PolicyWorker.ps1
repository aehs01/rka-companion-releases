﻿# Retro Knights Arcade - persistent guest policies with administrator-only recovery, Windows PowerShell 5.1; old trial support retained only for backward compatibility
# Windows 10/11 Home compatible registry values; NOT a comprehensive application lock.
#Requires -Version 5.1
param(
 [Parameter(Mandatory=$true)][ValidateSet('Trial','Persistent','Restore','Verify')][string]$Operation,
 [string]$TargetSid='',
 [string]$ProfilePath='',
 [string]$BackupPath=''
)
$ErrorActionPreference='Stop'
$Root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery'
$Pointer=Join-Path $Root 'current.json'
$WorkerFile=Join-Path $Root 'PolicyWorker.ps1'
$LogPath=Join-Path $Root 'worker.log'
function Write-Log([string]$msg){try{Add-Content -LiteralPath $LogPath -Value "$(Get-Date -Format o) $msg" -Encoding UTF8}catch{}}
function Assert-Admin {
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 $principal=[Security.Principal.WindowsPrincipal]$identity
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator elevation is required.'}
}
function Ensure-Root {
 if(-not(Test-Path -LiteralPath $Root)){New-Item -Path $Root -ItemType Directory -Force|Out-Null}
 # Explicitly remove inherited Users/Authenticated Users permissions. Backup must not be editable by guests.
 & icacls.exe $Root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Cannot secure ProgramData recovery directory ACL.'}
}
function Open-Hive([string]$sid) {
 $usr=[Microsoft.Win32.Registry]::Users
 $h=$usr.OpenSubKey($sid,$true)
 if($h){return [pscustomobject]@{ Key=$h; Mounted=$false; MountId=$sid }}
 $p=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop | Select-Object -First 1
 if(-not $p -or -not $p.LocalPath){throw 'Could not find the selected Windows user profile. Sign into the guest account once before testing.'}
 $dat=Join-Path $p.LocalPath 'NTUSER.DAT'
 if(-not(Test-Path -LiteralPath $dat)){throw 'Guest registry hive was not found. Sign into the guest account once first.'}
 $mount='RKA_LOCKDOWN_TEST_'+([guid]::NewGuid().ToString('N'))
 & reg.exe load "HKU\$mount" $dat |Out-Null
 if($LASTEXITCODE -ne 0){throw 'Could not load guest account registry hive. Log out the guest account and retry.'}
 $h=$usr.OpenSubKey($mount,$true)
 if(-not $h){throw 'Loaded guest account hive is inaccessible.'}
 return [pscustomobject]@{ Key=$h; Mounted=$true; MountId=$mount }
}
function Close-Hive($h){
 if($null -ne $h.Key){$h.Key.Dispose()}
 if($h.Mounted){[gc]::Collect();[gc]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 200; & reg.exe unload "HKU\$($h.MountId)" |Out-Null;if($LASTEXITCODE -ne 0){Write-Log "WARN unload hive: $($h.MountId)"}}
}
function Registry-Read($h,[string]$path,[string]$name){
 $k=$h.Key.OpenSubKey($path,$false)
 if(-not $k){return @{Exists=$false;Value=$null;Kind='String'}}
 try{
  if($k.GetValueNames() -notcontains $name){return @{Exists=$false;Value=$null;Kind='String'}}
  $kind=$k.GetValueKind($name).ToString()
  $v=$k.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
  if($kind -notin @('DWord','String','ExpandString','MultiString')){throw "Unsupported existing registry type $kind for $path\$name; abort for safe restoration."}
  return @{Exists=$true;Value=$v;Kind=$kind}
 }finally{$k.Dispose()}
}
function Registry-Write($h,[string]$path,[string]$name,$value,[string]$kind){
 $k=$h.Key.CreateSubKey($path,$true)
 if(-not $k){throw "Unable to open registry key $path"}
 try{ $k.SetValue($name,$value,([Microsoft.Win32.RegistryValueKind][Enum]::Parse([Microsoft.Win32.RegistryValueKind],$kind))) }finally{$k.Dispose()}
}
function Registry-Delete($h,[string]$path,[string]$name){
 $k=$h.Key.OpenSubKey($path,$true)
 if($k){try{if($k.GetValueNames() -contains $name){$k.DeleteValue($name,$false)}}finally{$k.Dispose()}}
}
function Get-Changes($profile) {
 $l=New-Object System.Collections.ArrayList
 function Put($path,$name,$value,$kind){[void]$l.Add(@{Path=$path;Name=$name;Value=$value;Kind=$kind})}
 if($profile.blockSettings){Put 'Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoControlPanel' 1 'DWord'}
 if($profile.blockCmd){Put 'Software\Policies\Microsoft\Windows\System' 'DisableCMD' 2 'DWord'}
 if($profile.blockRegistry){Put 'Software\Microsoft\Windows\CurrentVersion\Policies\System' 'DisableRegistryTools' 1 'DWord'}
 if($profile.restrictEdge){
  $approved=@()
  foreach($url in @($profile.urls)){
   if([string]::IsNullOrWhiteSpace($url)){continue}
   $u=$null
   if(-not [uri]::TryCreate([string]$url,[UriKind]::Absolute,[ref]$u) -or $u.Scheme -notin @('http','https') -or -not [string]::IsNullOrEmpty($u.UserInfo)){throw "Invalid Edge allowlist URL $url"}
   # Chromium URLFilter patterns: host-only covers http and https and all paths.
   # Allow LAN host, Discord domains, and explicit URL host without accidental path-only mismatch.
   $hostPattern=$u.Host.ToLowerInvariant()
   if($u.IsDefaultPort -eq $false){$hostPattern+=':'+$u.Port}
   $approved+=$hostPattern
   if($u.Host.ToLowerInvariant() -in @('discord.com','discord.gg','discordapp.com','cdn.discordapp.com')){$approved+='[*.]'+$u.Host.ToLowerInvariant()}

  }
  # Explicit intranet entry is always required even when older profiles omit it.
  $intranetUri=$null
  if(-not [uri]::TryCreate([string]$profile.intranet,[UriKind]::Absolute,[ref]$intranetUri) -or $intranetUri.Scheme -notin @('http','https')){throw 'Configured intranet URL is missing or invalid.'}
  $approved+= $intranetUri.Host.ToLowerInvariant()
  if(-not $intranetUri.IsDefaultPort){$approved+=($intranetUri.Host.ToLowerInvariant()+':'+$intranetUri.Port)}
  $approved+= @('discord.com','[*.]discord.com','discord.gg','[*.]discord.gg','cdn.discordapp.com','[*.]discordapp.com','edge://policy','chrome://policy')
  # URLBlocklist '*' also covers browser internal URLs; explicitly permit diagnostics.
  # Browser policies may not take effect until guest browser restart or sign-out/in.
  # Existing snapshots are never overwritten; Restore before applying a changed profile.
  if($approved.Count -eq 0){throw 'Browser blocking needs at least one approved website.'}
  $index=1
  foreach($url in ($approved|Select-Object -Unique)){Put 'Software\Policies\Microsoft\Edge\URLAllowlist' ([string]$index) $url 'String';$index++}
  $index=1
  foreach($url in ($approved|Select-Object -Unique)){Put 'Software\Policies\Google\Chrome\URLAllowlist' ([string]$index) $url 'String';$index++}
  # Security invariant: both allowlists must be written before wildcard URL blocking.
  Put 'Software\Policies\Google\Chrome\URLBlocklist' '1' '*' 'String'
  Put 'Software\Policies\Microsoft\Edge\URLBlocklist' '1' '*' 'String'
 }
 return $l.ToArray()
}
function Find-Sid($sid){
 if($sid -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Invalid local account SID.'}
 $account=Get-CimInstance Win32_UserAccount -Filter "SID='$sid' AND LocalAccount=True" |Select-Object -First 1
 if(-not $account -or $account.Disabled){throw 'Guest account missing or disabled.'}
 $adminMembers=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
 foreach($member in $adminMembers){if($member.SID -and $member.SID.Value -eq $sid){throw 'Refusing to restrict an administrator account.'}}
 if($sid -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Refusing to restrict the current administrator.'}
 return $account
}
function Read-Backup($path){if(-not(Test-Path -LiteralPath $path)){throw 'Recovery backup file not found.'};return Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json}
function Restore-Backup([string]$path){
 $b=Read-Backup $path
 $h=$null
 try{
  $h=Open-Hive ([string]$b.sid)
  foreach($record in @($b.before)){
   if($record.Exists){
    $v=$record.Value;if($record.Kind -eq 'DWord'){$v=[int]$v};if($record.Kind -eq 'MultiString'){$v=[string[]]@($v)}
    Registry-Write $h $record.Path $record.Name $v $record.Kind
   }else{Registry-Delete $h $record.Path $record.Name}
  }
 }finally{if($h){Close-Hive $h}}
 # Read back every changed key before reporting a successful restore. This is a registry-level check; Windows may still need guest sign-out.
 $h=$null
 try{
  $h=Open-Hive ([string]$b.sid)
  foreach($record in @($b.before)){
   $now=Registry-Read $h $record.Path $record.Name
   if([bool]$now.Exists -ne [bool]$record.Exists){throw "RESTORE VERIFICATION FAILED (existence): $($record.Path) $($record.Name)"}
   if($record.Exists -and ($now.Kind -ne $record.Kind -or (($now.Value | ConvertTo-Json -Compress) -ne ($record.Value | ConvertTo-Json -Compress)))){throw "RESTORE VERIFICATION FAILED (value): $($record.Path) $($record.Name)"}
  }
 } finally{if($h){Close-Hive $h}}
 # Old snapshot records may omit restoredAt. ConvertFrom-Json produces PSCustomObject;
 # use Add-Member instead of assigning a missing property under Strict/ErrorAction Stop.
 if($b.PSObject.Properties['status']){$b.status='restored'}else{$b | Add-Member -NotePropertyName status -NotePropertyValue 'restored'}
 $restoredTime=(Get-Date).ToString('o')
 if($b.PSObject.Properties['restoredAt']){$b.restoredAt=$restoredTime}else{$b | Add-Member -NotePropertyName restoredAt -NotePropertyValue $restoredTime}
 $b|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $path -Encoding UTF8
 if(Test-Path -LiteralPath $Pointer){Remove-Item -LiteralPath $Pointer -Force -ErrorAction SilentlyContinue}
 $task=[string]$b.task
 if($task){try{Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction Stop}catch{Write-Log "WARN could not unregister task: $($_.Exception.Message)"}}
 Write-Log "Restored snapshot: $path"
}
try{
 Assert-Admin; Ensure-Root
 if($Operation -eq 'Restore'){
  if(-not $BackupPath){if(-not(Test-Path -LiteralPath $Pointer)){throw 'No active policy snapshot to restore.'};$ptr=Get-Content -LiteralPath $Pointer -Raw|ConvertFrom-Json;$BackupPath=[string]$ptr.path}
  Restore-Backup $BackupPath;exit 0
 }
 if(-not $ProfilePath -or -not(Test-Path -LiteralPath $ProfilePath)){throw 'Profile configuration not found.'}
 if($Operation -eq 'Verify'){
  $account=Find-Sid $TargetSid
  $p=Get-Content -LiteralPath $ProfilePath -Raw -Encoding UTF8|ConvertFrom-Json
  if([string]$p.account -ne [string]$account.Name){throw 'Selected profile account does not match the verified standard-user SID.'}
  $changes=@(Get-Changes $p)
  if($changes.Count -eq 0){throw 'Select one or more supported restrictions before verifying.'}
  $h=$null;$details=@();$matched=0
  try{
   $h=Open-Hive $TargetSid
   foreach($c in $changes){
    $actual=Registry-Read $h $c.Path $c.Name
    $same=([bool]$actual.Exists -and [string]$actual.Kind -eq [string]$c.Kind -and [string]$actual.Value -eq [string]$c.Value)
    if($same){$matched++}
    $details+=($(if($same){'MATCH'}else{'MISSING/DIFFERENT'})+': '+$c.Path+' / '+$c.Name)
   }
  }finally{if($h){Close-Hive $h}}
  $groups=[ordered]@{}
  foreach($item in $changes){
   $category=if($item.Path -match 'Google\\Chrome'){'Chrome'}elseif($item.Path -match 'Microsoft\\Edge'){'Edge'}elseif($item.Name -eq 'NoControlPanel'){'Control Panel'}elseif($item.Name -eq 'DisableCMD'){'Command Prompt'}elseif($item.Name -eq 'DisableRegistryTools'){'Registry Editor'}else{'Other'}
   if(-not $groups.Contains($category)){$groups[$category]=[ordered]@{matched=0;total=0}}
   $groups[$category].total++
  }
  # Count category matches from the same read-only verification details.
  for($i=0;$i -lt $changes.Count;$i++){
   $item=$changes[$i]
   $category=if($item.Path -like '*Google\Chrome*'){'Chrome'}elseif($item.Path -like '*Microsoft\Edge*'){'Edge'}elseif($item.Name -eq 'NoControlPanel'){'Control Panel'}elseif($item.Name -eq 'DisableCMD'){'Command Prompt'}elseif($item.Name -eq 'DisableRegistryTools'){'Registry Editor'}else{'Other'}
   if($details[$i] -like 'MATCH:*'){$groups[$category].matched++}
  }
  $result=[ordered]@{sid=$TargetSid;account=$account.Name;checkedAt=(Get-Date).ToString('o');applied=($matched -eq $changes.Count);matchCount=$matched;total=$changes.Count;groups=$groups;details=$details}
  $resultDir=Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent'
  if(-not(Test-Path -LiteralPath $resultDir)){New-Item -ItemType Directory -Path $resultDir -Force|Out-Null}
  $result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $resultDir 'verification.json') -Encoding UTF8
  Write-Log "Read-only policy verification: $($account.Name) $matched/$($changes.Count)"
  exit 0
 }
 if(Test-Path -LiteralPath $Pointer){throw 'A previous policy snapshot is registered. Restore it first before reapplying restrictions.'}
 $account=Find-Sid $TargetSid
 $p=Get-Content -LiteralPath $ProfilePath -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$p.account -ne [string]$account.Name){throw 'Selected profile account does not match verified target SID.'}
 $changes=@(Get-Changes $p)
 if($changes.Count -eq 0){throw 'No supported restrictions have been selected.'}
 $h=$null;$before=@()
 try{
  $h=Open-Hive $TargetSid
  foreach($c in $changes){$old=Registry-Read $h $c.Path $c.Name;$before+=@{Path=$c.Path;Name=$c.Name;Exists=$old.Exists;Value=$old.Value;Kind=$old.Kind}}
 }finally{if($h){Close-Hive $h}}
 $guid=[guid]::NewGuid().ToString('N')
 $task=if($Operation -eq 'Trial'){'RKA-Lockdown-AutoRestore-'+$guid}else{''}
 $backup=Join-Path $Root ("snapshot-$guid.json")
 $record=[ordered]@{sid=$TargetSid;account=$account.Name;createdAt=(Get-Date).ToString('o');status='prepared';task=$task;before=$before;changes=$changes}
 $record|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $backup -Encoding UTF8
 Copy-Item -LiteralPath $PSCommandPath -Destination $WorkerFile -Force
 $exe=Join-Path $PSHOME 'powershell.exe'
 $arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$WorkerFile+'" -Operation Restore -BackupPath "'+$backup+'"'
 if($Operation -eq 'Trial'){
  $action=New-ScheduledTaskAction -Execute $exe -Argument $arguments
  $trigger=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5)
  $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $st=New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Description 'Emergency restoration of RKA test settings'
  Register-ScheduledTask -TaskName $task -InputObject $st -Force -ErrorAction Stop |Out-Null
 }
 $pointerData=@{path=$backup;task=$task;mode=$Operation;expiry=if($Operation -eq 'Trial'){(Get-Date).AddMinutes(5).ToString('o')}else{$null}}
 $pointerData|ConvertTo-Json|Set-Content -LiteralPath $Pointer -Encoding UTF8
 $h=$null
 try{
  $h=Open-Hive $TargetSid
  foreach($c in $changes){Registry-Write $h $c.Path $c.Name $c.Value $c.Kind}
 }catch{
  Write-Log "Apply failed; restoring backup immediately: $($_.Exception.Message)"
  if($h){Close-Hive $h;$h=$null}
  Restore-Backup $backup
  throw
 }finally{if($h){Close-Hive $h}}
 $record.status='active';$record|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $backup -Encoding UTF8
 Write-Log "$Operation active for $TargetSid; changes=$($changes.Count); rollback task=$task"
 exit 0
}catch{
 Write-Log "FAILED $Operation : $($_.Exception.ToString())"
 try{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'RKA Policy Worker','OK','Error')|Out-Null}catch{}
 exit 1
}
