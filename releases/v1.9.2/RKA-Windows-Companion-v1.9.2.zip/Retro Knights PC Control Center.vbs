Option Explicit
Dim shell, fs, dir, script, args
Set fs = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("Shell.Application")
dir = fs.GetParentFolderName(WScript.ScriptFullName)
script = dir & "\Application\RKA-WPF.ps1"
args = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File " & Chr(34) & script & Chr(34)
shell.ShellExecute "powershell.exe", args, dir & "\Application", "runas", 0
