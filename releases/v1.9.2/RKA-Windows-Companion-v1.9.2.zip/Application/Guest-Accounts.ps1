# Retro Knights Arcade - admin guest accounts (Companion 1.9.1), Windows PowerShell 5.1.
#
# Staff can pick an administrator account as the guest, so customers can answer
# Yes when a game asks Windows to run as administrator. Standard accounts are
# guests as before and are never listed here. The list sits in a folder only
# SYSTEM and Administrators can change, and is ignored unless SYSTEM or an
# administrator wrote it.
#
# An administrator can remove the lockdown, so for admin guests the lockdown's
# registry values are saved after every staff change (Companion window or
# Control Room) and the agent puts back anything missing, about once a minute
# while the guest is signed in. Unlock everything clears the saved copy.
#Requires -Version 5.1
$script:RkaGuestDir=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Guests'
$script:RkaAdminGuestFile=Join-Path $script:RkaGuestDir 'admin-guests.json'
$script:RkaRepairFile=Join-Path $script:RkaGuestDir 'repairs.json'
# The lockdown's registry values all live under these two keys of the guest's hive.
$script:RkaPolicyRoots=@('Software\Policies','Software\Microsoft\Windows\CurrentVersion\Policies')

function Get-RkaAdminSids {
 return @(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop|Where-Object {$_.SID}|ForEach-Object {$_.SID.Value})
}
function Test-RkaTrustedOwner([string]$path){
 try{
  $owner=(Get-Acl -LiteralPath $path).GetOwner([Security.Principal.SecurityIdentifier]).Value
  if($owner -in @('S-1-5-18','S-1-5-32-544')){return $true}
  return ((Get-RkaAdminSids) -contains $owner)
 }catch{return $false}
}
function Initialize-RkaGuestDir {
 if(-not(Test-Path -LiteralPath $script:RkaGuestDir)){New-Item -ItemType Directory -Path $script:RkaGuestDir -Force|Out-Null}
 & "$env:SystemRoot\System32\icacls.exe" $script:RkaGuestDir '/setowner' '*S-1-5-32-544'|Out-Null
 & "$env:SystemRoot\System32\icacls.exe" $script:RkaGuestDir '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F'|Out-Null
 if($LASTEXITCODE -ne 0){throw 'Could not protect the admin guest folder.'}
}
function Write-RkaGuestJson([string]$path,$value){
 Initialize-RkaGuestDir
 $tmp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{
  [IO.File]::WriteAllText($tmp,($value|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination $path -Force
 }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}}
}
function Read-RkaGuestJson([string]$path){
 if(-not(Test-Path -LiteralPath $path -PathType Leaf)){return $null}
 if(-not(Test-RkaTrustedOwner $path)){return $null}
 try{return (Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json)}catch{return $null}
}
function Get-RkaAdminGuests {
 $d=Read-RkaGuestJson $script:RkaAdminGuestFile
 if(-not $d){return @()}
 return @(@($d.guests)|Where-Object {$_ -and [string]$_.sid -match '^S-1-5-21-(\d+-){3}\d+$' -and [string]$_.sid -notmatch '-(500|501|503|504)$'}|ForEach-Object {
  [pscustomobject]@{sid=[string]$_.sid;name=[string]$_.name;addedUtc=[string]$_.addedUtc;by=[string]$_.by}
 })
}
function Test-RkaAdminGuest([string]$sid){
 if(-not $sid){return $false}
 return (@(Get-RkaAdminGuests|Where-Object {$_.sid -ceq $sid}).Count -gt 0)
}
# A lockdown target: a standard account, or an administrator staff chose as the guest.
function Test-RkaGuestTarget([string]$sid,[string[]]$adminSids){
 return (($adminSids -notcontains $sid) -or (Test-RkaAdminGuest $sid))
}
function Test-RkaRunningAsAdminGuest {
 return (Test-RkaAdminGuest ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value))
}
function Add-RkaAdminGuest([string]$sid,[string]$name,[string]$by='Companion'){
 if($sid -notmatch '^S-1-5-21-(\d+-){3}\d+$' -or $sid -match '-(500|501|503|504)$'){throw 'That account cannot be the guest.'}
 if($sid -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'The account running this cannot be the guest.'}
 $list=@(Get-RkaAdminGuests|Where-Object {$_.sid -cne $sid})
 $list+=[pscustomobject]@{sid=$sid;name=$name;addedUtc=[DateTime]::UtcNow.ToString('o');by=$by}
 Write-RkaGuestJson $script:RkaAdminGuestFile @{guests=@($list)}
 try{Save-RkaPolicySnapshot $sid}catch{}
}
function Remove-RkaAdminGuest([string]$sid){
 $list=@(Get-RkaAdminGuests|Where-Object {$_.sid -cne $sid})
 Write-RkaGuestJson $script:RkaAdminGuestFile @{guests=@($list)}
 Clear-RkaPolicySnapshot $sid
}

# The guest's registry: already loaded while they're signed in, else loaded from NTUSER.DAT.
function Open-RkaGuestHive([string]$sid,[bool]$loadIfNeeded){
 $usr=[Microsoft.Win32.Registry]::Users
 $h=$usr.OpenSubKey($sid,$true)
 if($h){return [pscustomobject]@{Key=$h;Mount=$null}}
 if(-not $loadIfNeeded){return $null}
 $p=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop|Select-Object -First 1
 if(-not $p -or -not $p.LocalPath){return $null}
 $dat=Join-Path $p.LocalPath 'NTUSER.DAT'
 if(-not(Test-Path -LiteralPath $dat)){return $null}
 $mount='RKA_GUESTS_'+([guid]::NewGuid().ToString('N'))
 & reg.exe load "HKU\$mount" $dat|Out-Null
 if($LASTEXITCODE -ne 0){return $null}
 return [pscustomobject]@{Key=$usr.OpenSubKey($mount,$true);Mount=$mount}
}
function Close-RkaGuestHive($h){
 if(-not $h){return}
 if($h.Key){$h.Key.Dispose()}
 if($h.Mount){[gc]::Collect();[gc]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 200;& reg.exe unload "HKU\$($h.Mount)"|Out-Null}
}
function Get-RkaPolicyValues($hiveKey){
 $out=New-Object System.Collections.ArrayList
 $walk={
  param($key,[string]$path)
  foreach($n in $key.GetValueNames()){
   $kind=$key.GetValueKind($n).ToString()
   $v=$key.GetValue($n,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
   if($kind -eq 'Binary'){$v=[Convert]::ToBase64String([byte[]]$v)}
   elseif($kind -eq 'MultiString'){$v=@([string[]]$v)}
   elseif($kind -in @('DWord','QWord')){$v=[string]$v}
   elseif($kind -notin @('String','ExpandString')){continue}
   [void]$out.Add([pscustomobject]@{path=$path;name=$n;kind=$kind;value=$v})
  }
  foreach($s in $key.GetSubKeyNames()){
   $sub=$key.OpenSubKey($s)
   if($sub){try{& $walk $sub ($path+'\'+$s)}finally{$sub.Dispose()}}
  }
 }
 foreach($root in $script:RkaPolicyRoots){
  $k=$hiveKey.OpenSubKey($root)
  if($k){try{& $walk $k $root}finally{$k.Dispose()}}
 }
 return $out.ToArray()
}
function Get-RkaSnapshotPath([string]$sid){return (Join-Path $script:RkaGuestDir ($sid+'.policies.json'))}
# After a staff change: what the guest's lockdown should look like.
function Save-RkaPolicySnapshot([string]$sid){
 if(-not(Test-RkaAdminGuest $sid)){return}
 $h=Open-RkaGuestHive $sid $true
 if(-not $h -or -not $h.Key){Close-RkaGuestHive $h;return}
 try{$values=@(Get-RkaPolicyValues $h.Key)}finally{Close-RkaGuestHive $h}
 Write-RkaGuestJson (Get-RkaSnapshotPath $sid) @{sid=$sid;savedUtc=[DateTime]::UtcNow.ToString('o');values=@($values)}
}
function Clear-RkaPolicySnapshot([string]$sid){
 $p=Get-RkaSnapshotPath $sid
 if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue}
}
function Test-RkaSameValue($current,$kind,$saved){
 if($null -eq $current){return $false}
 switch($kind){
  'Binary' {return ([Convert]::ToBase64String([byte[]]$current) -ceq [string]$saved)}
  'MultiString' {return ((@([string[]]$current) -join "`n") -ceq (@($saved|ForEach-Object {[string]$_}) -join "`n"))}
  default {return ([string]$current -ceq [string]$saved)}
 }
}
# Puts back any saved lockdown value that is missing or changed. Only while the
# guest is signed in (their registry can't change otherwise). Returns how many.
function Repair-RkaPolicySnapshot([string]$sid){
 if(-not(Test-RkaAdminGuest $sid)){return 0}
 $snap=Read-RkaGuestJson (Get-RkaSnapshotPath $sid)
 if(-not $snap -or [string]$snap.sid -cne $sid){return 0}
 $h=Open-RkaGuestHive $sid $false
 if(-not $h -or -not $h.Key){return 0}
 $fixed=@()
 try{
  foreach($e in @($snap.values)){
   $path=[string]$e.path;$name=[string]$e.name;$kind=[string]$e.kind
   if(-not $path -or $kind -notin @('String','ExpandString','DWord','QWord','Binary','MultiString')){continue}
   if(-not(@($script:RkaPolicyRoots|Where-Object {$path -eq $_ -or $path.StartsWith($_+'\')}).Count)){continue}
   $k=$h.Key.CreateSubKey($path)
   try{
    $cur=$k.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $curKind=$(if($null -ne $cur){$k.GetValueKind($name).ToString()}else{''})
    if($curKind -eq $kind -and (Test-RkaSameValue $cur $kind $e.value)){continue}
    switch($kind){
     'Binary' {$k.SetValue($name,[Convert]::FromBase64String([string]$e.value),[Microsoft.Win32.RegistryValueKind]::Binary)}
     'MultiString' {$k.SetValue($name,[string[]]@($e.value|ForEach-Object {[string]$_}),[Microsoft.Win32.RegistryValueKind]::MultiString)}
     'DWord' {$k.SetValue($name,[int][int64][string]$e.value,[Microsoft.Win32.RegistryValueKind]::DWord)}
     'QWord' {$k.SetValue($name,[int64][string]$e.value,[Microsoft.Win32.RegistryValueKind]::QWord)}
     default {$k.SetValue($name,[string]$e.value,[Microsoft.Win32.RegistryValueKind]$kind)}
    }
    $fixed+=($path+'\'+$name)
   }finally{$k.Dispose()}
  }
 }finally{Close-RkaGuestHive $h}
 if($fixed.Count){
  $prev=Read-RkaGuestJson $script:RkaRepairFile
  $total=0;try{if($prev -and [string]$prev.sid -ceq $sid){$total=[int]$prev.total}}catch{}
  Write-RkaGuestJson $script:RkaRepairFile @{sid=$sid;lastUtc=[DateTime]::UtcNow.ToString('o');lastCount=$fixed.Count;total=($total+1);last=@($fixed|Select-Object -First 20)}
 }
 return $fixed.Count
}
# Agent: a PC whose guest became an administrator before Companion 1.9.1 is
# adopted only when everything still points at it: it's the account the saved
# remote lockdown was approved for (only allowed for standard accounts) AND
# Windows signs into it automatically. Anything else waits for staff.
function Find-RkaGuestToAdopt([string]$approvedProfilePath){
 if(@(Get-RkaAdminGuests).Count){return $null}
 if(-not(Test-Path -LiteralPath $approvedProfilePath)){return $null}
 try{$name=[string](Get-Content -LiteralPath $approvedProfilePath -Raw -Encoding UTF8|ConvertFrom-Json).account}catch{return $null}
 if(-not $name){return $null}
 $w=Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction SilentlyContinue
 if([string]$w.AutoAdminLogon -ne '1' -or [string]$w.DefaultUserName -ine $name){return $null}
 $a=Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop|Where-Object {$_.Name -ieq $name -and -not $_.Disabled}|Select-Object -First 1
 if(-not $a -or [string]$a.SID -notmatch '^S-1-5-21-(\d+-){3}\d+$' -or [string]$a.SID -match '-(500|501|503|504)$'){return $null}
 if((Get-RkaAdminSids) -notcontains [string]$a.SID){return $null}
 return [pscustomobject]@{sid=[string]$a.SID;name=[string]$a.Name}
}
