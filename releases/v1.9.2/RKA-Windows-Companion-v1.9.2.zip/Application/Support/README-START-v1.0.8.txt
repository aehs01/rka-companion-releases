Retro Knights Arcade — Windows Companion v1.0.8

RELEASE STATUS: Windows 10/11 PowerShell 5.1; STATICALLY TESTED, not yet live-tested on RKA PCs. Pilot on RKA4 or a spare PC before others.

UPGRADE WITH ONE ZIP FOR ALL EIGHT PCS:
1. Download the official ZIP ONCE using your signed-in GitHub account. Save the identical ZIP onto a trusted, admin-accessible LAN share, for example \\rkaserver\RKAUpdates\ (read-only for other accounts).
2. On each PC sign into a separate Windows administrator account; launch the EXISTING Companion as admin from the same permanent folder (do not launch from the ZIP).
3. Settings > Software Updates > Install Trusted Release ZIP (Local / LAN). Browse to the official ZIP and approve after checking the shown file path and SHA-256 with the official published checksum.
4. The installer backs up overwritten program files to secured ProgramData, updates the app files IN PLACE, and—IF this PC is already Lovable enrolled—rebuilds BOTH background tasks with Remote-Setup's backup/rollback. No re-enrollment or guest/profile reset is intended.
5. Close the old window after the upgrade, reopen the admin Control Center, check v1.0.8, then Lovable Connection > Check Remote Status: Installed SYSTEM agent file v1.0.8 AND fresh authenticated v1.0.8 poll.
6. Pilot remote Chrome and Edge ALLOW/BLOCK, approved websites changes, local Restore Previous Settings, desktop shortcut copy, game compatibility scan. Test USB storage and LAN functionality before upgrading the remaining PCs.

UPDATES NOTE: Future optional HTTPS feed can CHECK and DOWNLOAD/STAGE a release ZIP without GitHub login if a trusted gateway is configured. This release does not contain credentials, unconditionally trust a feed's checksum, or silently install remote code. No private GitHub release can be downloaded anonymously without a separate gateway. No publisher signing certificate is configured. Always verify downloaded ZIP SHA-256 against a separately obtained official checksum; do not install arbitrary ZIPs.

FIXES:
- Agent v1.0.8 allows locally approved individual remote policies and website lists on PCs already having a full local snapshot, journaling original registry keys INTO the existing protected recovery file for accurate rollback. Does not delete the existing recovery pointer.
- Administrator-to-guest .lnk/.url desktop copy, safe skips for admin utilities, private AppData targets and existing shortcuts. No elevation or execution implied.
- Read-only guest game/startup elevation hints. Does NOT claim to identify every game needing UAC or grant games permanent admin privilege.
- Admin-triggered update from a ZIP on disk or LAN path (manually approved, checksum shown, backup, rollback attempt, enrolled agent task upgrade).

BACKUPS: program ZIP backup stored in C:\ProgramData\RKA-Lockdown-Agent\Updater\Backup-..., full policy restore snapshot retained under ...\Recovery\, remote task backups ...\RemoteControl\UpgradeBackup-....
Never delete recovery files or share enrollment token contents. Keep administrator recovery access.
