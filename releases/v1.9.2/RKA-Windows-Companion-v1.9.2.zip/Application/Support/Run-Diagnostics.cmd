@echo off
cd /d "%~dp0"
echo Starting Retro Knights Arcade Lockdown Agent v0.2.1 with visible console...
echo The console should REMAIN OPEN while the agent interface is running or hidden in the system tray.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0RKA-Lockdown.ps1"
echo.
echo Application exited with code %ERRORLEVEL%.
echo Logs: %%LOCALAPPDATA%%\RKA-Lockdown-Agent\
pause
