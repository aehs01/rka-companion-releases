RKA WINDOWS COMPANION v0.4.5 — TEST BUILD

NORMAL USE
  Launch-RKA.cmd                 Normal WPF launch, no persistent PowerShell console; requests administrator elevation.
  Launch-RKA-WPF.cmd             Equivalent WPF launch; retained for familiarity.
  Create-Control-Center-Shortcut.cmd   Creates Retro Knights PC Control Center on CURRENT administrator desktop with RKA icon.

RECOVERY / DIAGNOSTICS (ADMINISTRATORS ONLY)
  Emergency-Restore.cmd          Restore prior guest policy snapshot if present; keep a separate admin login.
  RESTORE-USB-STORAGE.cmd        Restore system-wide USB storage policy from protected snapshot.
  Launch-RKA-WPF-Debug.cmd       Deliberately opens PowerShell console to show startup errors.
  Run-Diagnostics.cmd            Collect local diagnostics; not the normal launcher.
  RUN-PREFLIGHT.cmd              Check local prerequisites before rollout.
  CHECK-LOVABLE-CONNECTION.cmd   Read current connection/heartbeat state.
  RUN-LOVABLE-SETUP.cmd          Remote setup, admin only; do not re-enroll unless necessary.
  Launch-RKA-Legacy.cmd          Old interface fallback only; avoid running concurrently.
  Other scripts (.ps1/.vbs) are backend components; do not launch them casually.

IMPORTANT
- This build fixes LOCAL UX/USB restore and browser allowlist diagnostics. It DOES NOT add new remote typed commands.
- To update an active browser allowlist, use Emergency Restore / Restore Previous Settings FIRST, then save the list and Apply again. An active protected snapshot prevents reapply by design.
- Guest browser policy may require browser restart or Windows sign-out/in.
- The built-in edge://policy and chrome://policy pages are explicitly allowed by this build, but real browser behavior needs testing.
- A registry match does not prove that an allowed URL loads. Chromium policy precedence, existing machine policies, extensions, redirects and profile state can affect it.
- USB policy affects all users. No snapshot + no active Deny_All=1 now returns Already restored; an active block without a snapshot still errors for safety.
- Remote agent is retained from v0.4.4; per-feature remote commands and shutdown await compatible Lovable/agent protocol. Do not publish the new remote controls without agent support.
- Test on one laptop first; keep v0.4.4 and an admin recovery route.
