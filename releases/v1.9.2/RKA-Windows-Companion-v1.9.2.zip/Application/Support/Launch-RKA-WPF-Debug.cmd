@echo off
cd /d "%~dp0"
echo RKA Windows Companion v0.4.5 diagnostic launcher
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0RKA-WPF.ps1"
if errorlevel 1 pause
