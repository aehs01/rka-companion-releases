## v0.2.1 test scope (2026-10-19)
- Admin-only UI; corrected AutoLogon.zip; registry readback on restoration; explicit persistent mode behind recovery confirmation; shared desktop shortcut file backup/restore (not icon layout lock); optional outbound-only Lovable heartbeat pilot.
- Pending: verify Windows Home functionality; enroll in Lovable, status and revocation; read-only heartbeat must never imply PROTECTED.
- Defer Windows 98/XP V3-style HTML notice and Windows 98/XP companion to separate milestone; original notices not yet recovered or confirmed.

# RETRO KNIGHTS ARCADE — LAN & WINDOWS COMPANION ROADMAP
Updated: 2026-10-19. Canonical living Google Doc: https://docs.google.com/document/d/1pq6-ZW046zaNH7ld2wM8LP_lwb0A2ywx2HqCyq-FeGc/edit

## Latest builds
- RKA Windows Companion / Lockdown Agent **v0.2.0 TEST** — test laptop only; policies reversible on a five-minute timer. See Google Drive release folder for the downloadable ZIP.
- Retro Knights LAN WordPress theme **v1.0.0** — user-tested downloads and game deployment. See release folder for the theme ZIP.
- Google Drive release folder: https://drive.google.com/drive/folders/1W5u2uY60sIVgZBa3cZM4xNVDKWQNX6T8

## Released and testable
- Portal v1.0.0: modern V3 design, WPDM package gallery/list/search and detail pages, live ALP WPCode LAN server listings, Battlelog/PvPGN/tournaments/Discord URLs and original downloader.
- Companion v0.1.4: persistent tray and diagnostics on user's main Windows computer; no enforcement.
- Companion v0.2.0 TEST: V3 theme and official knight emblem icon/desktop shortcut, fixed account dropdown, http://rkaserver/ open button and editable destination; default Discord URLs; signed Microsoft Sysinternals Autologon setup launcher; admin-only five-minute user-scoped policy trial with independently scheduled SYSTEM restore, emergency manual restore. NOT verified on live Windows. NOT production lockdown.

## Roadmap next steps (ordered)
### P0 — safe client pilot and rollback validation
1. Test on spare Windows 11 Home laptop as LOCAL ADMIN; confirm account scan and minimize to tray.
2. Make local standard RKA-Guest, sign in once, sign out; confirm SID and non-admin classification.
3. Test Open Intranet and default Discord links; adjust hostname later as needed.
4. Test Auto Sign-In via Microsoft utility with local guest password; confirm Shift/bypass and Disable controls and admin recovery; do not auto-sign-in an admin.
5. With backup and task scheduler enabled, trial Settings/CMD/Regedit (one at a time) on guest. Confirm **manual rollback** restores original values and access, then test unattended five-minute rollback. Do not use permanent enforcement until proved.
6. Repeat Windows 10 compatibility on a spare device (temporary use only; security support caveat).

### P1 — hardening after test validation
- Replace PowerShell UI with a signed, installer-backed compiled application and admin-owned service; no policy authority in guest session.
- Guest-account isolation; prevent tampering with game folders and removal of installed games using Windows ACLs (don't assume regedit policies are full app restrictions).
- App allowlist for approved launchers/games, with safe maintenance override; verify Windows 11 Home support and anti-cheat compatibility.
- Edge URL allowlist plus Discord web/voice testing. Admin-confirm before removing core Discord origins.
- Secure, logged time-bounded maintenance sessions and robust reboot persistence/recovery.

### P2 — connect intranet ↔ local companion
- Build a **read-only** localhost/device status interface that identifies connected agent and installed/launchable approved games; trusted origin and signed/nonce-authenticated requests only. Do not expose over guest LAN. Browser can show "Ready to Play" vs "Ask Staff" based on verified local information.
- Portal homepage launcher cards: map stable IDs `steam`, `epic`, `gog`, `battlenet` to locally approved executable targets; never accept arbitrary file paths or command lines from webpage.
- Portal game detail: `Play` only when verified installed; fallback desktop shortcut instructions (v1.0.0 already implemented), staff requests for noninstalled games. Respect short storage limits per PC and LAN Party Toolkit's existing deployment features.
- Coordinate ALP game ID ↔ WPDM package ID ↔ client launcher ID; do not assume ALP server packages mean a game is installed on the customer PC.

### P3 — Lovable dashboard + fleet operation
- Build secure enrollment for an arbitrary number of Windows Home client agents, device health and status, trusted local owner login, version, policy test state.
- From existing Lovable Employee Checklist > PC Management, staff can see device status and approve/install game requests, request maintenance overrides with expiry. Avoid arbitrary remote command execution. Preserve LAN Party Toolkit's deployment, shortcuts, timed stations, wallpaper and PC lifecycle operations.
- Versioned signed update channel + compatibility matrix; health monitoring and audit.

## Release archive
- Companion v0.2.0 — first Windows policy *test* release (not verified).
- Companion v0.1.4 — tray-stable read-only diagnostics.
- Intranet v1.0.0 — first user-tested theme release.
- Intranet v0.1.10 — staging build preceding 1.0.0; same functional code.

## Operational constraints
- User's gaming PCs are mostly Windows 11 Home, possibly one Windows 10 PC; mostly standard guest accounts that will auto sign in, separate administrator credentials, station disks around 1–2 TB. Test under Home; Windows 10 is beyond normal support since Oct 14, 2025.
- ALP stays responsible for server package publication and queries; LAN Party Toolkit responsible for deployments and shortcuts. Intranet is public-facing only on trusted LAN; RKA companion handles local Windows restrictions and launch control. No auto-download/delete by public customers.
- `tyrant` is temporary testing host, `rkaserver` future production hostname; changing hostname must include WordPress/ALP configs and HTTPS authentication.
- User will upload new versions to Google Drive; keep old ZIPs in Release Archive and update top current links and log every release.


## v0.3.0 Beta offline additions
- Read-only health/preflight with account role inventory, OS/uptime/disk/RAM, Chrome and scheduled tasks.
- Admin-only profile export/import (no tokens or credentials).
- Diagnostics & Backup GUI tab and RUN-PREFLIGHT.cmd fallback.
- Remote commands specified but deliberately NOT enabled without agent-side authentication, replay defense and SID verification.
- Next: test Windows UI and actual agent heartbeat/Chrome, then implement secure server/agent command channel in a separate test cycle.


## v0.3.1 BETA — Startup bug fix (2026-10-19)
- v0.3.0 Windows screenshot confirmed RKA Startup Error: CommandNotFoundException New-Check. Moved helper declaration before initial Chrome UI usage.
- Other features unchanged. Verify GUI, all tabs and heartbeat without re-enrolling on Windows laptop.


## v0.3.2 Windows laptop feedback hotfix (October 19, 2026)
GUI startup/tray/accounts/links/health and profile export/import passed v0.3.1 testing. Failing: standalone preflight had error, local heartbeat check was not visibly interactive, Chrome installer flashed console then exited, Save Settings was mistakenly interpreted as applying guest policy. New v0.3.2: persistent preflight error log, visible heartbeat details, Chrome installer exit code and persistent log + protected worker path, explicit Save Profile Only vs Apply Restrictions, no timed trial UI, policy Verify based on target guest registry values, manual restore with independent admin confirmation. Windows runtime retest required. Remote commands remain disabled.


## v0.4.0 WPF/.NET UI preview — October 19, 2026

- Implemented independent modern WPF XAML + Windows PowerShell 5.1 host, borderless neon admin dashboard matching approved design direction, with separate navigation, user restrictions/observed guest SID policy status, Chrome Startup, Lovable Connection, Game Installers, and Diagnostics/backup. No compiled EXE; WinForms available through legacy launcher.
- Fixed Chrome-Portal-Setup.ps1 case-insensitive validated `$Action` reassignment to scheduled task action (`$taskAction`), desktop shortcut script `$HOME` read-only variable, and JSON policy restore missing `restoredAt` member.
- WPF status green/red/amber is local registry observation, not a server-side protection attestation. No automatic Windows application allowlisting, USB execution blocking, or remote command execution added.
- Copy of existing .ps1 backend/heartbeat present and earlier encrypted machine credential untouched.
- Automated checks: XAML XML parsing, named control bindings, backend bug-signature checks, archive integrity. Windows rendering, UAC, task execution, policy restore and Chrome sign-in require a supervised laptop smoke test.
- First release step after WPF UI sign-off: consider compiled .NET 8 WPF EXE and installer; only then migrate backend to structured C# service with authenticated remote command protocol.

## v0.4.3 WPF Remote Test release
- Added first local Windows Remote-Agent.ps1 + Remote-Setup.ps1 to connect deployed Lovable Partner Dashboard LAN Management typed command API. Independent protected SYSTEM scheduled task (once/minute, 3 polls/run) reuses existing DPAPI machine token without re-enrollment; reports version 0.4.3-TEST only when installed.
- Supported agent commands: refresh_diagnostics (read-only), restart_pc (90s scheduled with local opt-in), apply_guest_policy (only previously locally synced profile and verified nonadmin SID, local opt-in), restore_guest_policy (only matching SID snapshot, local opt-in). Agent command IDs are recorded before execution to prevent repeat after crash; nonce/TTL/scope/replay settled on Lovable server. Queueing is NOT successful execution.
- Administrator-only Remote Management controls in WPF Lovable Connection tab: Enable Diagnostics, Allow/Disable PC Changes, Sync Guest Policy, Disconnect Remote Commands, Check Status. Changes disabled by default.
- Administrator-only USB Storage Block/Restore controls via a separate machine-wide HKLM removable-storage registry policy with exact protected backup; not USB HID lockout, not verified on Windows Home. Independent USB recovery CMD added.
- Original provided RKA logo used for UI/tray/guest intranet icon. Browser allowlist/Discord installer and guest empty-state changes from v0.4.2 retained.
- Not a compiled EXE; WPF/.NET Framework hosted by PowerShell 5.1. All features await real Windows runtime and security testing. No device or policy actually modified by packaging. Use laptop only.
