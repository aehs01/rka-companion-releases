RKA WINDOWS COMPANION v0.4.1 — MODERN WPF (.NET) BETA
====================================================================

WHAT THIS IS
- A genuine WPF desktop UI built with Microsoft's .NET PresentationFramework/XAML.
- It runs through Windows PowerShell 5.1 as the WPF host, to avoid a new .NET SDK/runtime installation during testing. It is NOT a compiled standalone .exe yet.
- The design approximates the dark/neon UI concept; final fonts, emoji/icon renderings, screen scaling and window effects must be tested on Windows.
- It reuses the existing v0.3.2 PowerShell policy, heartbeat, Chrome and diagnostics backends. Backends were not converted to C# yet.
- The backend remains local-only for policy updates. Remote commands from Lovable are NOT active.

FIRST LAUNCH (TEST LAPTOP ONLY)
1. Keep your existing v0.3.2 folder and emergency recovery scripts available.
2. Extract THIS entire ZIP into a NEW, PERMANENT folder. Do not run from inside a ZIP or temporary archive preview.
3. Double-click Launch-RKA.cmd (it invokes the borderless WPF launch via administrator UAC).
   Alternate: double-click Launch-RKA-WPF.vbs.
4. If nothing appears or a startup error is shown, run Launch-RKA-WPF-Debug.cmd from an elevated Windows command prompt. Share the error (never tokens).
5. UI log: %LOCALAPPDATA%\RKA-Lockdown-Agent\wpf-ui.log
6. You may launch the earlier WinForms interface using Launch-RKA-Legacy.cmd; do NOT run both while changing policies.

IMPORTANT CHANGES
- Policies tab shows actual selected guest's Windows registry values (when readable) with green Applied, red Not applied, amber Unable to verify, or gray Disabled.
- Checking a box changes ONLY the desired profile. Save Profile Only never changes Windows.
- Apply Restrictions uses an explicit persistent policy snapshot and independent administrator recovery confirmation; NO 5-minute automatic timer.
- Restore Previous Settings will attempt to restore original guest registry values from a protected snapshot; Emergency-Restore.cmd remains available independently.
- The WPF UI does not apply restrictions to administrators or unknown accounts. The guest must be verified as a local standard user.
- Chrome guest login startup task bug corrected (PowerShell -Action argument reused as variable in v0.3.2).
- Desktop shortcut bug corrected (script assigned read-only $HOME).
- Restore snapshot bug corrected (missing restoredAt property on JSON PSCustomObject).
- Lovable check is local task/log status; only server dashboard establishes Online.
- Chrome, Console/Registry/Settings restrictions do NOT stop all portable apps, installers, USB execution or unapproved browsers.
- Chrome startup and heartbeat tasks run separately from the tray app.

NO SECRET MIGRATION REQUIRED
Existing local profile data remains in %LOCALAPPDATA%\RKA-Lockdown-Agent; existing encrypted Lovable enrollment remains under C:\ProgramData\RKA-Lockdown-Agent\Heartbeat. Do NOT re-enroll unless necessary.

RECOVERY
Do not test policy Apply until you have a working separate Windows administrator account and Emergency-Restore.cmd available. Existing recovery snapshots must be restored before applying any new one. Never delete snapshot pointer/recovery files just to silence an error.

STATUS
Linux-side validation: WPF XAML is well-formed XML, named controls consistent, ZIP CRC integrity checked. There is NO Windows WPF runtime in this environment, so all actual UI rendering, scheduled task operations, guest hive checks and policy recovery still require your laptop test. This is a TEST/PREVIEW, not production ready.

v0.4.1 WPF BETA NOTES
- Modern WPF navigation/window buttons now use safe ASCII labels and vector icon shapes to avoid the missing-glyph rectangles. The program source is UTF-8 with BOM for Windows PowerShell 5.1.
- Chrome Guest Startup App Mode requests a maximized window. This is normal, windowed app mode (not kiosk or exclusive fullscreen); Chrome may require first-run initialization.
- Diagnostics > Deploy Intranet Shortcut: selects ONE verified standard guest, deploys an RKA-branded "Retro Knights LAN Portal" shortcut on that guest's desktop using a protected ProgramData launcher. The guest shortcut opens the configured intranet in maximized Chrome App Mode and never opens admin controls. It operates separately from guest Chrome automatic startup. A missing guest Desktop (e.g. redirected to OneDrive) is reported rather than guessed.
- Policies > Edit Edge approved websites: edit the Edge-only URL list, save it to the app profile, then restore/apply a new policy snapshot to make changes on Windows. Approved sites may need browser policy refresh. Chrome is not constrained by Edge-only rules.
- Policies > Save Shortcuts and Restore Shortcuts: backs up .lnk and .url files for the selected guest AND public desktop. This does not lock icons, capture XY icon positions, restrict USB, or remove newly created files on restore.
- Removed redundant in-app legacy launcher that failed due to app single-instance protection. Launch-RKA-Legacy.cmd is retained as a recovery fallback AFTER closing the WPF process.
- Never use guest Windows login for admin Control Center; keep an independent administrator and Emergency-Restore.cmd. Remote commands remain disabled.

V0.4.3 WPF REMOTE TEST — See TEST-v0.4.3-WPF.txt before testing. USB storage rule is device-wide. Remote management diagnostics require explicit administrator setup; restart/apply/restore require separate local opt-in. Retains existing heartbeat enrollment. Do NOT roll out fleet-wide before laptop verification.


v0.4.4: Settings tab restored with Microsoft-signed Sysinternals Autologon launcher, status and Disable utility, plus approved websites editor. Browser policies now use Chromium host patterns and always include configured intranet and Discord domains. Title-bar padding adjusted. See TEST-v0.4.4-WPF.txt.
