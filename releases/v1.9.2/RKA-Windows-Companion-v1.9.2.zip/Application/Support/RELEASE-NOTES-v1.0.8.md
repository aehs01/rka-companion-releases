# RKA Windows Companion v1.0.8 — fleet setup & policy interoperability

- **Five deployed PCs, eight planned:** Administrator-approved local/LAN release ZIP install now backs up program files and updates both background tasks on already-enrolled devices. The remote agent reports v1.0.8 after authenticated check-in; no new remote-command protocol.
- **Recovery-safe targeted changes:** Remote `set_guest_restriction` and `set_browser_allowlist` accept an active full-policy recovery snapshot belonging to the same guest, atomically recording original registry values before any modification. Local Restore recovers the original state even after remote toggles and website list changes. Other guests are denied.
- **Game shortcuts:** Copies safe .lnk/.url files from administrator desktop to selected standard guest, without overwriting files or copying programs. Skips Windows administrative tools, admin-private AppData destinations and shortcuts flagged RunAs.
- **Compatibility scan:** Read-only guest startup, shortcut flag and AppCompatLayers scan. No persistent elevation, UAC bypass or automatic admin approval.
- **Update limits:** Private GitHub has no anonymous download. Optional HTTPS metadata/download requires a separately configured release endpoint. ZIP installation is never unattended; no Authenticode signing key configured. Validate official SHA-256 independently.
- **Verification:** source structure, packaged file hashes, XAML control bindings and ZIP validated; Windows 10/11 behavior NOT tested on actual devices. Pilot one PC first, preserve v1.0.7 rollback.
