# Deploy an RKA logo shortcut to a single, verified local standard user's Desktop.
# Admin only. Shortcut launches a separate protected ProgramData worker as that guest.
#Requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$TargetSid,[Parameter(Mandatory=$true)][string]$Url)
$ErrorActionPreference='Stop'
function Assert-Admin {
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Launch from an elevated administrator account.'}
}
function Get-StandardGuest([string]$sid) {
 if($sid -notmatch '^S-1-5-21-(\d+-){3}\d+$'){throw 'Expected a local Windows user SID.'}
 $acct=Get-CimInstance Win32_UserAccount -Filter "SID='$sid' AND LocalAccount=True" -ErrorAction Stop | Select-Object -First 1
 if(-not $acct -or $acct.Disabled){throw 'Selected local guest does not exist or is disabled.'}
 $rkaGa=Join-Path $PSScriptRoot 'Guest-Accounts.ps1';if(Test-Path -LiteralPath $rkaGa){. $rkaGa}else{function Test-RkaAdminGuest{return $false};function Get-RkaAdminGuests{return @()};function Save-RkaPolicySnapshot{};function Clear-RkaPolicySnapshot{};function Repair-RkaPolicySnapshot{return 0};function Find-RkaGuestToAdopt{return $null};function Add-RkaAdminGuest{};function Test-RkaRunningAsAdminGuest{return $false}}
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
 if(@($admins | Where-Object {$_.SID -and $_.SID.Value -eq $sid}).Count -gt 0 -and -not (Test-RkaAdminGuest $sid)){throw 'An administrator account that is not the admin guest cannot receive the guest launcher.'}
 if($sid -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Refusing to target the current administrator account.'}
 $userProfile=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop | Select-Object -First 1
 if(-not $userProfile -or -not $userProfile.LocalPath){throw 'The guest must sign into Windows once before deploying the shortcut.'}
 $desktop=Join-Path $userProfile.LocalPath 'Desktop'
 if(-not(Test-Path -LiteralPath $desktop -PathType Container)){throw "Guest Desktop folder was not found at $desktop. Verify Desktop is not redirected to OneDrive."}
 return [pscustomobject]@{Name=$acct.Name;Sid=$sid;Desktop=$desktop}
}
try{
 Assert-Admin
 $uri=$null
 if(-not [Uri]::TryCreate($Url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.UserInfo -or $Url -match '[*\s#"<>]'){throw 'Enter one exact http(s) URL with no credentials, wildcards, spaces or fragments.'}
 $g=Get-StandardGuest $TargetSid
 $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\IntranetShortcut'
 if(-not(Test-Path -LiteralPath $root)){New-Item -Path $root -ItemType Directory -Force|Out-Null}
 & icacls.exe $root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Unable to secure intranet shortcut worker folder.'}
 $worker=Join-Path $root 'Guest-Intranet-Launch.ps1'
 $source=Join-Path $PSScriptRoot 'Guest-Intranet-Launch.ps1'
 $sourceIcon=Join-Path $PSScriptRoot 'assets\rka.ico'
 if(-not(Test-Path -LiteralPath $source) -or -not(Test-Path -LiteralPath $sourceIcon)){throw 'Launcher or RKA icon is missing from extracted package.'}
 Copy-Item -LiteralPath $source -Destination $worker -Force -ErrorAction Stop
 $icon=Join-Path $root 'rka.ico'
 Copy-Item -LiteralPath $sourceIcon -Destination $icon -Force -ErrorAction Stop
 $config=Join-Path $root 'config.json'
 [ordered]@{version=1;sid=$g.Sid;url=$uri.AbsoluteUri;mode='App';window='Maximized'} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $config -Encoding UTF8
 $target=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $link=Join-Path $g.Desktop 'Retro Knights LAN Portal.lnk'
 $shell=New-Object -ComObject WScript.Shell
 $shortcut=$shell.CreateShortcut($link)
 $shortcut.TargetPath=$target
 $shortcut.Arguments='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$worker+'" -ConfigPath "'+$config+'"'
 $shortcut.WorkingDirectory=$root
 $shortcut.IconLocation=$icon+',0'
 $shortcut.Description='Retro Knights Arcade - LAN intranet (Chrome App Mode)'
 $shortcut.Save()
 if(-not(Test-Path -LiteralPath $link -PathType Leaf)){throw 'Shortcut creation did not produce a .lnk file.'}
 Write-Host "SUCCESS: Guest $($g.Name) desktop shortcut deployed: $link" -ForegroundColor Green
 Write-Host "It opens $($uri.AbsoluteUri) in Chrome App Mode, maximized (taskbar remains available)." -ForegroundColor Cyan
 exit 0
}catch{
 try{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Deploy Intranet Shortcut','OK','Error')|Out-Null}catch{Write-Host $_.Exception.Message -ForegroundColor Red}
 exit 1
}
