#Requires -Version 5.1
$admin=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if(-not $admin.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
 $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $p=Start-Process $exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"') -Verb RunAs -Wait -PassThru
 exit $p.ExitCode
}
try{
 & (Join-Path $PSScriptRoot 'Application\Remote-Recovery.ps1') -Action RestoreGuestItems
 if($LASTEXITCODE -ne 0){throw 'Restore reported an error'}
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;Read-Host 'Press Enter';exit 1}
Read-Host 'Please verify settings in the guest account. Press Enter to close'
