# Requires Windows Administrator. Stop the SYSTEM heartbeat task and erase local token.
# Does not affect Windows lockdown settings.
#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run the remove launcher as administrator.' }
$task='RKA-Lockdown-ReadOnlyHeartbeat'
$found=Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
if($null -ne $found) { Unregister-ScheduledTask -TaskName $task -Confirm:$false }
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'
if(Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force }
Write-Host 'Local heartbeat task and protected token removed.' -ForegroundColor Green
Write-Host 'Also revoke this device token in Lovable PC Management to prevent further use.'
