@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Chrome-Portal-Setup.ps1" -Action Status
pause
