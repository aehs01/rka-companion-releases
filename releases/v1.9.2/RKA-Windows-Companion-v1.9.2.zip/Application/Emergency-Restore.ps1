# Emergency restore (Companion 1.2): Unlock everything, for when the Companion
# window won't open. Asks Windows for administrator approval once, then removes
# every guest lockdown the Companion manages from every standard account and
# allows USB storage again for the whole PC. LAN play and the after-hours
# Windows Update setting aren't lockouts, so they stay as they are.
$ErrorActionPreference='Stop'
$exe="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
 $proc=Start-Process -FilePath $exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"') -Verb RunAs -Wait -PassThru
 exit $proc.ExitCode
}
$worker=Join-Path $PSScriptRoot 'PolicyWorker.ps1'
$usb=Join-Path $PSScriptRoot 'USB-Storage.ps1'
if(-not(Test-Path -LiteralPath $worker)){throw 'PolicyWorker.ps1 is missing.'}
& $exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $worker -Operation UnlockAll
$code=$LASTEXITCODE
if(Test-Path -LiteralPath $usb){& $exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $usb -Action Restore|Out-Null}
if($code -eq 0){Write-Host 'Unlocked everything: the guest accounts are back to Windows defaults and USB storage is allowed. Sign in to the guest to check.' -ForegroundColor Green}
else{Write-Warning ('Unlock everything had a problem (exit '+$code+'). See C:\ProgramData\RKA-Lockdown-Agent\Recovery\worker.log')}
exit $code
