# Retro Knights Arcade - one-time, outbound-only Lovable heartbeat enrollment.
# Windows PowerShell 5.1; Windows 10/11 Home. No remote commands or lockdown changes.
#Requires -Version 5.1
# 1.9: the Companion window's "Connect this PC to Lovable" runs this without
# prompts: -DeviceName, and the token in the RKA_ENROLL_TOKEN environment
# variable of this process only (never on the command line or on disk).
# Failures then print "ERROR: <reason>" so the window can show it.
param([string]$DeviceName = '', [switch]$TokenFromEnvironment)
$ErrorActionPreference = 'Stop'
$quiet = $TokenFromEnvironment.IsPresent
trap {
    $why = $_.Exception.Message
    if ($quiet) { Write-Output ('ERROR: ' + $why); exit 1 }
    # Run by hand: keep the window open so the reason can be read.
    Write-Host ''
    Write-Host ('SETUP STOPPED: ' + $why) -ForegroundColor Red
    Write-Host ''
    try { [void](Read-Host 'Press Enter to close this window') } catch {}
    exit 1
}
# Windows PowerShell 5.1 does not automatically load System.Security from the GAC.
# The DPAPI ProtectedData class lives in that assembly on Windows 10/11.
try {
    Add-Type -AssemblyName System.Security -ErrorAction Stop
    if ($null -eq ('System.Security.Cryptography.ProtectedData' -as [type])) {
        throw 'ProtectedData type is unavailable after System.Security was loaded.'
    }
} catch {
    throw 'Cannot initialize Windows DPAPI encryption. Use Windows PowerShell 5.1 (powershell.exe) on Windows 10/11; setup cannot safely proceed.'
}

$endpoint = 'https://zallpwnkizoxxxkufbfq.supabase.co/functions/v1/rka-pc-heartbeat'
$taskName = 'RKA-Lockdown-ReadOnlyHeartbeat'
$root = Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Protect-Folder([string]$path) {
    & "$env:SystemRoot\System32\icacls.exe" $path '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not restrict folder access to SYSTEM and Administrators.' }
}
if (-not (Test-IsAdmin)) { throw 'Please run RUN-LOVABLE-SETUP.cmd and approve the administrator prompt.' }
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Heartbeat-Client.ps1'))) {
    throw 'Missing Heartbeat-Client.ps1. Extract the entire ZIP first.'
}

if (-not $quiet) {
    Write-Host ''
    Write-Host 'RETRO KNIGHTS ARCADE - LOVABLE PC CONNECTION' -ForegroundColor Cyan
    Write-Host '1) In Lovable PC Management, first issue a one-time heartbeat token.'
    Write-Host '2) Enter the same device name that you enrolled (RKA1 / RKA2 / etc.).'
    Write-Host '3) Paste the token when prompted. It is hidden and is NOT sent to ChatGPT.'
    Write-Host ''
}
$detected = $env:COMPUTERNAME.ToUpperInvariant()
if ($detected -notmatch '^[A-Z0-9-]{3,40}$') { $detected = 'RKA1' }
$deviceName = if ($quiet) { $DeviceName } else { Read-Host "Enrolled device NAME in Lovable [suggestion: $detected]" }
if ([string]::IsNullOrWhiteSpace($deviceName)) { $deviceName = $detected }
# 1.9: "rka 6" and "RKA-6 " are what people type; Lovable's names are upper case without spaces.
$deviceName = ($deviceName.Trim().ToUpperInvariant() -replace '\s+', '')
if ($deviceName -cnotmatch '^[A-Z0-9-]{3,40}$') { throw "That PC name ($deviceName) can't be used. Use the name exactly as Lovable shows it: letters, numbers and hyphens, 3 to 40 characters (like RKA6)." }
if (-not $quiet) { Write-Host "Device: $deviceName" -ForegroundColor Cyan; Write-Host 'Token entry will be hidden. Paste your ONE-TIME token then press Enter.' }
$secret = $null
if ($quiet) {
    $fromEnv = [Environment]::GetEnvironmentVariable('RKA_ENROLL_TOKEN', 'Process')
    [Environment]::SetEnvironmentVariable('RKA_ENROLL_TOKEN', $null, 'Process')
    if ([string]::IsNullOrEmpty($fromEnv)) { throw 'No token was given.' }
    $secret = New-Object System.Security.SecureString
    foreach ($ch in $fromEnv.Trim().ToCharArray()) { $secret.AppendChar($ch) }
    $fromEnv = $null
} else {
    $secret = Read-Host 'Lovable heartbeat token' -AsSecureString
}
$bstr = [IntPtr]::Zero
$plain = $null
$bytes = $null
try {
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
    # 1.9: a pasted token often brings a space or line break along.
    $plain = ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)).Trim()
    if ($plain -cnotmatch '^rka_pc_[A-Za-z0-9_-]{43}$') { throw "That doesn't look like a whole PC token. In Control Room, copy the full token (it starts with rka_pc_ and is 50 characters long) and paste it again." }
    $bytes = [Text.Encoding]::UTF8.GetBytes($plain)
    $blob = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
} finally {
    if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    $plain = $null
    if ($null -ne $bytes) { [Array]::Clear($bytes,0,$bytes.Length) }
    $secret.Dispose()
}

# Create machine-scoped, restricted configuration and script for the SYSTEM task.
New-Item -ItemType Directory -Path $root -Force | Out-Null
Protect-Folder $root
$target = Join-Path $root 'Heartbeat-Client.ps1'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Heartbeat-Client.ps1') -Destination $target -Force
$config = @{ endpoint=$endpoint; deviceName=$deviceName; tokenEncrypted=[Convert]::ToBase64String($blob) }
$config | ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $root 'configuration.json') -Encoding UTF8 -Force
Protect-Folder $root

# Create the recurring task under SYSTEM; no guest login or tray application required.
$exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$action = New-ScheduledTaskAction -Execute $exe -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $target + '"')
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650)
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'RKA read-only Lovable online/offline heartbeat; cannot receive commands' -Force | Out-Null

# Trigger a first heartbeat now without waiting for the next minute.
Start-ScheduledTask -TaskName $taskName
Write-Host ''
Write-Host 'Heartbeat task installed. Trying one check-in now...' -ForegroundColor Cyan
$statusPath = Join-Path $root 'status.log'
$after = Get-Date
$latest = $null
for ($i=0; $i -lt 12; $i++) {
    Start-Sleep -Seconds 2
    if (Test-Path -LiteralPath $statusPath) {
        $last = Get-Content -LiteralPath $statusPath -Tail 1 -ErrorAction SilentlyContinue
        if ($last) {
            $parsedTime = [datetime]::MinValue
            $firstPart = ([string]$last -split ' ',2)[0]
            if ([datetime]::TryParse($firstPart,[ref]$parsedTime) -and $parsedTime -ge $after.AddSeconds(-3)) { $latest = [string]$last; break }
        }
    }
}
if ($latest -and $latest -match 'Heartbeat accepted') {
    if ($quiet) { Write-Output 'HEARTBEAT: accepted' } else { Write-Host 'SUCCESS: Lovable accepted the first heartbeat.' -ForegroundColor Green }
} elseif ($latest) {
    # 1.9: say why, from the heartbeat's own last line (it never holds the token).
    $reason = ([string]$latest -split ' ', 2)[1]
    if ($quiet) { Write-Output ('HEARTBEAT: refused ' + $reason) } else { Write-Warning ('A heartbeat ran, but Lovable did not accept it: ' + $reason) }
} else {
    if ($quiet) { Write-Output 'HEARTBEAT: none yet' } else { Write-Warning 'Task is installed but no new result appeared within 24 seconds. Check after a minute.' }
}
Write-Host 'Now open Lovable > Employee Resources > PC Management > PCs.'
Write-Host 'Online means a heartbeat arrived within 3 minutes; Protection must remain Unverified.'
Write-Host 'To stop, run RUN-REMOVE-HEARTBEAT.cmd and revoke the device token in Lovable.'
Write-Host ''
