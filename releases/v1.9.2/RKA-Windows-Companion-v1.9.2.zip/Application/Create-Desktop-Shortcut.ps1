# Puts an "RKA Companion" shortcut on the current administrator's desktop and
# removes the old "Retro Knights PC Control Center" one.
$ErrorActionPreference='Stop'
$appRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$target=Join-Path $env:SystemRoot 'System32\wscript.exe'
$scriptPath=Join-Path $appRoot 'Launch-RKA-WPF.vbs'
$icon=Join-Path $appRoot 'assets\rka.ico'
$desktop=[Environment]::GetFolderPath('Desktop')
$shell=New-Object -ComObject WScript.Shell
$old=Join-Path $desktop 'Retro Knights PC Control Center.lnk'
if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old -Force}
$lnk=$shell.CreateShortcut((Join-Path $desktop 'RKA Companion.lnk'))
$lnk.TargetPath=$target
$lnk.Arguments='"'+$scriptPath+'"'
$lnk.WorkingDirectory=$appRoot
$lnk.IconLocation=$icon+',0'
$lnk.Description='RKA Companion: guest lockdown, Lovable and updates (administrators only)'
$lnk.Save()
Write-Host "Desktop shortcut created: $desktop" -ForegroundColor Cyan
