# RKA optional PUBLIC desktop shortcut restoration — administrative operation.
# Does not delete existing files or restore icon pixel coordinates.
#Requires -Version 5.1
$ErrorActionPreference='Stop'
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if(-not $admin){throw 'Please Run as administrator.'}
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\DesktopBackup'
$latest=Get-ChildItem -LiteralPath $root -Directory -ErrorAction Stop|Sort-Object Name -Descending|Select-Object -First 1
if(-not $latest){throw 'No public desktop shortcut backups found. Use Save Desktop first.'}
$public=[Environment]::GetFolderPath('CommonDesktopDirectory')
$files=@(Get-ChildItem -LiteralPath $latest.FullName -File|Where-Object {$_.Extension -in '.lnk','.url'})
foreach($f in $files){Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $public $f.Name) -Force}
Write-Host "Restored $($files.Count) missing/modified public desktop shortcuts from $($latest.Name). This does NOT restore on-screen icon positions." -ForegroundColor Cyan
