# Interactive guest-only LAN intranet launch. Admin-owned ProgramData config, user-level browser.
#Requires -Version 5.1
param([string]$ConfigPath="$env:ProgramData\RKA-Lockdown-Agent\IntranetShortcut\config.json")
$ErrorActionPreference='Stop'
function Trace([string]$message){
 try{
  $logDir=Join-Path $env:LOCALAPPDATA 'RKA-LAN-Portal'
  if(-not(Test-Path -LiteralPath $logDir)){New-Item -Path $logDir -ItemType Directory -Force|Out-Null}
  Add-Content -LiteralPath (Join-Path $logDir 'launch.log') -Value ('{0:o} {1}' -f (Get-Date),$message) -Encoding UTF8
 }catch{}
}
try{
 if(-not(Test-Path -LiteralPath $ConfigPath)){throw 'Intranet launcher is not configured.'}
 $c=Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
 $me=[Security.Principal.WindowsIdentity]::GetCurrent()
 if($me.User.Value -ne [string]$c.sid){throw 'Shortcut was launched from a different Windows account.'}
 if(([Security.Principal.WindowsPrincipal]$me).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Intranet guest shortcut cannot run as an administrator.'}
 $uri=$null
 if(-not [Uri]::TryCreate([string]$c.url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.UserInfo){throw 'Invalid LAN portal URL in protected configuration.'}
 $candidates=@("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
 $chrome=$candidates | Where-Object {$_ -and (Test-Path -LiteralPath $_ -PathType Leaf)} | Select-Object -First 1
 if(-not $chrome){throw 'Chrome is not installed for this guest account.'}
 # Chrome App Mode is windowed, maximized on the available display (taskbar remains visible).
 $proc=Start-Process -FilePath $chrome -ArgumentList @('--app='+$uri.AbsoluteUri,'--start-maximized') -PassThru -ErrorAction Stop
 try{
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class RkaGuestPortalWindow {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd, int nCmdShow);
}
'@ -ErrorAction Stop
  for($i=0;$i -lt 20;$i++){
   Start-Sleep -Milliseconds 250
   $proc.Refresh()
   if($proc.MainWindowHandle -ne [IntPtr]::Zero){
    [void][RkaGuestPortalWindow]::ShowWindow($proc.MainWindowHandle,3)
    break
   }
  }
 }catch{Trace ('Maximize requested; direct window handle unavailable: '+$_.Exception.Message)}
 Trace ('Launched '+$uri.AbsoluteUri+' as guest '+$me.Name)
 exit 0
}catch{
 Trace ('ERROR '+$_.Exception.Message)
 # Do not show an elevated console. User can provide LOCALAPPDATA\RKA-LAN-Portal\launch.log to admins.
 exit 1
}
