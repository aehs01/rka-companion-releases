// RKA Windows Companion v1.0.6 - Windows notification source identity helper.
// Compiled locally by an elevated administrator using the Windows .NET Framework C# compiler.
// No network requests, command execution, configuration writes, or arbitrary file arguments.
using System;
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
[assembly: AssemblyTitle("Retro Knights Arcade LAN")]
[assembly: AssemblyProduct("Retro Knights Arcade LAN")]
[assembly: AssemblyCompany("Retro Knights Arcade")]
[assembly: AssemblyDescription("Guest tournament and arcade notifications")]
[assembly: AssemblyVersion("1.0.6.0")]
[assembly: AssemblyFileVersion("1.0.6.0")]

internal static class RkaLanNotice {
    [DllImport("shell32.dll", CharSet=CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appID);

    [STAThread]
    private static int Main(string[] args) {
        // Only an encoded, already-validated plain-text message is accepted.
        // Do not accept caller-chosen executable paths or remote command data.
        if (args.Length != 1 || args[0].Length < 4 || args[0].Length > 2000) return 2;
        string message;
        try {
            byte[] bytes = Convert.FromBase64String(args[0]);
            message = new UTF8Encoding(false, true).GetString(bytes);
            if (message.Length == 0 || message.Length > 240 || message.Contains("<") || message.Contains(">")) return 3;
            foreach (char c in message) if (char.IsControl(c)) return 3;
            if (message.IndexOf("http://", StringComparison.OrdinalIgnoreCase) >= 0 ||
                message.IndexOf("https://", StringComparison.OrdinalIgnoreCase) >= 0) return 3;
        } catch { return 2; }
        try {
            SetCurrentProcessExplicitAppUserModelID("RetroKnightsArcade.LAN");
            Application.EnableVisualStyles();
            using (var notify = new NotifyIcon()) {
                Icon icon = null;
                try { icon = new Icon(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rka.ico")); }
                catch { icon = (Icon)SystemIcons.Information.Clone(); }
                try {
                    notify.Icon = icon;
                    notify.Text = "Retro Knights Arcade LAN";
                    notify.BalloonTipTitle = "Retro Knights Arcade LAN";
                    notify.BalloonTipText = message;
                    notify.BalloonTipIcon = ToolTipIcon.None;
                    notify.Visible = true;
                    // Requested banner duration. On Windows 10/11, the OS can override this
                    // with Settings > Accessibility > Visual effects notification duration.
                    notify.ShowBalloonTip(30000);
                    // Keep the tray icon alive beyond the requested balloon lifetime.
                    Thread.Sleep(32000);
                } finally {
                    notify.Visible = false;
                    if (icon != null) icon.Dispose();
                }
            }
            return 0;
        } catch { return 1; }
    }
}
