@echo off
setlocal
cd /d "%~dp0"
set "REPORT=%TEMP%\RKA-Preflight-Latest.log"
echo Running read-only RKA system preflight...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Preflight.ps1" > "%REPORT%" 2>&1
set "RESULT=%ERRORLEVEL%"
echo.
type "%REPORT%"
echo.
echo Report: %REPORT%
if not "%RESULT%"=="0" echo ERROR: Preflight exited with code %RESULT%. Please send the report text or a photo.
pause
exit /b %RESULT%
