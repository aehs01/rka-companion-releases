# RKA optional PUBLIC desktop backup (shortcuts, not icon coordinates). Admin only.
# Windows PowerShell 5.1 — no changes to shortcut ACLs or location.
#Requires -Version 5.1
$ErrorActionPreference='Stop'
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if(-not $admin){throw 'Please Run as administrator.'}
$public=[Environment]::GetFolderPath('CommonDesktopDirectory')
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\DesktopBackup'
if(-not(Test-Path $root)){New-Item -ItemType Directory -Path $root -Force|Out-Null}
& icacls.exe $root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' |Out-Null
if($LASTEXITCODE -ne 0){throw 'Unable to secure backup directory.'}
$files=@(Get-ChildItem -LiteralPath $public -File | Where-Object {$_.Extension -in '.lnk','.url'})
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss';$dest=Join-Path $root $stamp
New-Item -Path $dest -ItemType Directory |Out-Null
foreach($f in $files){Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $dest $f.Name) -ErrorAction Stop}
Write-Host "Saved $($files.Count) public desktop shortcuts to $dest. This backs up SHORTCUT FILES, not their on-screen positions." -ForegroundColor Cyan
