' Starts the modern WPF UI without leaving a visible console; administrator approval required.
Option Explicit
Dim fs, shell, folder, script, args
Set fs = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("Shell.Application")
folder = fs.GetParentFolderName(WScript.ScriptFullName)
script = folder & "\RKA-WPF.ps1"
args = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ & script & """"
shell.ShellExecute "powershell.exe", args, folder, "runas", 0
