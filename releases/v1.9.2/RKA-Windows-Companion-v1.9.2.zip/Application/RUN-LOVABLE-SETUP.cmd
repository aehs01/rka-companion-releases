@echo off
setlocal
cd /d "%~dp0"
fltmc >nul 2>&1
if errorlevel 1 (
  echo Requesting administrator approval...
  set "RKA_LAUNCHER=%~f0"
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList ('/c ' + [char]34 + $env:RKA_LAUNCHER + [char]34) -Verb RunAs"
  exit /b
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Heartbeat-Setup.ps1"
echo.
echo Press any key to close this window.
pause >nul
