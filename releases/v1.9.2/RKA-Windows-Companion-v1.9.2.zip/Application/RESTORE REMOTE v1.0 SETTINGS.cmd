@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RESTORE REMOTE v1.0 SETTINGS.ps1"
