@echo off
cd /d "%~dp0"
echo Retro Knights Arcade - emergency policy restore (administrator approval required)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Emergency-Restore.ps1"
pause
