# Retro Knights Arcade Windows Companion v0.3.2 BETA: offline tester feedback fixes
# PowerShell 5.1, Windows Forms, Windows 11 Pro/Home
#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
try {
 Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic
 Add-Type -AssemblyName System.Drawing
 [System.Windows.Forms.Application]::EnableVisualStyles()
 # Avoid duplicate tray instances when the launcher is clicked multiple times.
 $script:InstanceMutex=$null
 $script:OwnsInstanceMutex=$false
 $mutexCreated=$false
 $script:InstanceMutex=[System.Threading.Mutex]::new($true,'Local\RetroKnightsArcade.LockdownAgent.Interface',[ref]$mutexCreated)
 $script:OwnsInstanceMutex=$mutexCreated
 if(-not $mutexCreated){
  [System.Windows.Forms.MessageBox]::Show('RKA Lockdown Agent is already running. Look for the RKA icon in the system tray near the clock.','Already running','OK','Information') | Out-Null
  return
 }
 $script:Version = '0.3.2'
 # Detect local Administrators group membership even when UAC runs the admin account unelevated.
 $script:AdminContext=$false
 try {
  $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  $members=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
  foreach($member in $members){if($member.SID -and $member.SID.Value -eq $sid){$script:AdminContext=$true;break}}
 } catch {$script:AdminContext=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
 if(-not $script:AdminContext){
  [System.Windows.Forms.MessageBox]::Show('RKA management is for local administrators only. Sign into the separate admin account to configure settings. The public guest account does not need this interface.','Administrator account required','OK','Warning')|Out-Null
  exit 2
 }
 $rkaGa=Join-Path $PSScriptRoot 'Guest-Accounts.ps1';if(Test-Path -LiteralPath $rkaGa){. $rkaGa}else{function Test-RkaAdminGuest{return $false};function Get-RkaAdminGuests{return @()};function Save-RkaPolicySnapshot{};function Clear-RkaPolicySnapshot{};function Repair-RkaPolicySnapshot{return 0};function Find-RkaGuestToAdopt{return $null};function Add-RkaAdminGuest{};function Test-RkaRunningAsAdminGuest{return $false}}
 if(Test-RkaRunningAsAdminGuest){[System.Windows.Forms.MessageBox]::Show('This is the guest account customers use. Sign into the staff administrator account to change settings.','RKA Companion','OK','Warning')|Out-Null;exit 2}
 $script:Root = Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent'
 $script:ProfileFile = Join-Path $script:Root 'profile.json'
 $script:LogFile = Join-Path $script:Root 'ui.log'
 New-Item -Path $script:Root -ItemType Directory -Force | Out-Null
 function Log([string]$message) { Add-Content -LiteralPath $script:LogFile -Value "$(Get-Date -Format o) $message" -Encoding UTF8 }
 function DefaultProfile { return [pscustomobject]@{ account=''; urls=@('http://rkaserver/','https://discord.com/','https://discord.gg/','https://cdn.discordapp.com/','https://media.discordapp.net/'); intranet='http://rkaserver/'; blockSettings=$true; blockCmd=$true; blockRegistry=$true; restrictEdge=$false; networkBrowse=$false; hideThisPc=$false } }
 function LoadProfile {
  if (Test-Path -LiteralPath $script:ProfileFile) {
   try {
    $old=(Get-Content -LiteralPath $script:ProfileFile -Raw -Encoding UTF8 | ConvertFrom-Json)
    if (-not $old.PSObject.Properties['intranet']) { $old | Add-Member -NotePropertyName intranet -NotePropertyValue 'http://rkaserver/' }
    $existing=@($old.urls | Where-Object {-not [string]::IsNullOrWhiteSpace([string]$_)} | ForEach-Object {if(([string]$_) -match '^https?://tyrant/?$'){'http://rkaserver/'}else{[string]$_}} | Select-Object -Unique)
    # Repair empty legacy profiles only. Preserve a nonempty custom allowlist.
    if($existing.Count -eq 0){$existing=@((DefaultProfile).urls)}
    if(([string]$old.intranet) -match '^https?://tyrant/?$'){$old.intranet='http://rkaserver/'}
    if($existing -notcontains [string]$old.intranet){$existing=@([string]$old.intranet)+$existing}
    $old.urls=@($existing | Select-Object -Unique)
    return $old
   } catch { Log "Profile read error: $($_.Exception.Message)" }
  }
  return DefaultProfile
 }
 function New-Label($text,$x,$y,$w=410,$h=22,$parent=$null) {
  $c=New-Object System.Windows.Forms.Label; $c.Text=$text; $c.SetBounds($x,$y,$w,$h)
  if ($null -ne $parent) { [void]$parent.Controls.Add($c) }; return $c
 }
 function New-Button($text,$x,$y,$w=115,$h=32,$parent=$null) {
  $c=New-Object System.Windows.Forms.Button; $c.Text=$text; $c.SetBounds($x,$y,$w,$h)
  if ($null -ne $parent) { [void]$parent.Controls.Add($c) }; return $c
 }
 function New-Check($parent,$name,$x,$y,$width=560) { $c=New-Object System.Windows.Forms.CheckBox; $c.Text=$name; $c.SetBounds($x,$y,$width,27); [void]$parent.Controls.Add($c); return $c }
 function Check-Url([string]$value) {
  if ($value.Length -gt 500 -or $value -match '[*\s#]') { return $false }
  $uri=$null
  return ([uri]::TryCreate($value,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -in @('http','https') -and [string]::IsNullOrEmpty($uri.UserInfo))
 }
 function Get-LocalAccounts {
  $result=@()
  try {
   $all=@(Get-CimInstance -ClassName Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop | Where-Object { -not $_.Disabled -and -not $_.Lockout -and $_.SID -notmatch '-(500|501|503|504)$' })
   foreach($account in $all) {
    $isAdmin=$false
    try {
     $members=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop)
     $isAdmin=[bool](@($members | Where-Object { $_.SID -and $_.SID.Value -eq $account.SID }).Count)
    } catch {
     # Fail safe: do not infer standard-user status if admin lookup is unavailable.
     $isAdmin=$null
    }
    $label=if($null -eq $isAdmin){'Role unverified'} elseif($isAdmin){'Administrator - ineligible'} else {'Standard User'}
    $result += [pscustomobject]@{ Name=$account.Name; SID=$account.SID; Admin=$isAdmin; Label="$($account.Name)  ($label)" }
   }
  } catch { Log "Account discovery error: $($_.Exception.Message)" }
  return $result
 }
 $form=New-Object System.Windows.Forms.Form
 $form.Text='Retro Knights Arcade Lockdown Agent'
 $form.StartPosition='CenterScreen'; $form.Size=New-Object System.Drawing.Size(835,735)
 $form.MinimumSize=New-Object System.Drawing.Size(835,735)
 $form.Font=New-Object System.Drawing.Font('Segoe UI',9)
 $form.BackColor=[System.Drawing.Color]::FromArgb(10,17,23)
 $script:IconPath = Join-Path $PSScriptRoot 'assets\rka.ico'
 $script:BrandIcon = $null
 if(Test-Path -LiteralPath $script:IconPath){try{$script:BrandIcon=[System.Drawing.Icon]::new($script:IconPath)}catch{Log "Icon load failed: $($_.Exception.Message)"}}
 $form.Icon=if($script:BrandIcon){$script:BrandIcon}else{[System.Drawing.SystemIcons]::Shield}
 $title=New-Label 'RETRO KNIGHTS  |  PC CONTROL CENTER' 22 15 730 36 $form
 $title.Font=New-Object System.Drawing.Font('Segoe UI',17,[System.Drawing.FontStyle]::Bold)
 $subtitle=New-Label 'Guest protection, local diagnostics and Lovable connection  •  TEST BUILD' 24 52 620 22 $form
 $subtitle.ForeColor=[System.Drawing.Color]::FromArgb(152,181,194)
 $tabs=New-Object System.Windows.Forms.TabControl; $tabs.SetBounds(18,84,781,545); [void]$form.Controls.Add($tabs)
 foreach($tabName in @('Protection','Processes','Settings','Game Installers','Lovable Connection','Chrome Startup','Diagnostics & Backup')) { $p=New-Object System.Windows.Forms.TabPage; $p.Text=$tabName; $p.AutoScroll=$true; [void]$tabs.TabPages.Add($p) }
 $protect=$tabs.TabPages[0]; $processTab=$tabs.TabPages[1]; $settingsTab=$tabs.TabPages[2]; $gamesTab=$tabs.TabPages[3]
 $chromeTab=$tabs.TabPages[5]
 [void](New-Label 'CHROME / LAN PORTAL STARTUP' 18 19 700 34 $chromeTab)
 [void](New-Label 'Launch Chrome at guest Windows sign-in. The background heartbeat is separate and continues without Chrome.' 18 59 715 48 $chromeTab)
 $chromeEnabled=New-Check $chromeTab 'Automatically launch Chrome for selected standard account' 18 115
 $chromeEnabled.Checked=$true
 [void](New-Label 'Portal URL (defaults to LAN portal in Settings)' 18 158 640 24 $chromeTab)
 $chromeUrl=New-Object System.Windows.Forms.TextBox;$chromeUrl.SetBounds(18,185,682,29);[void]$chromeTab.Controls.Add($chromeUrl)
 $chromeUrl.Text='http://rkaserver/'
 [void](New-Label 'Window mode' 18 233 150 25 $chromeTab)
 $chromeMode=New-Object System.Windows.Forms.ComboBox;$chromeMode.SetBounds(18,263,210,29);$chromeMode.DropDownStyle='DropDownList';[void]$chromeMode.Items.AddRange(@('App','Normal','Fullscreen'));$chromeMode.SelectedIndex=0;[void]$chromeTab.Controls.Add($chromeMode)
 [void](New-Label 'Delay (seconds)' 258 233 160 25 $chromeTab)
 $chromeDelay=New-Object System.Windows.Forms.NumericUpDown;$chromeDelay.SetBounds(258,263,110,29);$chromeDelay.Minimum=0;$chromeDelay.Maximum=120;$chromeDelay.Value=10;[void]$chromeTab.Controls.Add($chromeDelay)
 $chromeInstall=New-Button 'Save / Enable Auto-Launch' 18 329 285 40 $chromeTab
 $chromeDisable=New-Button 'Disable Auto-Launch' 318 329 255 40 $chromeTab
 $chromeStatus=New-Label 'Startup configuration not checked yet.' 18 391 680 50 $chromeTab
 $chromeHint=New-Label 'Requires administrator elevation. Uses a limited task at sign-in for the selected standard account. Never launches for admin. Test after guest sign-in.' 18 453 690 75 $chromeTab
 $chromeInstall.Add_Click({
  try {
   if(-not $chromeEnabled.Checked){throw 'Check the auto-launch option first, or use Disable Auto-Launch.'}
   $name=Selected-Account
   $matched=@($script:accounts|Where-Object {$_.Name -eq $name -and $_.Admin -eq $false})
   if($manual.Checked -or $matched.Count -ne 1){throw 'Select a verified local standard user under Settings first.'}
   $dest=$chromeUrl.Text.Trim();if(-not(Check-Url $dest)){throw 'Enter a valid http(s) portal URL.'}
   $helper=Join-Path $PSScriptRoot 'Chrome-Portal-Setup.ps1';if(-not(Test-Path $helper)){throw 'Chrome startup setup script missing; extract the whole ZIP.'}
   $args='-NoProfile -ExecutionPolicy Bypass -File "'+$helper+'" -Action Install -UserName "'+$name+'" -Url "'+$dest+'" -Mode '+$chromeMode.SelectedItem+' -Delay '+$chromeDelay.Value
   $proc=Start-Process -FilePath 'powershell.exe' -ArgumentList $args -Verb RunAs -Wait -PassThru -ErrorAction Stop
   $logPath=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\chrome-setup-last-result.txt'
   $detail=if(Test-Path -LiteralPath $logPath){Get-Content -LiteralPath $logPath -Raw -Encoding UTF8}else{'No Chrome setup report was written.'}
   if($proc.ExitCode -ne 0){throw 'Chrome startup installation failed (exit '+$proc.ExitCode+").`r`n`r`n"+$detail}
   $chromeStatus.Text='Chrome auto-start task configured. Test at next guest sign-in.'
   [System.Windows.Forms.MessageBox]::Show($detail,'Chrome startup result','OK','Information')|Out-Null
  }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Chrome startup')|Out-Null}
 })
 $chromeDisable.Add_Click({
  try {
    $helper=Join-Path $PSScriptRoot 'Chrome-Portal-Setup.ps1'
    $proc=Start-Process -FilePath 'powershell.exe' -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$helper+'" -Action Remove') -Verb RunAs -Wait -PassThru -ErrorAction Stop
    $logPath=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\chrome-setup-last-result.txt'
    $detail=if(Test-Path -LiteralPath $logPath){Get-Content -LiteralPath $logPath -Raw -Encoding UTF8}else{'No removal report was written.'}
    if($proc.ExitCode -ne 0){throw 'Chrome startup removal failed (exit '+$proc.ExitCode+").`r`n`r`n"+$detail}
    $chromeStatus.Text='Chrome auto-start disabled.'
    [System.Windows.Forms.MessageBox]::Show($detail,'Chrome startup result','OK','Information')|Out-Null
  }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Chrome startup')|Out-Null}
 })
 $diagnosticsTab=$tabs.TabPages[6]
 [void](New-Label 'PC HEALTH, PREFLIGHT AND CONFIGURATION BACKUP' 18 18 715 36 $diagnosticsTab)
 [void](New-Label 'Read-only system checks and profile backups. Exports do not contain Lovable tokens or Windows passwords.' 18 58 710 45 $diagnosticsTab)
 $diagRun=New-Button 'Run Preflight / Health' 18 113 240 38 $diagnosticsTab
 $diagExport=New-Button 'Export Profile' 271 113 194 38 $diagnosticsTab
 $diagImport=New-Button 'Import Profile' 477 113 194 38 $diagnosticsTab
 $diagOutput=New-Object System.Windows.Forms.TextBox;$diagOutput.Multiline=$true;$diagOutput.ScrollBars='Vertical';$diagOutput.ReadOnly=$true;$diagOutput.SetBounds(18,170,685,305);[void]$diagnosticsTab.Controls.Add($diagOutput)
 $diagHint=New-Label 'Import changes saved preferences only. Review the guest account and apply restrictions locally as administrator.' 18 490 700 56 $diagnosticsTab
 $diagRun.Add_Click({
  try {
   $report=Join-Path $PSScriptRoot 'Run-Preflight.ps1'
   $json=& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $report
   $diagOutput.Text=($json -join [Environment]::NewLine)
  }catch{$diagOutput.Text='Preflight unavailable: '+$_.Exception.Message}
 })
 $diagExport.Add_Click({
  try {
   $d=New-Object System.Windows.Forms.SaveFileDialog;$d.Filter='RKA profile (*.json)|*.json';$d.FileName='RKA-Settings-Backup.json'
   if($d.ShowDialog() -eq 'OK'){
    $source=LoadProfile
    $safe=[ordered]@{format='RKA-Profile-Backup';version=1;account=[string]$source.account;intranet=[string]$source.intranet;urls=@($source.urls);blockSettings=[bool]$source.blockSettings;blockCmd=[bool]$source.blockCmd;blockRegistry=[bool]$source.blockRegistry;restrictEdge=[bool]$source.restrictEdge;networkBrowse=[bool]$source.networkBrowse;hideThisPc=[bool]$source.hideThisPc}
    $safe|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $d.FileName -Encoding UTF8
    $diagOutput.Text='Settings exported. Credentials, device tokens, and scheduled tasks are not included.'
   }
  }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Export failed')|Out-Null}
 })
 $diagImport.Add_Click({
  try {
   $d=New-Object System.Windows.Forms.OpenFileDialog;$d.Filter='RKA profile (*.json)|*.json'
   if($d.ShowDialog() -eq 'OK'){
    $obj=Get-Content -LiteralPath $d.FileName -Raw -Encoding UTF8|ConvertFrom-Json
    if($obj.format -ne 'RKA-Profile-Backup' -or $obj.version -ne 1){throw 'Not a compatible RKA settings backup.'}
    if(-not(Check-Url ([string]$obj.intranet))){throw 'Invalid intranet URL in backup.'}
    $safeUrls=@($obj.urls);if($safeUrls.Count -gt 30){throw 'Too many URLs.'}
    foreach($u in $safeUrls){if(-not(Check-Url ([string]$u))){throw 'Backup contains an invalid URL.'}}
    $target=[ordered]@{version=$script:Version;account=[string]$obj.account;intranet=[string]$obj.intranet;urls=$safeUrls;blockSettings=[bool]$obj.blockSettings;blockCmd=[bool]$obj.blockCmd;blockRegistry=[bool]$obj.blockRegistry;restrictEdge=[bool]$obj.restrictEdge;networkBrowse=[bool]$obj.networkBrowse;hideThisPc=[bool]$obj.hideThisPc}
    $target|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
    $diagOutput.Text='Profile imported. Restart Control Center to load preferences. No Windows policies were applied.'
   }
  }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Import failed')|Out-Null}
 })
 $connectionTab=$tabs.TabPages[4]
 [void](New-Label 'LOVABLE PC CONNECTION' 18 19 700 34 $connectionTab)
 [void](New-Label 'The protected Windows scheduled task keeps checking in even when this app is closed.' 18 59 715 43 $connectionTab)
 $connectionState=New-Label 'Checking connection status...' 18 111 710 55 $connectionTab
 $connectionState.ForeColor=[System.Drawing.Color]::FromArgb(52,206,234)
 $connectionHint=New-Label 'The Lovable dashboard is the source of truth for Online status. This local view reports task health.' 18 169 715 54 $connectionTab
 $connectBtn=New-Button 'Connect / Reconnect to Lovable' 18 250 335 39 $connectionTab
 $checkConnectBtn=New-Button 'Check Local Connection' 366 250 335 39 $connectionTab
 $removeConnectBtn=New-Button 'Remove Local Connection' 18 312 335 39 $connectionTab
 $connectionWarning=New-Label 'No remote commands are executed in this release. Only admins can enroll/remove a PC.' 18 390 713 64 $connectionTab
 function Refresh-LovableConnection {
  try {
   $task=Get-ScheduledTask -TaskName 'RKA-Lockdown-ReadOnlyHeartbeat' -ErrorAction SilentlyContinue
   $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'
   $cfgPath=Join-Path $root 'configuration.json'
   $device='Not enrolled'
   if(Test-Path -LiteralPath $cfgPath){$c=Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8|ConvertFrom-Json;$device=[string]$c.deviceName}
   if($null -eq $task){$connectionState.Text='Heartbeat task is not installed.';return ('Device: '+$device+"`r`nHeartbeat task: NOT INSTALLED`r`nRun Connect / Reconnect only if setup is required.")}
   $info=Get-ScheduledTaskInfo -TaskName $task.TaskName -ErrorAction SilentlyContinue
   $last=if($info){[string]$info.LastTaskResult}else{'Unknown'}
   $ran=if($info){[string]$info.LastRunTime}else{'Unknown'}
   $connectionState.Text='Device: '+$device+'  |  Task: '+$task.State+'  |  Last result: '+$last
   $lines=@('Device: '+$device,'Heartbeat task: '+[string]$task.State,'Last task result: '+$last,'Last run: '+$ran)
   $logPath=Join-Path $root 'status.log'
   if(Test-Path -LiteralPath $logPath){$tail=@(Get-Content -LiteralPath $logPath -Tail 5);$lines+=@('','Recent check-ins:')+$tail}else{$lines+=@('','No heartbeat log found yet.')}
   $lines+=@('','Local check only. To confirm Online status, open Partner Dashboard > LAN Management in Lovable.')
   return ($lines -join "`r`n")
  }catch{$connectionState.Text='Connection check failed.';return ('Connection status could not be read: '+$_.Exception.Message)}
 }
 $checkConnectBtn.Add_Click({
  try {
   $helper=Join-Path $PSScriptRoot 'Heartbeat-Ui-Status.ps1'
   if(-not(Test-Path -LiteralPath $helper)){throw 'Status helper missing. Extract the entire ZIP.'}
   $statusPath=Join-Path $script:Root 'heartbeat-ui-status.txt'
   if(Test-Path -LiteralPath $statusPath){Remove-Item -LiteralPath $statusPath -Force -ErrorAction SilentlyContinue}
   $proc=Start-Process -FilePath 'powershell.exe' -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$helper+'"') -Verb RunAs -Wait -PassThru -ErrorAction Stop
   $detail=if(Test-Path -LiteralPath $statusPath){Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8}else{'No status report produced; check Windows UAC and local administrator access.'}
   [void](Refresh-LovableConnection)
   if($proc.ExitCode -ne 0){$detail='Connection check failed (exit '+$proc.ExitCode+").`r`n"+$detail}
   [System.Windows.Forms.MessageBox]::Show($detail,'Lovable Connection Check','OK','Information')|Out-Null
  }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Connection check failed','OK','Error')|Out-Null}
 })
 $connectBtn.Add_Click({
  try {
   $file=Join-Path $PSScriptRoot 'RUN-LOVABLE-SETUP.cmd'
   if(-not(Test-Path -LiteralPath $file)){throw 'Missing connection setup helper. Extract the entire ZIP.'}
   [System.Windows.Forms.MessageBox]::Show('First create a device and one-time token under Partner Dashboard > LAN Management. Use the exact SAME device name here. Setup will ask for your token privately.','Connect to Lovable','OK','Information')|Out-Null
   Start-Process -FilePath $file -Verb RunAs -ErrorAction Stop
  }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Connection setup')|Out-Null}
 })
 $removeConnectBtn.Add_Click({
  if([System.Windows.Forms.MessageBox]::Show('This stops the local heartbeat only. First remove/revoke this PC in the Lovable admin dashboard. Continue?','Remove local connection','YesNo','Warning') -ne 'Yes'){return}
  try{Start-Process -FilePath (Join-Path $PSScriptRoot 'RUN-REMOVE-HEARTBEAT.cmd') -Verb RunAs -ErrorAction Stop}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Connection removal')|Out-Null}
 })
 [void](Refresh-LovableConnection)

 $tip=New-Object System.Windows.Forms.ToolTip; $tip.AutoPopDelay=20000; $tip.InitialDelay=350; $tip.ReshowDelay=100
 function Add-Help($parent,$control,$text,$x,$y) {
  $q=New-Button '?' $x $y 27 25 $parent; $q.FlatStyle='Flat'; $q.FlatAppearance.BorderSize=0
  $q.ForeColor=[System.Drawing.Color]::RoyalBlue
  $tip.SetToolTip($q,$text); $tip.SetToolTip($control,$text)
  $q.Add_Click({ [System.Windows.Forms.MessageBox]::Show($text,'About this setting','OK','Information') | Out-Null }.GetNewClosure())
 }
 $banner=New-Label 'Guest protection — changes are applied explicitly and remain until administrator restores them.' 16 13 727 25 $protect
 $banner.ForeColor=[System.Drawing.Color]::FromArgb(52,206,234)
 $group=New-Object System.Windows.Forms.GroupBox; $group.Text='Customer restrictions'; $group.SetBounds(14,45,732,240);[void]$protect.Controls.Add($group)
 $settings=New-Check $group 'Block Windows Settings and Control Panel' 16 27
 Add-Help $group $settings 'Prevents a selected user from opening Settings and Control Panel. A registry policy is not a complete security boundary.' 680 29
 $cmd=New-Check $group 'Block Command Prompt' 16 61
 Add-Help $group $cmd 'Restricts cmd.exe through a customer-user policy. Other shells and scripts may require separate application-control rules.' 680 63
 $registry=New-Check $group 'Block Registry Editor' 16 95
 Add-Help $group $registry 'Restricts regedit.exe for the selected user. Not a substitute for standard-user permissions or app allowlisting.' 680 97
 $edge=New-Check $group 'Edge: allow only approved intranet URLs' 16 129
 Add-Help $group $edge 'Planned URLBlocklist + URLAllowlist configuration in Edge. Other browsers and Steam embedded web views require separate controls. Do not enable before testing LAN Party Manager.' 680 131
 $network=New-Check $group 'Limit browsing nearby network computers (planned)' 16 163
 Add-Help $group $network 'Future control for network discovery and unapproved shares; hiding Network in Explorer does not prevent direct access to an IP address.' 680 165
 $thispc=New-Check $group 'Hide This PC in File Explorer (planned)' 16 197
 Add-Help $group $thispc 'Convenience restriction only; hiding This PC does not prevent file access through Open dialogs or other programs.' 680 199
 $actions=New-Object System.Windows.Forms.GroupBox; $actions.Text='Actions';$actions.SetBounds(14,296,732,105);[void]$protect.Controls.Add($actions)
 $save=New-Button 'Save Profile Only' 14 29 147 33 $actions
 $audit=New-Button 'Verify Policy' 173 29 152 33 $actions
 $lock=New-Button 'Apply Restrictions' 337 29 154 33 $actions
 $restore=New-Button 'Restore Previous Settings' 503 29 211 33 $actions
 $lock.Enabled=$true; $restore.Enabled=$true
 $tip.SetToolTip($lock,'Applies selected restrictions ONLY to a verified standard-user account. No automatic timer. Requires confirmation and a separate administrator recovery path.')
 $tip.SetToolTip($restore,'Admin elevation required. Restores the saved original registry values; guest sign-out may be required to refresh policies.')
 $status=New-Label 'Protection: Not verified. Save Profile Only does not change Windows settings.' 18 442 710 35 $protect
 $status.ForeColor=[System.Drawing.Color]::FromArgb(152,181,194)
 $desktopBackup=New-Button 'Back Up Public Shortcuts' 20 480 233 33 $protect
 $desktopRestore=New-Button 'Restore Public Shortcuts' 265 480 235 33 $protect
 $desktopHint=New-Label 'Shortcut FILE backups; icon positions are not saved in this release.' 18 519 720 20 $protect
 $desktopBackup.Add_Click({
  try { Start-Process powershell.exe -Verb RunAs -ArgumentList ('-NoProfile -NoExit -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'Save-Desktop-Shortcuts.ps1')+'"') -ErrorAction Stop }
  catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Shortcut backup')|Out-Null}
 })
 $desktopRestore.Add_Click({
  try { Start-Process powershell.exe -Verb RunAs -ArgumentList ('-NoProfile -NoExit -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'Restore-Desktop-Shortcuts.ps1')+'"') -ErrorAction Stop }
  catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Shortcut restoration')|Out-Null}
 })

 $processInfo=New-Label 'Read-only Windows processes. Select Refresh to update the list.' 12 13 720 24 $processTab
 $refresh=New-Button 'Refresh Processes' 12 43 170 34 $processTab
 $processSearch=New-Object System.Windows.Forms.TextBox;$processSearch.SetBounds(196,45,273,28);[void]$processTab.Controls.Add($processSearch)
 [void](New-Label 'Filter:' 479 49 55 23 $processTab)
 $grid=New-Object System.Windows.Forms.ListView;$grid.View='Details';$grid.FullRowSelect=$true;$grid.GridLines=$true;$grid.SetBounds(12,91,736,337)
 foreach($c in @(@('Process',270),@('PID',100),@('Memory MB',125),@('Path (when accessible)',220))) { [void]$grid.Columns.Add($c[0],[int]$c[1]) }
 [void]$processTab.Controls.Add($grid)
 $script:processData=@()
 function Refresh-Processes {
  try {
   $script:processData=@(Get-Process | Sort-Object ProcessName | ForEach-Object { [pscustomobject]@{Name=$_.ProcessName;Pid=$_.Id;Mb=[math]::Round($_.WorkingSet64/1MB,1);Path=$(try{$_.Path}catch{''})} })
   Filter-Processes
  } catch { Log "Process list error: $($_.Exception.Message)"; [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Process viewer') | Out-Null }
 }
 function Filter-Processes {
  $grid.BeginUpdate(); $grid.Items.Clear()
  $filter=$processSearch.Text.Trim()
  foreach($p in $script:processData) {
   if ($filter -and $p.Name -notlike "*$filter*" -and [string]$p.Pid -notlike "*$filter*") {continue}
   $item=New-Object System.Windows.Forms.ListViewItem([string]$p.Name)
   [void]$item.SubItems.Add([string]$p.Pid);[void]$item.SubItems.Add([string]$p.Mb);[void]$item.SubItems.Add([string]$p.Path)
   [void]$grid.Items.Add($item)
  }
  $grid.EndUpdate()
 }
 $refresh.Add_Click({ Refresh-Processes }); $processSearch.Add_TextChanged({ Filter-Processes })
 $accountBox=New-Object System.Windows.Forms.GroupBox;$accountBox.Text='Customer account';$accountBox.SetBounds(13,12,736,160);[void]$settingsTab.Controls.Add($accountBox)
 [void](New-Label 'Target Windows account' 13 29 300 22 $accountBox)
 $users=New-Object System.Windows.Forms.ComboBox;$users.DropDownStyle='DropDownList';$users.SetBounds(14,54,484,29);[void]$accountBox.Controls.Add($users)
 $scan=New-Button 'Rescan Accounts' 510 52 192 32 $accountBox
 $manual=New-Object System.Windows.Forms.CheckBox;$manual.Text='Enter username manually (advanced)';$manual.SetBounds(14,93,285,26);[void]$accountBox.Controls.Add($manual)
 $manualName=New-Object System.Windows.Forms.TextBox;$manualName.SetBounds(302,93,197,25);$manualName.Enabled=$false;[void]$accountBox.Controls.Add($manualName)
 $accountHelp=New-Label 'Only verified standard-user accounts can be selected for eventual enforcement.' 14 125 682 24 $accountBox
 $accountHelp.ForeColor=[System.Drawing.Color]::FromArgb(152,181,194)
 $urlGroup=New-Object System.Windows.Forms.GroupBox;$urlGroup.Text='Approved intranet URLs';$urlGroup.SetBounds(13,181,736,159);[void]$settingsTab.Controls.Add($urlGroup)
 $urlList=New-Object System.Windows.Forms.ListBox;$urlList.SetBounds(13,26,490,108);[void]$urlGroup.Controls.Add($urlList)
 $add=New-Button 'Add URL...' 514 25 187 31 $urlGroup
 $edit=New-Button 'Edit Selected...' 514 62 187 31 $urlGroup
 $remove=New-Button 'Remove Selected' 514 99 187 31 $urlGroup
 $intranetGroup=New-Object System.Windows.Forms.GroupBox;$intranetGroup.Text='LAN portal destination';$intranetGroup.SetBounds(13,347,736,62);[void]$settingsTab.Controls.Add($intranetGroup)
 $intranetField=New-Object System.Windows.Forms.TextBox;$intranetField.SetBounds(15,24,484,28);$intranetField.Text='http://rkaserver/';[void]$intranetGroup.Controls.Add($intranetField)
 $openIntranet=New-Button 'Open LAN Intranet' 512 23 195 31 $intranetGroup
 $autologin=New-Button 'Configure Auto Sign-In...' 13 417 230 35 $settingsTab
 $autoNote=New-Label 'Opens verified Microsoft Sysinternals AutoLogon. Standard accounts only.' 256 420 478 35 $settingsTab
 $autoNote.ForeColor=[System.Drawing.Color]::FromArgb(152,181,194)
 $gamesInfo=New-Label 'Official resources only. Links open in your default browser; nothing is installed automatically.' 14 16 716 39 $gamesTab
 $gamesInfo.ForeColor=[System.Drawing.Color]::FromArgb(152,181,194)
 $gameItems=@(
  @{name='Steam';desc='Steam game launcher and library';url='https://store.steampowered.com/about/'},
  @{name='Epic Games Launcher';desc='Epic Games Store and launcher';url='https://store.epicgames.com/download'},
  @{name='Battle.net';desc='Blizzard and Activision game launcher';url='https://download.battle.net/en-us/desktop'},
  @{name='GOG GALAXY';desc='GOG game library and launcher';url='https://www.gog.com/galaxy'},
  @{name='KYBER';desc='STAR WARS Battlefront II mod launcher';url='https://kyber.gg/download/'},
  @{name='LAN Party Manager';desc='Optional LAN event hub and desktop companion';url='https://www.lanpartymanager.com/'}
 )
 $gameY=66
 foreach($game in $gameItems){
  $card=New-Object System.Windows.Forms.Panel
  $card.SetBounds(14,$gameY,725,66);$card.BackColor=[System.Drawing.Color]::FromArgb(20,36,44)
  [void]$gamesTab.Controls.Add($card)
  $gameName=New-Label $game.name 13 8 470 23 $card
  $gameName.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
  [void](New-Label $game.desc 13 34 480 22 $card)
  $visit=New-Button 'Open Official Site' 540 17 165 33 $card
  $gameUrl=[string]$game.url
  $tip.SetToolTip($visit,'Opens the official website in your default browser. Does not install software.')
  $visit.Add_Click({
   try {Start-Process -FilePath $gameUrl -ErrorAction Stop}
   catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Unable to open website') | Out-Null}
  }.GetNewClosure())
  $gameY+=73
 }
 function Scan-Accounts {
  $current=if($users.SelectedItem){$users.SelectedItem.ToString()}else{''}
  $script:accounts=@(Get-LocalAccounts);$users.Items.Clear()
  foreach($a in $script:accounts){[void]$users.Items.Add($a.Label)}
  if($users.Items.Count -gt 0){$users.SelectedIndex=0}
  for($i=0;$i -lt $users.Items.Count;$i++){if($users.Items[$i] -eq $current){$users.SelectedIndex=$i;break}}
  if($users.Items.Count -eq 0){ $accountHelp.Text='Account scan unavailable. Account roles must be verified before enforcement.' }
 }
 $scan.Add_Click({Scan-Accounts}); $manual.Add_CheckedChanged({$manualName.Enabled=$manual.Checked;$users.Enabled=-not $manual.Checked})
 function Selected-Account {
  if($manual.Checked){return $manualName.Text.Trim()}
  if($users.SelectedIndex -lt 0){return ''}
  return [string]$script:accounts[$users.SelectedIndex].Name
 }
 function Edit-UrlDialog([string]$current='') {
  $dialog=New-Object System.Windows.Forms.Form;$dialog.Text='Intranet URL';$dialog.Size=New-Object System.Drawing.Size(555,198);$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
  [void](New-Label 'Enter a precise http:// or https:// address, including port if required.' 14 15 515 23 $dialog)
  $field=New-Object System.Windows.Forms.TextBox;$field.SetBounds(14,49,510,30);$field.Text=$current;[void]$dialog.Controls.Add($field)
  $ok=New-Button 'Save URL' 270 101 120 32 $dialog; $cancel=New-Button 'Cancel' 403 101 120 32 $dialog;$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel
  $ok.Add_Click({
   $value=$field.Text.Trim()
   if(-not (Check-Url $value)){[System.Windows.Forms.MessageBox]::Show('Enter a full http(s) URL without wildcards, whitespace, fragments or credentials. Example: http://arcade-server:8080','Invalid URL') | Out-Null;return}
   $dialog.Tag=$value;$dialog.DialogResult='OK';$dialog.Close()
  })
  if($dialog.ShowDialog($form) -eq 'OK'){return [string]$dialog.Tag}
  return $null
 }
 $add.Add_Click({if($urlList.Items.Count -ge 20){[System.Windows.Forms.MessageBox]::Show('Maximum of 20 URLs.')|Out-Null;return};$u=Edit-UrlDialog;if($null -ne $u -and -not $urlList.Items.Contains($u)){[void]$urlList.Items.Add($u)}})
 $edit.Add_Click({if($urlList.SelectedIndex -ge 0){$i=$urlList.SelectedIndex;$old=[string]$urlList.Items[$i];$u=Edit-UrlDialog $old;if($null -ne $u){if($old -match 'discord\.com|discord\.gg|discordapp\.com|discordapp\.net' -and $old -ne $u){if([System.Windows.Forms.MessageBox]::Show('This entry is part of Discord access for gaming and voice. Changing it might break Discord. Continue?', 'Discord Access', 'YesNo', 'Warning') -ne 'Yes'){return}};$urlList.Items[$i]=$u}}})
 $remove.Add_Click({if($urlList.SelectedIndex -ge 0){$old=[string]$urlList.SelectedItem;if($old -match 'discord\.com|discord\.gg|discordapp\.com|discordapp\.net'){if([System.Windows.Forms.MessageBox]::Show('This URL enables Discord web, voice or media features. Remove it anyway?', 'Remove Discord Access?', 'YesNo', 'Warning') -ne 'Yes'){return}};$urlList.Items.RemoveAt($urlList.SelectedIndex)}})
 $autologin.Add_Click({
  try {
   $account=Selected-Account
   $a=@($script:accounts | Where-Object { $_.Name -eq $account -and $_.Admin -eq $false })
   if($manual.Checked -or $a.Count -ne 1){throw 'Select a verified local standard-user account in the dropdown first. Administrator and manual entries are not eligible.'}
   $message="Microsoft Sysinternals Autologon will open. Set the LOCAL standard account: $account. Enter its password in the Microsoft application (not RKA). You can also use Autologon to disable sign-in. This is not a lockdown feature.`r`n`r`nIMPORTANT: passwords remain recoverable to local administrators. Do not configure automatic sign-in for an administrator.`r`n`r`nDownload and launch Microsoft's signed utility?"
   if([System.Windows.Forms.MessageBox]::Show($message,'Configure Customer Auto Sign-In','YesNo','Warning') -ne 'Yes'){return}
   $toolsDir=Join-Path $script:Root 'microsoft-tools';New-Item -ItemType Directory -Path $toolsDir -Force|Out-Null
   $zip=Join-Path $toolsDir 'AutoLogon.zip'; $tool=Join-Path $toolsDir 'Autologon64.exe'
   if(-not(Test-Path $tool)){
     Invoke-WebRequest -Uri 'https://download.sysinternals.com/files/AutoLogon.zip' -OutFile $zip -UseBasicParsing -ErrorAction Stop
     Expand-Archive -LiteralPath $zip -DestinationPath $toolsDir -Force -ErrorAction Stop
   }
   if(-not(Test-Path $tool)){throw 'Microsoft Autologon64.exe was not found in the official downloaded archive.'}
   $sig=Get-AuthenticodeSignature -LiteralPath $tool
   if($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Microsoft'){throw 'Autologon signature verification failed; refusing to launch.'}
   Start-Process -FilePath $tool -Verb RunAs -ErrorAction Stop
   Log 'Opened Microsoft-verified Autologon; no password captured by RKA'
  } catch {Log "Autologon setup error: $($_.Exception.Message)";[System.Windows.Forms.MessageBox]::Show($_.Exception.Message + "`r`n`r`nOfficial documentation: https://learn.microsoft.com/en-us/sysinternals/downloads/autologon",'Auto-login setup') | Out-Null}
 })
 $openIntranet.Add_Click({
  try { $destination=$intranetField.Text.Trim();if(-not(Check-Url $destination)){throw 'Enter a valid http(s) URL under Settings.'};Start-Process -FilePath $destination -ErrorAction Stop }
  catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Unable to open LAN portal')|Out-Null}
 })
$footer=New-Label 'BETA  |  Guest policies stay active until an administrator restores them. Keep recovery access.' 20 648 650 26 $form
 $footer.ForeColor=[System.Drawing.Color]::FromArgb(152,181,194)
 $about=New-Button 'About' 686 645 108 32 $form
 function About-Dialog {
  $d=New-Object System.Windows.Forms.Form;$d.Text='About Retro Knights Arcade Lockdown Agent';$d.Size=New-Object System.Drawing.Size(550,397);$d.StartPosition='CenterParent';$d.FormBorderStyle='FixedDialog';$d.MaximizeBox=$false
  [void](New-Label 'Retro Knights Arcade Lockdown Agent' 18 16 510 30 $d)
  [void](New-Label "Version $script:Version | Windows $([Environment]::OSVersion.Version) | Edition: see Windows Settings > System > About" 18 52 508 42 $d)
  [void](New-Label 'Release notes' 18 105 410 24 $d)
  $versions=New-Object System.Windows.Forms.ComboBox;$versions.DropDownStyle='DropDownList';$versions.SetBounds(18,135,490,27);[void]$d.Controls.Add($versions)
  foreach($v in @('0.2.1 - recovery and connectivity pilot','0.2.0 - Home-compatible recovery trial','0.1.4 - Persistent tray reliability','0.1.3 - Tray and game resources','0.1.2 - Interface improvements','0.1.1 - Diagnostics','0.1.0 - Initial utility')){[void]$versions.Items.Add($v)}
  $notes=New-Object System.Windows.Forms.TextBox;$notes.SetBounds(18,174,490,151);$notes.Multiline=$true;$notes.ReadOnly=$true;$notes.ScrollBars='Vertical';[void]$d.Controls.Add($notes)
  $versions.Add_SelectedIndexChanged({
   $notes.Text=switch($versions.SelectedIndex){
    0 {"- Account enumeration fix, V3-style UI, official logo icon`r`n- LAN portal button and Discord default URLs`r`n- Microsoft-signed Autologon setup launcher`r`n- Manual-restore standard-account policy with independent recovery snapshot; legacy 5-minute rollback compatibility`r`n- Windows 10/11 Home compatibility target; not production hardened"}
    1 {"- Tray owned by a dedicated persistent application context`r`n- Critical window events moved to compiled handlers`r`n- Added tray visibility balloon and 30-second diagnostic heartbeat`r`n- Added running-process/status diagnostic helper`r`n- No lockdown enforcement enabled"}
    2 {"- Windows Forms message loop fix for tray persistence`r`n- Official game installation reference links`r`n- RKA tray icon and application branding`r`n- No enforcement or remote-control commands in this build"}
    3 {"- Tabs for Protection, Processes and Settings`r`n- Account discovery and manual account entry`r`n- Intranet URL Add/Edit/Remove dialogs`r`n- System tray operation and tooltips`r`n- Auto-login guidance; no credential storage`r`n- Protection-changing actions disabled for UI review"}
    4 {"- Expanded startup diagnostics`r`n- Read-only process listing`r`n- Improved launcher error visibility"}
    5 {"- Initial PowerShell Windows Forms interface`r`n- Prototype registry policy and backup utilities"}
   }
  });$versions.SelectedIndex=0
  [void]$d.ShowDialog($form)
 }
 $about.Add_Click({About-Dialog})
 # A separate ApplicationContext owns the message loop and tray icon.
 # The context continues running even if the main Form is hidden.
 # All critical window/tray event handlers are compiled C# to avoid PowerShell callback-scope issues.
 $trayCode = @'
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

public sealed class RkaTrayContext : ApplicationContext
{
    private readonly Form window;
    private readonly NotifyIcon tray;
    private readonly ContextMenuStrip menu;
    private readonly Timer heartbeat;
    private readonly string logPath;
    private bool exiting;
    private bool hideScheduled;
    private bool alreadyExplainedTray;
    public ToolStripMenuItem AboutItem { get; private set; }
    public ToolStripMenuItem OpenItem { get; private set; }
    public ToolStripMenuItem ExitItem { get; private set; }

    public RkaTrayContext(Form form, Icon icon, string logFile)
    {
        window = form;
        logPath = logFile;
        tray = new NotifyIcon();
        tray.Icon = icon;
        tray.Text = "Retro Knights Arcade Lockdown Agent";
        menu = new ContextMenuStrip();
        OpenItem = new ToolStripMenuItem("Open Lockdown Agent");
        AboutItem = new ToolStripMenuItem("About");
        ExitItem = new ToolStripMenuItem("Exit Interface");
        menu.Items.Add(OpenItem);
        menu.Items.Add(AboutItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(ExitItem);
        tray.ContextMenuStrip = menu;
        tray.DoubleClick += (sender, args) => Restore();
        OpenItem.Click += (sender, args) => Restore();
        ExitItem.Click += (sender, args) => ExitInterface();
        window.FormClosing += OnWindowClosing;
        window.FormClosed += (sender, args) => {
            if (!exiting) { Log("Unexpected main window closure"); ExitThread(); }
        };
        window.Resize += OnWindowResize;
        heartbeat = new Timer();
        heartbeat.Interval = 30000;
        heartbeat.Tick += (sender, args) => Log("Heartbeat; window-visible=" + window.Visible + "; tray-visible=" + tray.Visible);
        tray.Visible = true;
        heartbeat.Start();
        Log("Tray context started; icon-visible=" + tray.Visible);
    }

    private void Log(string message)
    {
        try { File.AppendAllText(logPath, DateTime.Now.ToString("o") + " " + message + Environment.NewLine); }
        catch { /* Diagnostics must never crash the UI */ }
    }

    public void ShowMainWindow()
    {
        window.ShowInTaskbar = true;
        window.Show();
        window.WindowState = FormWindowState.Normal;
        window.Activate();
        Log("Main window displayed");
    }

    private void OnWindowClosing(object sender, FormClosingEventArgs args)
    {
        if (exiting || args.CloseReason == CloseReason.WindowsShutDown || args.CloseReason == CloseReason.TaskManagerClosing)
            return;
        args.Cancel = true;
        Log("Close intercepted; hiding to tray");
        QueueHide("X");
    }

    private void OnWindowResize(object sender, EventArgs args)
    {
        if (!exiting && window.WindowState == FormWindowState.Minimized)
        {
            Log("Minimize detected; hiding to tray");
            QueueHide("minimize");
        }
    }

    private void QueueHide(string cause)
    {
        if (hideScheduled || exiting) return;
        hideScheduled = true;
        if (window.IsHandleCreated)
        {
            window.BeginInvoke(new Action(() => {
                try { HideToTray(cause); }
                finally { hideScheduled = false; }
            }));
        }
        else
        {
            HideToTray(cause);
            hideScheduled = false;
        }
    }

    private void HideToTray(string cause)
    {
        if (exiting) return;
        window.Hide();
        window.ShowInTaskbar = false;
        tray.Visible = true;
        Log("Window hidden to tray (" + cause + "); tray-visible=" + tray.Visible);
        if (!alreadyExplainedTray)
        {
            alreadyExplainedTray = true;
            tray.BalloonTipTitle = "RKA Lockdown Agent is still running";
            tray.BalloonTipText = "Open the system tray near the Windows clock (check the ^ hidden-icons menu). Double-click the RKA icon to restore.";
            tray.ShowBalloonTip(5000);
        }
    }

    public void Restore()
    {
        if (exiting) return;
        window.ShowInTaskbar = true;
        if (!window.Visible) window.Show();
        window.WindowState = FormWindowState.Normal;
        window.BringToFront();
        window.Activate();
        Log("Window restored from tray");
    }

    public void ExitInterface()
    {
        if (exiting) return;
        exiting = true;
        Log("Exit Interface selected");
        heartbeat.Stop();
        window.Close();
        ExitThread();
    }

    protected override void ExitThreadCore()
    {
        Log("Tray message loop exiting");
        heartbeat.Stop();
        heartbeat.Dispose();
        tray.Visible = false;
        tray.Dispose();
        menu.Dispose();
        base.ExitThreadCore();
    }
}
'@
 Add-Type -TypeDefinition $trayCode -ReferencedAssemblies @('System.Windows.Forms','System.Drawing') -ErrorAction Stop
 $script:TrayContext = New-Object RkaTrayContext -ArgumentList @($form, $form.Icon, $script:LogFile)
 $script:TrayContext.AboutItem.Add_Click({ About-Dialog })
 function Profile-From-Ui {
  $name=Selected-Account
  $urls=@($urlList.Items | ForEach-Object {[string]$_})
  return @{version=$script:Version;account=$name;intranet=$intranetField.Text.Trim();urls=$urls;blockSettings=[bool]$settings.Checked;blockCmd=[bool]$cmd.Checked;blockRegistry=[bool]$registry.Checked;restrictEdge=[bool]$edge.Checked;networkBrowse=[bool]$network.Checked;hideThisPc=[bool]$thispc.Checked}
 }
 $save.Add_Click({
  try {
   $p=Profile-From-Ui
   if(-not(Check-Url ([string]$p.intranet))){throw 'Enter a valid LAN intranet URL.'}
   $p | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
   Log "Settings saved for profile account $($p.account); no new Windows policy applied"
   [System.Windows.Forms.MessageBox]::Show('Profile saved ONLY. Windows guest restrictions have NOT been applied. To apply, choose Apply Restrictions. It requires administrator elevation and remains active until Restore Previous Settings.','Profile saved','OK','Information') | Out-Null
  } catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Save failed') | Out-Null}
 })
 $script:WorkerPath=Join-Path $PSScriptRoot 'PolicyWorker.ps1'
 function Run-ElevatedWorker([string]$operation,[string]$targetSid='') {
  $params=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$script:WorkerPath+'"'),'-Operation',$operation)
  if($targetSid){$params+=@('-TargetSid',$targetSid,'-ProfilePath',('"'+$script:ProfileFile+'"'))}
  $argsString=$params -join ' '
  $p=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $argsString -Verb RunAs -Wait -PassThru -ErrorAction Stop
  Log "$operation worker exited with code $($p.ExitCode)"
  if($p.ExitCode -ne 0){throw "The $operation operation was not completed. Exit code $($p.ExitCode). Check C:\ProgramData\RKA-Lockdown-Agent\Recovery\worker.log."}
 }
 $lock.Add_Click({
  try {
   if($manual.Checked){throw 'Manual usernames cannot be used for lockdown. Choose a verified standard account.'}
   if($users.SelectedIndex -lt 0){throw 'Select a verified standard Windows account.'}
   $a=$script:accounts[$users.SelectedIndex]
   if($a.Admin -ne $false){throw 'Only verified non-admin Windows accounts can be restricted.'}
   $currentSid=[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
   if($a.SID -eq $currentSid){throw 'Cannot test restrictions on the currently signed-in account. Sign into an administrator account and select a separate guest account.'}
   $p=Profile-From-Ui
   if(-not(Check-Url ([string]$p.intranet))){throw 'Fix the LAN intranet URL under Settings first.'}
   if(-not($p.blockSettings -or $p.blockCmd -or $p.blockRegistry -or $p.restrictEdge)){throw 'Select at least one supported restriction.'}
   $p | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
   $operation='Persistent'
   if([System.Windows.Forms.MessageBox]::Show("Apply selected restrictions to standard Windows user $($a.Name)? They will remain until restored manually. Only proceed after confirming your separate administrator login and Emergency-Restore.cmd are available.",'Apply restrictions — administrator recovery required','YesNo','Warning') -ne 'Yes'){return}
   $confirm=[Microsoft.VisualBasic.Interaction]::InputBox('Type RESTORE READY if you have verified independent administrator access and know how to run Emergency-Restore.cmd.','Confirm recovery plan','')
   if($confirm -cne 'RESTORE READY'){throw 'Recovery confirmation is required; no changes made.'}
   Run-ElevatedWorker $operation ([string]$a.SID)
   $status.Text='Applied to selected standard account (verification recommended). Restore manually when finished.'
   [System.Windows.Forms.MessageBox]::Show("$operation settings were applied. Switch to guest for verification. Recovery is controlled from a separate administrator account. Browser restrictions do not control Chrome, Brave or game installers.",'Policy update','OK','Information')|Out-Null
  } catch { Log "Apply restrictions failed $($_.Exception.Message)";[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Apply restrictions failed')|Out-Null }
 })
 $restore.Add_Click({
  try {
   if([System.Windows.Forms.MessageBox]::Show('Restore the saved policy snapshot now? Requires administrator elevation.','Restore previous settings','YesNo','Question') -ne 'Yes'){return}
   Run-ElevatedWorker 'Restore'
   $status.Text='Restoration verified in registry; sign out of guest to refresh Windows policies.'
   [System.Windows.Forms.MessageBox]::Show('Registry restoration verified. Sign out and back into the guest account to refresh Control Panel and Edge policies.','Restored','OK','Information')|Out-Null
  } catch {Log "Restore failed $($_.Exception.Message)";[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Restore failed')|Out-Null}
 })
 $audit.Add_Click({
  try {
   if($manual.Checked -or $users.SelectedIndex -lt 0){throw 'Choose a verified standard account in Settings first.'}
   $a=$script:accounts[$users.SelectedIndex]
   if($a.Admin -ne $false){throw 'The selected account is not verified as a standard user.'}
   $p=Profile-From-Ui
   $p|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
   Run-ElevatedWorker 'Verify' ([string]$a.SID)
   $path=Join-Path $script:Root 'verification.json'
   if(-not(Test-Path -LiteralPath $path)){throw 'No verification report was created. Check Recovery\worker.log.'}
   $v=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
   if([string]$v.sid -ne [string]$a.SID){throw 'Verification report is for a different account; run Verify Policy again.'}
   $status.Text=if($v.applied){'VERIFIED: '+$v.matchCount+' of '+$v.total+' policy values found for '+$a.Name}else{'NOT VERIFIED: '+$v.matchCount+' of '+$v.total+' policy values found for '+$a.Name}
   $msg="Target standard account: $($a.Name)`r`nRegistry values verified: $($v.matchCount)/$($v.total)`r`nAll selected settings match: $($v.applied)`r`n`r`n"+(@($v.details)-join "`r`n")+"`r`n`r`nWindows may require the guest to sign out and sign in for the policy to take effect. This does not prove that other apps are blocked."
   [System.Windows.Forms.MessageBox]::Show($msg,'Guest Policy Verification','OK','Information')|Out-Null
  }catch{Log ('Verification error: '+$_.Exception.Message);[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Policy verification failed')|Out-Null}
 })
 $script:accounts=@();Scan-Accounts
 $p=LoadProfile
 if($p.intranet){$intranetField.Text=[string]$p.intranet; if($chromeUrl){$chromeUrl.Text=[string]$p.intranet}}
 $settings.Checked=[bool]$p.blockSettings; $cmd.Checked=[bool]$p.blockCmd; $registry.Checked=[bool]$p.blockRegistry;$edge.Checked=[bool]$p.restrictEdge
 $network.Checked=[bool]$p.networkBrowse;$thispc.Checked=[bool]$p.hideThisPc
 foreach($url in @($p.urls)){if($url){[void]$urlList.Items.Add([string]$url)}}
 if($p.account){$manual.Checked=$true;$manualName.Text=[string]$p.account
  for($i=0;$i -lt $script:accounts.Count;$i++){if($script:accounts[$i].Name -eq $p.account -and $script:accounts[$i].Admin -eq $false){$manual.Checked=$false;$users.SelectedIndex=$i;break}}
 }
 # Theme all WinForms controls, retaining existing code-behind behavior.
 $script:Cyan=[System.Drawing.Color]::FromArgb(55,207,232)
 $script:White=[System.Drawing.Color]::FromArgb(235,246,251)
 $script:Soft=[System.Drawing.Color]::FromArgb(158,188,202)
 $script:Panel=[System.Drawing.Color]::FromArgb(16,30,39)
 $script:Input=[System.Drawing.Color]::FromArgb(24,43,53)
 function Set-RkaStyle([System.Windows.Forms.Control]$ctl){
  if($ctl -is [System.Windows.Forms.TabPage]) {$ctl.BackColor=$script:Panel;$ctl.ForeColor=$script:White}
  elseif($ctl -is [System.Windows.Forms.GroupBox]) {$ctl.BackColor=$script:Panel;$ctl.ForeColor=$script:Cyan}
  elseif($ctl -is [System.Windows.Forms.Panel]) {$ctl.BackColor=$script:Panel}
  elseif($ctl -is [System.Windows.Forms.Button]) {$ctl.FlatStyle='Flat';$ctl.FlatAppearance.BorderSize=1;$ctl.FlatAppearance.BorderColor=$script:Cyan;$ctl.BackColor=$script:Input;$ctl.ForeColor=$script:Cyan}
  elseif($ctl -is [System.Windows.Forms.TextBox] -or $ctl -is [System.Windows.Forms.ComboBox] -or $ctl -is [System.Windows.Forms.ListBox] -or $ctl -is [System.Windows.Forms.ListView]) {$ctl.BackColor=$script:Input;$ctl.ForeColor=$script:White}
  elseif($ctl -is [System.Windows.Forms.Label] -or $ctl -is [System.Windows.Forms.CheckBox]) {$ctl.ForeColor=$script:White}
  foreach($child in $ctl.Controls){Set-RkaStyle $child}
 }
 Set-RkaStyle $form
 $form.BackColor=[System.Drawing.Color]::FromArgb(10,17,23)
 $title.ForeColor=$script:Cyan
 $subtitle.ForeColor=$script:Soft
 $footer.ForeColor=$script:Soft
 $banner.ForeColor=$script:Cyan
 $status.ForeColor=$script:Soft
 $accountHelp.ForeColor=$script:Soft
 $autoNote.ForeColor=$script:Soft
 $gamesInfo.ForeColor=$script:Soft
 Log 'UI initialized; starting independent tray-owned application context'
 $script:TrayContext.ShowMainWindow()
 [System.Windows.Forms.Application]::Run([System.Windows.Forms.ApplicationContext]$script:TrayContext)
} catch {
 $message=$_.Exception.ToString()
 try { if(-not(Test-Path $script:Root)){New-Item -Path $script:Root -ItemType Directory -Force|Out-Null};$message|Out-File -LiteralPath (Join-Path $script:Root 'startup-error.txt') -Append -Encoding UTF8 } catch{}
 try {[System.Windows.Forms.MessageBox]::Show($message,'RKA Startup Error') | Out-Null} catch {}
 Write-Host $message -ForegroundColor Red
} finally {
 # TrayContext owns and disposes its own NotifyIcon and message loop.
 if($null -ne $script:BrandIcon){$script:BrandIcon.Dispose()}
 if($null -ne $script:InstanceMutex){
  if($script:OwnsInstanceMutex){try{$script:InstanceMutex.ReleaseMutex()}catch{}}
  $script:InstanceMutex.Dispose()
 }
}
