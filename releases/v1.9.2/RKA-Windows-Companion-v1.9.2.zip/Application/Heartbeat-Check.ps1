# Read-only local connection status check. No token printed.
#Requires -Version 5.1
$taskName='RKA-Lockdown-ReadOnlyHeartbeat'
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'
Write-Host ''
Write-Host 'RETRO KNIGHTS - LOVABLE HEARTBEAT STATUS' -ForegroundColor Cyan
$task=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if($null -eq $task) { Write-Warning 'Heartbeat task is NOT installed. Run RUN-LOVABLE-SETUP.cmd first.'; return }
Write-Host ('Scheduled task: '+$task.State)
$info=Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction SilentlyContinue
if($info){Write-Host ('Last task result: '+$info.LastTaskResult); Write-Host ('Last run: '+$info.LastRunTime)}
$path=Join-Path $root 'status.log'
if(Test-Path -LiteralPath $path) { Write-Host ''; Write-Host 'Most recent check-ins:'; Get-Content -LiteralPath $path -Tail 6 }
else {Write-Warning 'No check-in log yet. Give it a minute or check task privileges.'}
Write-Host ''
Write-Host 'Confirm Live Online status in the Lovable ADMIN PC Management preview.'
