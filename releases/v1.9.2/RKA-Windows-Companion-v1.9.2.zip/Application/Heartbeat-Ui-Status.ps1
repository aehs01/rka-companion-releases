# Requires admin elevation, reads restricted task/config/log, writes NONSECRET local status to admin user's profile.
#Requires -Version 5.1
$ErrorActionPreference='Stop'
$destination=Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent'
if(-not(Test-Path $destination)){New-Item -Path $destination -ItemType Directory -Force|Out-Null}
$report=Join-Path $destination 'heartbeat-ui-status.txt'
try{
  $me=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
  if(-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator elevation required to read protected heartbeat status.'}
  $name='RKA-Lockdown-ReadOnlyHeartbeat'
  $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'
  $config=Join-Path $root 'configuration.json'
  $device='Not enrolled'
  if(Test-Path $config){$cfg=Get-Content -LiteralPath $config -Raw -Encoding UTF8 | ConvertFrom-Json;$device=[string]$cfg.deviceName}
  $task=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
  $lines=@('DEVICE: '+$device)
  if(-not $task){$lines+='TASK: NOT INSTALLED'}else{
    $details=Get-ScheduledTaskInfo -TaskName $name -ErrorAction SilentlyContinue
    $lines+='TASK: '+[string]$task.State
    if($details){$lines+='LAST RESULT: '+$details.LastTaskResult;$lines+='LAST RUN: '+$details.LastRunTime}else{$lines+='LAST RESULT: Not available'}
  }
  $statusLog=Join-Path $root 'status.log'
  if(Test-Path $statusLog){$lines+='';$lines+='RECENT HEARTBEATS:';$lines+=@(Get-Content -LiteralPath $statusLog -Tail 6)}
  else{$lines+='';$lines+='No heartbeat log was found.'}
  $lines+='';$lines+='Local status only. Verify Online from Partner Dashboard > LAN Management.'
  $lines|Set-Content -LiteralPath $report -Encoding UTF8
  exit 0
}catch{
  ('LOCAL STATUS FAILED: '+$_.Exception.Message)|Set-Content -LiteralPath $report -Encoding UTF8
  exit 1
}
