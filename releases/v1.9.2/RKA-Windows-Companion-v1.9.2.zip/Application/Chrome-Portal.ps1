# Chrome portal startup for a logged-on standard user. No elevated operations here.
param([string]$ConfigPath="$env:ProgramData\RKA-Lockdown-Agent\ChromePortal\config.json",[switch]$Test)
$ErrorActionPreference='Stop'
if(-not(Test-Path -LiteralPath $ConfigPath)){exit 2}
$c=Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $c.enabled -and -not $Test){exit 0}
$uri=$null
if(-not [Uri]::TryCreate([string]$c.url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.UserInfo){exit 3}
$expectedSid=[string]$c.sid
$current=[Security.Principal.WindowsIdentity]::GetCurrent()
if($current.User.Value -ne $expectedSid){exit 4}
$p=New-Object Security.Principal.WindowsPrincipal($current)
if($p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){exit 5}
if(-not $Test){Start-Sleep -Seconds ([Math]::Min(120,[Math]::Max(0,[int]$c.delay)))}
$chromeCandidates=@("$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe","$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
$chrome=$chromeCandidates|Where-Object {$_ -and (Test-Path -LiteralPath $_)}|Select-Object -First 1
if(-not $chrome){exit 6}
# Avoid duplicate portal window if user already has Chrome running.
if(-not $Test -and (Get-Process chrome -ErrorAction SilentlyContinue)){exit 0}
$mode=[string]$c.mode
$args=@()
if($mode -eq 'Normal'){$args=@('--new-window',[string]$uri.AbsoluteUri)}
elseif($mode -eq 'Fullscreen'){$args=@('--start-fullscreen',[string]$uri.AbsoluteUri)}
else{$args=@('--app='+[string]$uri.AbsoluteUri,'--start-maximized')}
# Chrome App Mode is windowed, but should occupy the available guest work area.
# --start-maximized respects taskbar; unlike kiosk fullscreen, the Windows shell remains accessible.
$started=Start-Process -FilePath $chrome -ArgumentList $args -PassThru -ErrorAction Stop
if($mode -eq 'App' -and $started){
 try{
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class RkaChromeMaximize {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd, int command);
}
'@ -ErrorAction Stop
  for($i=0;$i -lt 20;$i++){
   Start-Sleep -Milliseconds 250
   $started.Refresh()
   if($started.MainWindowHandle -ne [IntPtr]::Zero){
    [void][RkaChromeMaximize]::ShowWindow($started.MainWindowHandle,3)
    break
   }
  }
 }catch{# Chrome may hand off the app window to an existing process; start-maximized still requested.
 }
}
