@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL-OR-REPAIR-BACKGROUND-AGENT.ps1"
if errorlevel 1 (echo Background agent repair failed. & pause)
