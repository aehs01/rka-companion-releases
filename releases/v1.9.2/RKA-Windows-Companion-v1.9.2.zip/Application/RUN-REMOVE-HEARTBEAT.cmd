@echo off
setlocal
cd /d "%~dp0"
fltmc >nul 2>&1
if errorlevel 1 (
  set "RKA_LAUNCHER=%~f0"
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList ('/c ' + [char]34 + $env:RKA_LAUNCHER + [char]34) -Verb RunAs"
  exit /b
)
echo This removes the Lovable heartbeat task and local enrollment token.
choice /M "Continue"
if errorlevel 2 exit /b
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Heartbeat-Remove.ps1"
echo.
pause
