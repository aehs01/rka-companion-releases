
$running=@(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" | Where-Object { $_.CommandLine -like '*RKA-Lockdown.ps1*' })
Write-Host ("Found {0} RKA PowerShell processes:" -f $running.Count)
$running | Select-Object ProcessId,CommandLine | Format-List
$log=Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent\ui.log'
if(Test-Path $log){ Write-Host 'Last 20 log lines:'; Get-Content -LiteralPath $log -Tail 20 } else { Write-Host 'No UI log found yet.' }
$err=Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent\startup-error.txt'
if(Test-Path $err){ Write-Host 'Latest startup error:'; Get-Content -LiteralPath $err -Tail 15 }
