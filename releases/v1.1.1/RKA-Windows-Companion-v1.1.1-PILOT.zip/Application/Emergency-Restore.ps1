# This launcher only requests administrator permission for the fixed emergency-restore helper.
$ErrorActionPreference='Stop'
$worker=Join-Path $PSScriptRoot 'PolicyWorker.ps1'
if(-not(Test-Path -LiteralPath $worker)){throw 'PolicyWorker.ps1 is missing.'}
$arg='-NoProfile -ExecutionPolicy Bypass -File "'+$worker+'" -Operation Restore'
$proc=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arg -Verb RunAs -Wait -PassThru
if($proc.ExitCode -eq 0){Write-Host 'Recovery completed. Sign into the guest account and verify settings.' -ForegroundColor Green}
else{Write-Warning ('Recovery failed or no trial active. Exit code '+$proc.ExitCode+'. Check C:\ProgramData\RKA-Lockdown-Agent\Recovery\worker.log')}
