# Retro Knights Arcade Companion v1.1.1 - administrator-initiated public GitHub updater.
# Public releases only; fixed source repository; no credentials, arbitrary feeds, or unattended installs.
# A GitHub release asset digest is an integrity check against GitHub metadata, NOT a publisher signature.
#Requires -Version 5.1
param(
 [ValidateSet('Check','Download','InstallStaged','InstallLocal')][string]$Action='Check',
 [ValidateSet('Stable','Pilot')][string]$Channel='Stable',
 [string]$ZipPath=''
)
$ErrorActionPreference='Stop'
$repo='aehs01/rka-companion-releases'
$api='https://api.github.com/repos/aehs01/rka-companion-releases/releases?per_page=40'
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Updater'
$stageFile=Join-Path $root 'staged-release.json'
$log=Join-Path $root 'updater.log'
function Require-Admin {
 $p=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Update operations require an elevated local administrator.'}
}
function Secure-Root {
 if(-not(Test-Path -LiteralPath $root)){[void](New-Item -Path $root -ItemType Directory -Force)}
 & "$env:SystemRoot\System32\icacls.exe" $root '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Cannot protect local updater folder.'}
}
function Log([string]$message){try{Add-Content -LiteralPath $log -Encoding UTF8 -Value ((Get-Date).ToString('o')+' '+$message)}catch{}}
function Install-Root {return (Split-Path -Path $PSScriptRoot -Parent)}
function Installed-Version {
 $app=Join-Path (Install-Root) 'Application\RKA-WPF.ps1'
 if(-not(Test-Path -LiteralPath $app)){throw 'Installed Companion UI not found.'}
 $src=Get-Content -LiteralPath $app -Raw -Encoding UTF8
 $m=[regex]::Match($src,"(?m)^\`$script:AppVersion = '(\d+\.\d+\.\d+)'\s*$")
 if(-not $m.Success){throw 'Installed Companion version missing.'}
 return [version]$m.Groups[1].Value
}
function Validate-Package([string]$source,[version]$installed,[version]$expected){
 if(-not(Test-Path -LiteralPath $source -PathType Leaf) -or [IO.Path]::GetExtension($source) -ine '.zip'){throw 'Release ZIP is missing or invalid.'}
 if((Get-Item -LiteralPath $source).Length -gt 25MB){throw 'ZIP exceeds 25 MB safety limit.'}
 Add-Type -AssemblyName System.IO.Compression
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $zip=[IO.Compression.ZipFile]::OpenRead($source)
 $seen=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 try{
  $entries=@($zip.Entries)
  if($entries.Count -lt 60 -or $entries.Count -gt 180){throw 'Unexpected release ZIP structure.'}
  $total=[long]0
  foreach($entry in $entries){
   $n=[string]$entry.FullName
   if($n.Contains('\') -or $n.StartsWith('/') -or $n.Contains(':') -or $n -match '(^|/)\.\.?(/|$)' -or -not($n -eq 'Retro Knights PC Control Center.vbs' -or $n.StartsWith('Application/'))){throw ('Unsafe ZIP path: '+$n)}
   if(-not $seen.Add($n)){throw ('Duplicate ZIP entry: '+$n)}
   if((($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000){throw 'ZIP symlink refused.'}
   if($entry.Length -gt 5MB){throw 'Oversized ZIP entry refused.'}
   $total+=$entry.Length
  }
  if($total -gt 45MB){throw 'ZIP uncompressed size exceeds safety limit.'}
  foreach($name in @('Application/RKA-WPF.ps1','Application/RKA-Window.xaml','Application/Remote-Agent.ps1','Application/Remote-Setup.ps1','Application/PolicyWorker.ps1','Application/Update-Manager.ps1','Application/Game-Compatibility.ps1','Application/Copy-Admin-Shortcuts.ps1','Retro Knights PC Control Center.vbs')){
   if(-not $seen.Contains($name)){throw ('ZIP required file missing: '+$name)}
  }
  $ui=New-Object IO.StreamReader ($zip.GetEntry('Application/RKA-WPF.ps1').Open())
  try{$uiText=$ui.ReadToEnd()}finally{$ui.Dispose()}
  $ag=New-Object IO.StreamReader ($zip.GetEntry('Application/Remote-Agent.ps1').Open())
  try{$agentText=$ag.ReadToEnd()}finally{$ag.Dispose()}
  $m=[regex]::Match($uiText,"(?m)^\`$script:AppVersion = '(\d+\.\d+\.\d+)'\s*$")
  $v=[regex]::Match($agentText,"(?m)^\`$agentVersion='(\d+\.\d+\.\d+)'\s*$")
  if(-not $m.Success -or -not $v.Success -or $m.Groups[1].Value -ne $v.Groups[1].Value){throw 'Companion and agent version markers are missing or mismatched.'}
  $found=[version]$m.Groups[1].Value
  if($found -le $installed){throw ('ZIP v'+$found+' is not newer than installed v'+$installed)}
  if($null -ne $expected -and $found -ne $expected){throw 'ZIP version differs from authenticated release metadata.'}
  return $found
 }finally{$zip.Dispose()}
}
function Find-Release([string]$channel){
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 $headers=@{'Accept'='application/vnd.github+json';'User-Agent'='RKA-Windows-Companion-Updater/1.1.1'}
 # Windows PowerShell 5.1 can emit a JSON array as ONE pipeline item; do not wrap Invoke-RestMethod with @(...).
 $releases=Invoke-RestMethod -Uri $api -Headers $headers -Method Get -TimeoutSec 20 -MaximumRedirection 0
 $candidateList=@()
 foreach($release in $releases){
  if($release.draft -eq $true){continue}
  $tag=[string]$release.tag_name
  if(-not ($tag -cmatch '^v(\d{1,3}\.\d{1,3}\.\d{1,3})(-PILOT)?$')){continue}
  $v=[version]$Matches[1];$pilot=($Matches[2] -eq '-PILOT')
  if(($pilot -and -not [bool]$release.prerelease) -or (-not $pilot -and [bool]$release.prerelease)){continue}
  if($channel -eq 'Stable' -and $pilot){continue}
  $name='RKA-Windows-Companion-v'+$v+$(if($pilot){'-PILOT'}else{''})+'.zip'
  $asset=@($release.assets | Where-Object {$_.name -ceq $name -and $_.state -eq 'uploaded'})
  if($asset.Count -ne 1){continue}
  $a=$asset[0]
  $digest=[string]$a.digest
  if($digest -cnotmatch '^sha256:[a-fA-F0-9]{64}$'){continue}
  if([long]$a.size -lt 100KB -or [long]$a.size -gt 25MB){continue}
  $url='https://github.com/'+$repo+'/releases/download/'+$tag+'/'+$name
  if([string]$a.browser_download_url -cne $url){continue}
  $candidateList+=@{version=$v;tag=$tag;pilot=$pilot;url=$url;digest=$digest.Substring(7).ToLowerInvariant();size=[long]$a.size;name=$name}
 }
 if($candidateList.Count -eq 0){return $null}
 return $candidateList|Sort-Object -Property @{Expression={$_.version};Descending=$true},@{Expression={$_.pilot};Descending=$false}|Select-Object -First 1
}
function Download-Release($release){
 $destination=Join-Path $root $release.name
 $part=Join-Path $root ('download-'+[guid]::NewGuid().ToString('N')+'.zip')
 if(Test-Path -LiteralPath $part){Remove-Item -LiteralPath $part -Force}
 try{
  Invoke-WebRequest -Uri $release.url -UseBasicParsing -OutFile $part -TimeoutSec 120 -Headers @{'User-Agent'='RKA-Windows-Companion-Updater/1.1.1'}
  if((Get-Item -LiteralPath $part).Length -ne $release.size){throw 'Downloaded file size does not match GitHub asset metadata.'}
  $actual=(Get-FileHash -LiteralPath $part -Algorithm SHA256).Hash.ToLowerInvariant()
  if($actual -cne $release.digest){throw 'GitHub asset SHA-256 mismatch; download rejected.'}
  [void](Validate-Package $part (Installed-Version) $release.version)
  Move-Item -LiteralPath $part -Destination $destination -Force
  $saved=@{version=[string]$release.version;tag=$release.tag;sha256=$release.digest;name=$release.name;size=$release.size;zip=$destination;source_repository=$repo;checked_at=(Get-Date).ToUniversalTime().ToString('o')}
  $tmp=$stageFile+'.tmp';$saved|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $tmp -Encoding UTF8 -NoNewline
  Move-Item -LiteralPath $tmp -Destination $stageFile -Force
  return $destination
 }finally{if(Test-Path -LiteralPath $part){Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue}}
}
function Install-Package([string]$zipPath,[version]$expected,[string]$expectedHash){
 $installRoot=Install-Root
 if(-not(Test-Path -LiteralPath (Join-Path $installRoot 'Retro Knights PC Control Center.vbs'))){throw 'Unexpected Companion installation folder.'}
 $current=Installed-Version
 $next=Validate-Package $zipPath $current $expected
 $hash=(Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
 if($expectedHash -and $hash -cne $expectedHash){throw 'Staged download differs from previously checked GitHub release.'}
 Log ('Administrator approved update from v'+$current+' to v'+$next+'; sha256 '+$hash)
 $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
 $backup=Join-Path $root ('Backup-'+$stamp+'-v'+$current)
 $stage=Join-Path $root ('Extract-'+[guid]::NewGuid().ToString('N'))
 [void](New-Item -Path $backup -ItemType Directory -Force)
 [void](New-Item -Path $stage -ItemType Directory -Force)
 $changed=New-Object System.Collections.ArrayList
 try{
  [IO.Compression.ZipFile]::ExtractToDirectory($zipPath,$stage)
  $files=@(Get-ChildItem -LiteralPath $stage -File -Recurse -ErrorAction Stop)
  foreach($file in $files){
   $rel=$file.FullName.Substring($stage.Length+1)
   $target=Join-Path $installRoot $rel
   if(Test-Path -LiteralPath $target){
    $old=Join-Path $backup $rel
    [void](New-Item -Path (Split-Path $old -Parent) -ItemType Directory -Force)
    Copy-Item -LiteralPath $target -Destination $old -ErrorAction Stop
   }
   [void]$changed.Add($rel)
  }
  foreach($file in $files){
   $rel=$file.FullName.Substring($stage.Length+1)
   $dest=Join-Path $installRoot $rel
   [void](New-Item -Path (Split-Path $dest -Parent) -ItemType Directory -Force)
   Copy-Item -LiteralPath $file.FullName -Destination $dest -Force -ErrorAction Stop
  }
  # Agent installer is a separate process: a script's 'exit 1' must NOT abort
  # this updater before it has a chance to restore the previous files.
  $enrollment=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat\configuration.json'
  if(Test-Path -LiteralPath $enrollment){
   $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
   $setup=Join-Path $installRoot 'Application\Remote-Setup.ps1'
   $args='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$setup+'" -Action Upgrade'
   $p=Start-Process -FilePath $exe -ArgumentList $args -PassThru -Wait -WindowStyle Hidden -ErrorAction Stop
   if($p.ExitCode -ne 0){throw ('Agent upgrade exited '+$p.ExitCode+'; review protected remote.log. The app files will be restored.')}
   Write-Output 'Agent tasks upgraded; confirm a fresh authenticated Lovable poll.'
  }else{Write-Output 'Companion installed; no enrolled agent was found. Enroll separately.'}
  if((Installed-Version) -ne $next){throw 'Installed UI version did not verify.'}
  Log ('Installed v'+$next+'; previous application files backed up '+$backup)
  Write-Output ('UPDATE INSTALLED: v'+$next+'; restart the Companion UI.')
  Write-Output ('Rollback files saved: '+$backup)
 }catch{
  $why=$_.Exception.Message
  foreach($rel in @($changed)){
   $dest=Join-Path $installRoot $rel;$old=Join-Path $backup $rel
   if(Test-Path -LiteralPath $old){Copy-Item -LiteralPath $old -Destination $dest -Force -ErrorAction SilentlyContinue}
   elseif(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue}
  }
  Log ('UPDATE FAILED; file rollback attempted: '+$why)
  throw ('Update failed. Previous application files restored where possible. '+$why+' Backup: '+$backup)
 }finally{if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}}
}
try{
 Require-Admin
 Secure-Root
 $current=Installed-Version
 switch($Action){
  'Check' {
   $release=Find-Release $Channel
   Write-Output ('Installed Companion: v'+$current+' | Update channel: '+$Channel)
   if(-not $release){Write-Output 'No published releases available for this channel.';break}
   Write-Output ('Latest published release: '+$release.tag)
   if($release.version -gt $current){Write-Output ('UPDATE AVAILABLE: v'+$release.version)}
   else{Write-Output 'Companion is up to date for this channel.'}
  }
  'Download' {
   $release=Find-Release $Channel
   if(-not $release -or $release.version -le $current){throw 'No newer release available in the selected channel.'}
   $path=Download-Release $release
   Log ('Verified and staged '+$release.tag+' (GitHub asset digest).')
   Write-Output ('STAGED RELEASE: '+$release.tag)
   Write-Output ('STAGED PATH: '+$path)
   Write-Output 'GitHub SHA-256 verified. Publisher code-signing is not configured.'
   Write-Output 'Installation requires a separate explicit administrator approval.'
  }
  'InstallStaged' {
   if(-not(Test-Path -LiteralPath $stageFile)){throw 'No previously downloaded release staged.'}
   $saved=Get-Content -LiteralPath $stageFile -Raw -Encoding UTF8|ConvertFrom-Json
   if([string]$saved.source_repository -cne $repo -or [string]$saved.sha256 -cnotmatch '^[0-9a-f]{64}$' -or [string]$saved.name -notmatch '^RKA-Windows-Companion-v\d+\.\d+\.\d+(-PILOT)?\.zip$'){throw 'Staged release metadata invalid.'}
   $safe=Join-Path $root ([string]$saved.name)
   if([IO.Path]::GetFullPath([string]$saved.zip) -cne [IO.Path]::GetFullPath($safe)){throw 'Staged release path is not in protected updater folder.'}
   if((Get-Item -LiteralPath $safe).Length -ne [long]$saved.size){throw 'Staged release size changed.'}
   Install-Package $safe ([version]$saved.version) ([string]$saved.sha256)
   Remove-Item -LiteralPath $stageFile -Force -ErrorAction SilentlyContinue
  }
  'InstallLocal' {
   if(-not $ZipPath){throw 'Select a local or LAN ZIP.'}
   Write-Output 'WARNING: Manual local ZIP is administrator-trusted input; publisher signature not verified.'
   Install-Package $ZipPath $null ''
  }
 }
}catch{Log ('Updater ERROR: '+$_.Exception.Message);Write-Error $_.Exception.Message;exit 1}
