# v1.1.1 Read-only Windows 10/11 Home heartbeat. Invoked as SYSTEM once per minute.
# It sends only device liveness and NEVER accepts remote commands or changes policy.
#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 does not automatically load System.Security from the GAC.
# The DPAPI ProtectedData class lives in that assembly on Windows 10/11.
try {
    Add-Type -AssemblyName System.Security -ErrorAction Stop
    if ($null -eq ('System.Security.Cryptography.ProtectedData' -as [type])) {
        throw 'ProtectedData type is unavailable after System.Security was loaded.'
    }
} catch {
    throw 'Cannot initialize Windows DPAPI encryption. Use Windows PowerShell 5.1 (powershell.exe) on Windows 10/11; setup cannot safely proceed.'
}

$root = Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat'
$cfgPath = Join-Path $root 'configuration.json'
$log = Join-Path $root 'status.log'
function Write-Safe([string]$message) {
    try { Add-Content -LiteralPath $log -Value "$(Get-Date -Format o) $message" -Encoding UTF8 } catch {}
}
$token = $null
$key = $null
try {
    if (-not (Test-Path -LiteralPath $cfgPath)) { throw 'Missing protected heartbeat configuration.' }
    $cfg = Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$cfg.endpoint -ne 'https://zallpwnkizoxxxkufbfq.supabase.co/functions/v1/rka-pc-heartbeat') { throw 'Unexpected endpoint.' }
    if ([string]$cfg.deviceName -cnotmatch '^[A-Z0-9-]{3,40}$') { throw 'Invalid enrolled device name.' }
    $key = [System.Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String([string]$cfg.tokenEncrypted),$null,[System.Security.Cryptography.DataProtectionScope]::LocalMachine)
    $token = [Text.Encoding]::UTF8.GetString($key)
    if ($token -cnotmatch '^rka_pc_[A-Za-z0-9_-]{43}$') { throw 'Missing or invalid enrollment credential.' }
    $os = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption
    # Never trust a version marker written by an installer. Require an authenticated
    # successful Remote-Agent poll in the last 4 minutes, with an active SYSTEM task.
    # Legacy fallback is intentionally outdated, NOT proof of the installed version.
    $healthFile=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl\agent-health.json'
    $version='0.0.0'
    try{
        $agentTask=Get-ScheduledTask -TaskName 'RKA-Remote-Commands' -ErrorAction Stop
        if(Test-Path -LiteralPath $healthFile){
            $agentHealth=Get-Content -LiteralPath $healthFile -Raw -Encoding UTF8|ConvertFrom-Json
            $confirmed=[datetimeoffset]::MinValue
            if(([string]$agentHealth.version) -match '^\d{1,3}\.\d{1,3}\.\d{1,3}$' -and
               [datetimeoffset]::TryParse([string]$agentHealth.confirmedUtc,[ref]$confirmed) -and
               [datetimeoffset]::UtcNow -ge $confirmed -and
               ([datetimeoffset]::UtcNow-$confirmed).TotalMinutes -lt 4 -and
               $agentTask.Principal.UserId -in @('SYSTEM','S-1-5-18') -and $agentTask.State -ne 'Disabled'){
                $version=[string]$agentHealth.version
            }
        }
    }catch{Write-Safe 'Remote agent has no recent authenticated poll; reporting legacy/unverified version.'}
    $body = @{ version=1; device_id=[string]$cfg.deviceName; state='unverified'; os=[string]$os; agent_version=$version } | ConvertTo-Json -Compress
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $response = Invoke-RestMethod -Method POST -Uri $cfg.endpoint -Headers @{ 'X-RKA-Device-Token'=$token } -Body $body -ContentType 'application/json' -TimeoutSec 15
    if ($response.ok -ne $true -or $response.state -ne 'unverified') { throw 'Unexpected heartbeat response.' }
    Write-Safe 'Heartbeat accepted by Lovable (read-only; status Unverified).'
} catch {
    # Do not log token, URL, request payload, or exception response bodies.
    Write-Safe 'Heartbeat failed. Check the device name, token, internet, and enrollment status.'
    exit 1
} finally {
    if ($null -ne $key) { [Array]::Clear($key,0,$key.Length) }
    $token = $null
}
