# RKA remote command agent v1.1.1. SYSTEM task, separate from existing heartbeat.
# Polls ONLY typed commands accepted by the server. No arbitrary script, path, URL or payload.
# The installer explicitly opts in to unattended modifications; destructive operations off by default.
#Requires -Version 5.1
$ErrorActionPreference='Stop'
$agentVersion='1.1.1'
$root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
$configPath=Join-Path $root 'remote-config.json'
$heartbeatPath=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat\configuration.json'
$log=Join-Path $root 'remote.log'
$processed=Join-Path $root 'seen-command-ids'
# Set when Lovable rejects the 1.1 poll (it doesn't know the new fields yet).
$legacyMark=Join-Path $root 'lovable-legacy.json'
$clientStatusFile=Join-Path $env:ProgramData 'RKA-Client\status\status.json'
$staffCallFile=Join-Path $env:ProgramData 'RKA-Client\status\staff-call.json'
$staffCallSent=Join-Path $root 'staff-call-sent.txt'
# Lovable lists what else it accepts in its poll reply (features: ['staff_call']).
$featuresFile=Join-Path $root 'lovable-features.json'
$endpoint='https://zallpwnkizoxxxkufbfq.supabase.co/functions/v1/rka-pc-agent-command'
$mutex=$null;$mutexHeld=$false
. (Join-Path $PSScriptRoot 'Remote-Operations.ps1')
function Get-Capabilities($conf,[bool]$legacy=$false){
 $all=@('policy_status')
 if([bool]$conf.allowChanges){
  $all+=@('shutdown_pc','power_delay','set_guest_restriction','set_chrome_autolaunch','set_browser_allowlist','send_announcement','apply_wallpaper','restore_wallpaper')
  if([bool]$conf.allowUsb){$all+='set_usb_storage'}
  # 1.1 capabilities. Lovable refuses a poll that lists a capability it doesn't know,
  # so they are only sent once Lovable accepts them (see Poll-Once).
  if(-not $legacy){
   $all+='set_lan_firewall'
   if(Test-Path -LiteralPath (Client-Inbox) -PathType Container){$all+=@('reset_session','set_staff_mode')}
  }
 }
 return @($all)
}
function Lovable-Legacy {
 if(-not(Test-Path -LiteralPath $legacyMark)){return $false}
 try{$m=Get-Content -LiteralPath $legacyMark -Raw -Encoding UTF8|ConvertFrom-Json;return (([DateTime]::UtcNow-([DateTime]::Parse([string]$m.since)).ToUniversalTime()).TotalHours -lt 1)}catch{return $false}
}
# A customer pressed Call staff in RKA Client (written as the guest, so checked
# and sent once). Calls older than 10 minutes are dropped.
function Get-StaffCall {
 try{
  if(-not(Test-Path -LiteralPath $staffCallFile)){return $null}
  if((Get-Item -LiteralPath $staffCallFile).Length -gt 1024){return $null}
  $c=Get-Content -LiteralPath $staffCallFile -Raw -Encoding UTF8|ConvertFrom-Json
  $id=([string]$c.id).ToLowerInvariant()
  if($id -cnotmatch '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'){return $null}
  $at=[datetimeoffset]::MinValue
  if(-not [datetimeoffset]::TryParse([string]$c.requestedUtc,[ref]$at) -or ([datetimeoffset]::UtcNow-$at).TotalMinutes -gt 10 -or $at -gt [datetimeoffset]::UtcNow.AddMinutes(1)){return $null}
  if((Test-Path -LiteralPath $staffCallSent) -and ([string](Get-Content -LiteralPath $staffCallSent -Raw)).Trim() -ceq $id){return $null}
  return @{id=$id;requested_at=$at.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')}
 }catch{return $null}
}
function Lovable-Features {
 try{if(Test-Path -LiteralPath $featuresFile){return @((Get-Content -LiteralPath $featuresFile -Raw -Encoding UTF8|ConvertFrom-Json).features|ForEach-Object {[string]$_})}}catch{}
 return @()
}
# Tells RKA Client what Lovable can take, so Call staff only shows when someone
# will actually get the call. SYSTEM writes it; guests can only read the inbox.
function Save-LovableFeatures([string[]]$features){
 @{features=@($features);savedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $featuresFile -Encoding UTF8
 $inbox=Client-Inbox
 if(Test-Path -LiteralPath $inbox -PathType Container){
  $body=@{schema=1;kind='features';staffCalls=('staff_call' -in $features);updatedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Compress
  $tmp=Join-Path $inbox 'features.json.tmp'
  [IO.File]::WriteAllText($tmp,$body,(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination (Join-Path $inbox 'features.json') -Force
 }
}
function Is-BadRequest($err){try{return ([int]$err.Exception.Response.StatusCode -eq 400)}catch{return $false}}
# RKA Client writes this file as the guest, so every value is checked against a
# fixed shape and anything unexpected drops the whole report. It is never acted on.
function Get-ClientReport {
 try{
  if(-not(Test-Path -LiteralPath $clientStatusFile)){return $null}
  if((Get-Item -LiteralPath $clientStatusFile).Length -gt 4096){return $null}
  $s=Get-Content -LiteralPath $clientStatusFile -Raw -Encoding UTF8|ConvertFrom-Json
  $updated=[datetimeoffset]::MinValue
  if(([string]$s.version) -notmatch '^\d{1,3}\.\d{1,3}\.\d{1,3}$' -or ([string]$s.mode) -notin @('locked','staff','open') -or
     -not [datetimeoffset]::TryParse([string]$s.updatedUtc,[ref]$updated)){return $null}
  $reset=$null;$r=[datetimeoffset]::MinValue
  if($s.lastResetUtc -and [datetimeoffset]::TryParse([string]$s.lastResetUtc,[ref]$r)){$reset=$r.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')}
  $launchers=@($s.launchers|ForEach-Object {[string]$_}|Where-Object {$_ -cmatch '^[a-z0-9-]{1,24}$'}|Select-Object -Unique -First 16)
  return @{version=[string]$s.version;mode=[string]$s.mode;customer_active=[bool]$s.customerActive;last_reset_at=$reset;launchers_installed=$launchers;updated_at=$updated.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')}
 }catch{return $null}
}

$secret=$null;$bytes=$null
function Write-Safe([string]$msg){
 try{if(Test-Path -LiteralPath $root){Add-Content -LiteralPath $log -Value ("$(Get-Date -Format o) "+($msg -replace 'rka_pc_[A-Za-z0-9_-]+','[REDACTED]')) -Encoding UTF8}}catch{}
}
function Is-ValidSid([string]$sid){return ($sid -match '^S-1-5-21-[0-9]{6,12}-[0-9]{6,12}-[0-9]{6,12}-[0-9]{3,6}$' -and $sid -notmatch '-(500|501|503|504)$')}
function StandardAccounts {
 $adminSids=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
 $accounts=@()
 foreach($a in @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop)){
  if($a.Disabled -or $a.Lockout -or (-not(Is-ValidSid ([string]$a.SID))) -or $adminSids -contains $a.SID){continue}
  $accounts+=@{sid=[string]$a.SID;account_name=([string]$a.Name).Substring(0,[Math]::Min(64,([string]$a.Name).Length))}
 }
 return $accounts
}
function Verify-Target([string]$sid,[string]$profilePath){
 if(-not(Is-ValidSid $sid)){throw 'Remote guest SID does not satisfy local-account requirements.'}
 $match=@(StandardAccounts | Where-Object {$_.sid -ceq $sid})
 if($match.Count -ne 1){throw 'Guest SID no longer identifies one enabled local standard user.'}
 if(-not(Test-Path -LiteralPath $profilePath)){throw 'No administrator-approved remote policy profile; sync it locally.'}
 $profile=Get-Content -LiteralPath $profilePath -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$profile.account -cne [string]$match[0].account_name){throw 'Policy profile account does not match target SID.'}
 if(-not ($profile.blockSettings -or $profile.blockCmd -or $profile.blockRegistry -or $profile.blockTaskManager -or $profile.restrictEdge)){throw 'No locally approved supported policy actions configured.'}
 return $profile
}
function Post-Server([hashtable]$body){
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 return Invoke-RestMethod -Method POST -Uri $endpoint -Headers @{'X-RKA-Device-Token'=$secret} -Body ($body|ConvertTo-Json -Compress -Depth 8) -ContentType 'application/json' -TimeoutSec 12
}
function Simple-Diagnostics {
 $os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
 $disk=Get-CimInstance Win32_LogicalDisk -Filter 'DeviceID="C:"' -ErrorAction SilentlyContinue
 $hb=Get-ScheduledTask -TaskName 'RKA-Lockdown-ReadOnlyHeartbeat' -ErrorAction SilentlyContinue
 $guestCount=-1
 try{$guestCount=@(StandardAccounts).Count}catch{}
 return @{agent_version=$agentVersion;computer=$env:COMPUTERNAME;os=$os.Caption;uptime_minutes=$(if($os){[int]((Get-Date)-$os.LastBootUpTime).TotalMinutes}else{$null});free_gb=$(if($disk){[math]::Round($disk.FreeSpace/1GB,1)}else{$null});guest_count=$guestCount;heartbeat_task=$(if($hb){[string]$hb.State}else{'missing'});testedAt=(Get-Date -Format 'o')}
}
function Worker([string]$operation,[string]$targetSid,[string]$profile){
 $policy=Join-Path $root 'PolicyWorker.ps1'
 if(-not(Test-Path -LiteralPath $policy)){throw 'Protected policy worker missing.'}
 $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $args='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$policy+'" -Operation '+$operation
 if($targetSid){$args+=' -TargetSid "'+$targetSid+'"'}
 if($profile){$args+=' -ProfilePath "'+$profile+'"'}
 $proc=Start-Process -FilePath $exe -ArgumentList $args -PassThru -Wait -WindowStyle Hidden
 if($proc.ExitCode -ne 0){throw ('Policy worker returned '+$proc.ExitCode+'; consult local Recovery\worker.log.')}
}
function Execute-Typed($cmd,$conf){
 $kind=[string]$cmd.kind
 $sid=[string]$cmd.target_sid
 $profilePath=Join-Path $root 'approved-policy.json'
 $changes=[bool]$conf.allowChanges
 if($kind -ne 'refresh_diagnostics' -and -not $changes){throw 'Remote changes disabled by local administrator'}
 switch($kind){
  'refresh_diagnostics' {return @{ok=$true;result=(Simple-Diagnostics)}}
  {$_ -in @('restart_pc','shutdown_pc')} {
   $delay=90
   if($null -ne $cmd.delay_seconds){$delay=[int]$cmd.delay_seconds}
   if($delay -notin @(0,30,90,300)){throw 'Unrecognized power delay'}
   if($kind -eq 'shutdown_pc'){$flag='/s'}else{$flag='/r'}
   $exe=Join-Path $env:SystemRoot 'System32\shutdown.exe'
   $args=$flag+' /t '+$delay+' /f /c "RKA authorized remote request - save your work"'
   $p=Start-Process -FilePath $exe -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
   if($p.ExitCode -ne 0){throw 'Windows refused the requested power action'}
   return @{ok=$true;result=@{scheduled_for=[DateTime]::UtcNow.AddSeconds($delay).ToString('yyyy-MM-ddTHH:mm:ss.fffZ');action=$kind;state='scheduled'}}
  }
  'apply_guest_policy' {
   $profile=Verify-Target $sid $profilePath
   if(@(Get-ChildItem (Join-Path $root 'ItemRecovery') -Filter '*.json' -ErrorAction SilentlyContinue).Count -gt 0){throw 'Individual snapshots exist; finish individual recovery before full-policy replacement'}
   $pointer=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery\current.json'
   if(Test-Path -LiteralPath $pointer){throw 'A prior full policy snapshot exists; restore it locally before reapplying'}
   Worker 'Persistent' $sid $profilePath
   return @{ok=$true;result=@{guest=$profile.account;policy='applied';enforcement='not_verified'}}
  }
  'restore_guest_policy' {
   [void](Require-Guest $sid)
   $pointer=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery\current.json'
   if(-not(Test-Path -LiteralPath $pointer)){throw 'No active full-policy snapshot'}
   $ptr=Get-Content -LiteralPath $pointer -Raw -Encoding UTF8|ConvertFrom-Json
   $snapshot=Get-Content -LiteralPath ([string]$ptr.path) -Raw -Encoding UTF8|ConvertFrom-Json
   if([string]$snapshot.sid -cne $sid){throw 'Full-policy backup SID mismatch'}
   Worker 'Restore' '' ''
   return @{ok=$true;result=@{policy='restored';enforcement='not_verified'}}
  }
  'set_guest_restriction' {
   if($null -eq $cmd.enabled -or ([string]$cmd.restriction) -notin @('chrome_web','edge_web','control_panel','regedit','command_prompt','task_manager')){throw 'Invalid typed restriction'}
   $r=Set-GuestRestriction $sid ([string]$cmd.restriction) ([bool]$cmd.enabled)
   return @{ok=$true;result=$r}
  }
  'set_browser_allowlist' {
   if($null -eq $cmd.allowlist -or $cmd.allowlist.preserve_intranet -ne $true){throw 'Intranet preservation is mandatory'}
   $hosts=@($cmd.allowlist.hosts|ForEach-Object {[string]$_})
   $r=Set-BrowserAllowlist $sid ([string]$cmd.allowlist.mode) $hosts
   return @{ok=$true;result=$r}
  }
  'set_chrome_autolaunch' {
   if($null -eq $cmd.enabled){throw 'Missing typed Chrome auto-launch value'}
   $r=Set-ChromeAutolaunch $sid ([bool]$cmd.enabled)
   return @{ok=$true;result=$r}
  }
  'set_usb_storage' {
   if(-not [bool]$conf.allowUsb){throw 'System-wide USB storage remote control not locally authorized'}
   if([string]$cmd.restriction -cne 'usb_storage' -or $null -eq $cmd.enabled){throw 'Invalid typed USB request'}
   if([bool]$cmd.enabled){Run-LocalScript 'USB-Storage.ps1' @('-Action','Enable')}
   else{Run-LocalScript 'USB-Storage.ps1' @('-Action','Restore')}
   return @{ok=$true;result=@{usb_storage=$(if($cmd.enabled){'block_requested'}else{'restore_requested'});scope='system';enforcement='not_verified'}}
  }
  'send_announcement' {
   # Announcements have no target SID. Only dispatch when exactly one standard guest is configured.
   $guests=@(StandardAccounts)
   if($guests.Count -ne 1){throw 'A single standard guest account is required for announcement delivery'}
   $r=Announce-Guest ([string]$guests[0].sid) ([string]$cmd.message) ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'reset_session' {
   # Same as RKA Client's walk-away reset: games close, the customer is signed out, settings go back.
   $r=Reset-ClientSession ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'set_staff_mode' {
   # Unlocks or locks RKA Client's staff mode; staff mode locks itself after 5 idle minutes.
   if($null -eq $cmd.enabled){throw 'Missing typed staff mode value'}
   $r=Set-ClientStaffMode ([bool]$cmd.enabled) ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'set_lan_firewall' {
   if($null -eq $cmd.enabled){throw 'Missing typed LAN play value'}
   Run-LocalScript 'LAN-Firewall.ps1' @('-Action',$(if([bool]$cmd.enabled){'Enable'}else{'Disable'}))
   return @{ok=$true;result=@{lan_play=$(if($cmd.enabled){'on'}else{'off'});scope='system';enforcement='not_verified'}}
  }
  'apply_wallpaper' {
   [void](Require-Guest $sid)
   $image=Acquire-Wallpaper $cmd ([string]$conf.deviceName)
   $r=Apply-GuestWallpaper $sid $image ([string]$cmd.id)
   return @{ok=$true;result=$r}
  }
  'restore_wallpaper' {
   $r=Restore-GuestWallpaper $sid
   return @{ok=$true;result=$r}
  }
  default {throw 'Unsupported typed remote action refused'}
 }
}
function Check-Expired($cmd){
 $expiry=[datetimeoffset]::MinValue
 if(-not [datetimeoffset]::TryParse([string]$cmd.expires_at,[ref]$expiry)){return $true}
 return ([datetimeoffset]::UtcNow -ge $expiry)
}
function Poll-Once($conf){
 $legacy=Lovable-Legacy
 $body=@{action='poll';device_id=[string]$conf.deviceName;agent_version=$agentVersion;capabilities=@(Get-Capabilities $conf $legacy)}
 $call=$null
 if(-not $legacy){
  $client=Get-ClientReport;if($client){$body.client=$client}
  if('staff_call' -in @(Lovable-Features)){$call=Get-StaffCall;if($call){$body.staff_call=$call}}
 }
 try{$reply=Post-Server $body}
 catch{
  if($legacy -or -not(Is-BadRequest $_)){throw}
  # This Lovable doesn't know the 1.1 fields yet. Use the 1.0 poll and try again in an hour.
  @{since=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $legacyMark -Encoding UTF8
  Write-Safe 'Lovable refused the 1.1 poll; using the 1.0 poll for an hour.'
  $legacy=$true
  $reply=Post-Server @{action='poll';device_id=[string]$conf.deviceName;agent_version=$agentVersion;capabilities=@(Get-Capabilities $conf $true)}
 }
 if($reply.ok -ne $true){throw 'Server did not accept device command poll.'}
 if($call -and $body.ContainsKey('staff_call')){Set-Content -LiteralPath $staffCallSent -Value $call.id -Encoding ASCII;Write-Safe 'Staff call sent to Lovable.'}
 try{Save-LovableFeatures @($reply.features|Where-Object {$_ -is [string] -and $_ -cmatch '^[a-z_]{1,32}$'}|Select-Object -First 16)}catch{Write-Safe 'Could not save Lovable features.'}
 # Only a successful authenticated response qualifies this installed agent as healthy.
 # The heartbeat reads this protected status, NOT an installer-controlled version marker.
 $health=@{version=$agentVersion;confirmedUtc=[DateTime]::UtcNow.ToString('o');capabilities=@(Get-Capabilities $conf $legacy);lovable11=(-not $legacy)}
 $healthTmp=Join-Path $root ('agent-health-'+[guid]::NewGuid().ToString('N')+'.tmp')
 $healthDest=Join-Path $root 'agent-health.json'
 try{
  $health|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $healthTmp -Encoding UTF8 -NoNewline
  Move-Item -LiteralPath $healthTmp -Destination $healthDest -Force
 }finally{if(Test-Path -LiteralPath $healthTmp){Remove-Item -LiteralPath $healthTmp -Force -ErrorAction SilentlyContinue}}
 $cmd=$reply.command
 if($null -eq $cmd){return}
 if([string]$cmd.id -notmatch '^[0-9a-fA-F-]{36}$' -or [string]$cmd.nonce -notmatch '^[A-Za-z0-9_-]{32,64}$'){throw 'Invalid typed command envelope.'}
 $id=[string]$cmd.id
 $marker=Join-Path $processed ($id+'.json')
 if(Test-Path -LiteralPath $marker){
  # Never rerun a possibly destructive command following process crash or lost ack.
  $previous=Get-Content -LiteralPath $marker -Raw -Encoding UTF8|ConvertFrom-Json
  if($previous.status -eq 'complete'){
   try{[void](Post-Server @{action='ack';device_id=[string]$conf.deviceName;command_id=$id;nonce=[string]$cmd.nonce;status=[string]$previous.ackStatus;result=$previous.result;error=[string]$previous.error})}catch{}
  }else{
   try{[void](Post-Server @{action='ack';device_id=[string]$conf.deviceName;command_id=$id;nonce=[string]$cmd.nonce;status='failed';error='An earlier agent run was interrupted; command was not repeated.'})}catch{}
  }
  return
 }
 $mark=@{id=$id;status='started';startedAt=(Get-Date -Format 'o')}
 $mark|ConvertTo-Json|Set-Content -LiteralPath $marker -Encoding UTF8
 $status='failed';$result=@{};$problem=''
 try{
  if(Check-Expired $cmd){throw 'Command expired before local execution.'}
  $executed=Execute-Typed $cmd $conf
  if($executed.ok -ne $true){throw 'Operation failed'}
  $status='succeeded';$result=$executed.result
 }catch{$problem=($_.Exception.Message -replace '[\r\n]+',' ');if($problem.Length -gt 250){$problem=$problem.Substring(0,250)}}
 $mark.status='complete';$mark.ackStatus=$status;$mark.kind=[string]$cmd.kind;$mark.result=$result;$mark.error=$problem;$mark.finishedAt=(Get-Date -Format 'o')
 $mark|ConvertTo-Json|Set-Content -LiteralPath $marker -Encoding UTF8
 $body=@{action='ack';device_id=[string]$conf.deviceName;command_id=$id;nonce=[string]$cmd.nonce;status=$status;result=$result}
 if($status -eq 'failed'){$body.error=$problem}
 try{[void](Post-Server $body);Write-Safe ('Command '+[string]$cmd.kind+' settled '+$status+' id='+$id)}catch{Write-Safe ('Command acknowledgement unavailable for '+$id+'. Local execution not repeated.')}
}
function Register-Guests($conf){
 $accounts=@(StandardAccounts)
 $hash=(@($accounts|Sort-Object sid|ForEach-Object {$_.sid+':'+$_.account_name})-join '|')
 $cache=Join-Path $root 'guests-cache.json'
 $need=$true
 if(Test-Path -LiteralPath $cache){try{$old=Get-Content -LiteralPath $cache -Raw|ConvertFrom-Json;$need=($old.hash -cne $hash -or ([datetime]::UtcNow-[datetime]$old.lastSent).TotalMinutes -ge 30)}catch{}}
 if($need){
  $resp=Post-Server @{action='register_guests';device_id=[string]$conf.deviceName;guests=$accounts}
  if($resp.ok -ne $true){throw 'Guest account inventory not accepted.'}
  @{hash=$hash;lastSent=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $cache -Encoding UTF8
 }
}
try{
 $created=$false;$mutex=[System.Threading.Mutex]::new($true,'Global\RKA_Lovable_Remote_Agent_v1',[ref]$created)
 if(-not $created){exit 0};$mutexHeld=$true
 Add-Type -AssemblyName System.Security -ErrorAction Stop
 if(-not(Test-Path -LiteralPath $configPath)){throw 'Remote-control setup not installed.'}
 $conf=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8|ConvertFrom-Json
 $hb=Get-Content -LiteralPath $heartbeatPath -Raw -Encoding UTF8|ConvertFrom-Json
 if([string]$conf.deviceName -cne [string]$hb.deviceName -or [string]$conf.deviceName -cnotmatch '^[A-Z0-9-]{3,40}$'){throw 'Device enrollment changed; remote agent will not poll.'}
 if([string]$hb.endpoint -ne 'https://zallpwnkizoxxxkufbfq.supabase.co/functions/v1/rka-pc-heartbeat'){throw 'Unexpected heartbeat enrollment endpoint.'}
 $bytes=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String([string]$hb.tokenEncrypted),$null,[Security.Cryptography.DataProtectionScope]::LocalMachine)
 $secret=[Text.Encoding]::UTF8.GetString($bytes)
 if($secret -cnotmatch '^rka_pc_[A-Za-z0-9_-]{43}$'){throw 'Invalid enrollment token format.'}
 if(-not(Test-Path -LiteralPath $processed)){[void](New-Item -ItemType Directory -Path $processed -Force)}
 try{Register-Guests $conf}catch{Write-Safe 'Guest registration failed; protected agent will retry.'}
 try{
  $guestAccounts=@(StandardAccounts)
  if($guestAccounts.Count -eq 1){
   $items=@(Get-PolicyInventory ([string]$guestAccounts[0].sid))
   [void](Post-Server @{action='policy_status';device_id=[string]$conf.deviceName;agent_version=$agentVersion;observed_at=[DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ss.fffZ');target_sid=[string]$guestAccounts[0].sid;auto_logon_enabled=$null;items=$items})
  }
 }catch{Write-Safe 'Policy inventory could not be read or submitted; server status remains unknown.'}

 # Poll three times per minute. Service token never appears in logs or responses.
 for($attempt=0;$attempt -lt 3;$attempt++){
  try{Poll-Once $conf}catch{Write-Safe 'Remote poll could not complete; retry on next scheduled run.'}
  if($attempt -lt 2){Start-Sleep -Seconds 17}
 }
}catch{Write-Safe ('Agent stopped: '+($_.Exception.Message -replace 'rka_pc_[A-Za-z0-9_-]+','[REDACTED]'));exit 1}
finally{
 if($null -ne $bytes){[Array]::Clear($bytes,0,$bytes.Length)}
 $secret=$null
 if($mutexHeld -and $mutex){try{$mutex.ReleaseMutex()}catch{}}
 if($mutex){$mutex.Dispose()}
}
