# Creates a branded desktop shortcut for the current Windows user.
$ErrorActionPreference='Stop'
$appRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$target=Join-Path $env:SystemRoot 'System32\wscript.exe'
$scriptPath=Join-Path $appRoot 'Launch-RKA-WPF.vbs'
$icon=Join-Path $appRoot 'assets\rka.ico'
$desktop=[Environment]::GetFolderPath('Desktop')
$shell=New-Object -ComObject WScript.Shell
$lnk=$shell.CreateShortcut((Join-Path $desktop 'Retro Knights PC Control Center.lnk'))
$lnk.TargetPath=$target
$lnk.Arguments='"'+$scriptPath+'"'
$lnk.WorkingDirectory=$appRoot
$lnk.IconLocation=$icon+',0'
$lnk.Description='RKA PC Control Center - administrator-only app launcher'
$lnk.Save()
Write-Host "Desktop shortcut created: $desktop" -ForegroundColor Cyan
