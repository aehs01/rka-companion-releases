# RKA Windows Companion - modern WPF (.NET Framework / PresentationFramework) preview.
# Windows PowerShell 5.1, Windows 10/11; uses existing audited local scripts.
#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$script:AppVersion = '1.5.0'
$script:UpdateAvailableVersion = $null
$script:AppRoot = $PSScriptRoot
$script:DataRoot = Join-Path $env:LOCALAPPDATA 'RKA-Lockdown-Agent'
$script:ProfileFile = Join-Path $script:DataRoot 'profile.json'
$script:LogFile = Join-Path $script:DataRoot 'wpf-ui.log'
$script:RecoveryRoot = Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Recovery'
$script:ChromeStatusFile = Join-Path $env:ProgramData 'RKA-Lockdown-Agent\chrome-setup-last-result.txt'
$script:HeartbeatStatusFile = Join-Path $script:DataRoot 'heartbeat-ui-status.txt'
$script:PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$script:AllowExit = $false
$script:SavedProfile = $null
$script:GuestAccounts = @()
$script:ApprovedUrls = @()
# Canonical first-run defaults. These are shown in the editor but do not change Windows until Apply Restrictions.
# Keep the five originally tested local LAN/Discord dependencies together in one place.
$script:DefaultApprovedUrls = @('http://rkaserver/','https://discord.com/','https://discord.gg/','https://cdn.discordapp.com/','https://media.discordapp.net/')
$script:TrayIcon = $null
$script:ClientIsShell = $false
$script:LanReport = ''
$script:Mutex = $null
$script:MutexAcquired = $false
# Block, Allow and the status column use the same item list as the worker and the agent.
. (Join-Path $PSScriptRoot 'Lockdown-Items.ps1')
# Each lockdown item's status text and its Block and Allow buttons.
$script:ItemRows=[ordered]@{
 settings=@('StatusSettings','BlockSettings','AllowSettings')
 cmd=@('StatusCmd','BlockCmd','AllowCmd')
 registry=@('StatusRegistry','BlockRegistry','AllowRegistry')
 taskmgr=@('StatusTaskMgr','BlockTaskMgr','AllowTaskMgr')
 password=@('StatusPassword','BlockPassword','AllowPassword')
 lock=@('StatusLock','BlockLock','AllowLock')
 popups=@('StatusPopups','BlockPopups','AllowPopups')
 usb=@('StatusUsbGuest','BlockUsbGuest','AllowUsbGuest')
 browser=@('StatusEdge','BlockEdge','AllowEdge')
}
$script:ItemStates=@{}
$script:KitRoot = Join-Path $env:ProgramFiles 'Retro Knights Arcade'
$script:LastCheckFile = Join-Path $env:ProgramData 'RKA-Client\updates\last-check.json'
$script:UpdateTimer = $null

function Write-RkaLog([string]$message) {
 try {
  if(-not(Test-Path -LiteralPath $script:DataRoot)){New-Item -Path $script:DataRoot -ItemType Directory -Force|Out-Null}
  Add-Content -LiteralPath $script:LogFile -Value ('{0:o} {1}' -f (Get-Date),$message) -Encoding UTF8
 } catch {}
}
function Show-Notice([string]$message, [string]$title = 'RKA Windows Companion') {
 [System.Windows.MessageBox]::Show($script:Window,$message,$title,[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Information)|Out-Null
}
function Show-Failure([string]$message, [string]$title = 'Operation failed') {
 Write-RkaLog "FAIL: $message"
 [System.Windows.MessageBox]::Show($script:Window,$message,$title,[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Error)|Out-Null
}
function Ask-YesNo([string]$message,[string]$title='Confirm action') {
 return ([System.Windows.MessageBox]::Show($script:Window,$message,$title,[System.Windows.MessageBoxButton]::YesNo,[System.Windows.MessageBoxImage]::Warning) -eq [System.Windows.MessageBoxResult]::Yes)
}
function Set-Footer([string]$message,[bool]$error=$false) {
 $script:Ui.FooterStatus.Text = $(if($error){'ERROR: '}else{'STATUS: '})+$message
 $script:Ui.FooterStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($error){'#FF768A'}else{'#8AE5FF'}))
 $script:Ui.LatestActionLabel.Text = $message
}
function Assert-Admin {
 $principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'RKA Companion is for staff.'}
}
function Check-Url([string]$value) {
 $uri=$null
 return (($value.Length -le 500) -and ($value -notmatch '[*\s#"<>]') -and [Uri]::TryCreate($value,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -in @('http','https') -and -not $uri.UserInfo)
}
# Chrome Startup > Portal URL is the shared live destination for all guest portal shortcuts.
# Never use a retired hardcoded hostname or silently change the saved browser allowlist.
function Get-CurrentPortalUrl {
 $url=[string]$script:Ui.ChromeUrl.Text.Trim()
 if(-not(Check-Url $url)){throw 'Set a valid Portal URL under Chrome Startup before deploying an intranet shortcut.'}
 return $url
}
function Sync-PortalUrl([string]$source) {
 if($script:PortalUrlSyncing){return}
 try{
  $script:PortalUrlSyncing=$true
  if($source -eq 'Chrome'){
   $url=[string]$script:Ui.ChromeUrl.Text
   if($script:Ui.GamePortalUrl.Text -cne $url){$script:Ui.GamePortalUrl.Text=$url}
  }else{
   $url=[string]$script:Ui.GamePortalUrl.Text
   if($script:Ui.ChromeUrl.Text -cne $url){$script:Ui.ChromeUrl.Text=$url}
  }
 }finally{$script:PortalUrlSyncing=$false}
}
function Read-Profile {
 $default=[pscustomobject]@{account='';intranet='http://rkaserver/';urls=@($script:DefaultApprovedUrls);blockSettings=$false;blockCmd=$false;blockRegistry=$false;blockTaskManager=$false;blockPassword=$false;blockLock=$false;blockPopups=$false;blockUsb=$false;restrictEdge=$false;networkBrowse=$false;hideThisPc=$false}
 if(Test-Path -LiteralPath $script:ProfileFile){
  try {
   $p=Get-Content -LiteralPath $script:ProfileFile -Raw -Encoding UTF8|ConvertFrom-Json
   foreach($prop in $default.PSObject.Properties){if(-not $p.PSObject.Properties[$prop.Name]){$p|Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value}}
   # Migrate ONLY the obsolete test hostname; preserve all other user-entered addresses.
   if([string]$p.intranet -match '^https?://tyrant/?$'){$p.intranet='http://rkaserver/'}
   $loadedUrls=@($p.urls | Where-Object {-not [string]::IsNullOrWhiteSpace([string]$_)} | ForEach-Object {if(([string]$_) -match '^https?://tyrant/?$'){'http://rkaserver/'}else{[string]$_}} | Select-Object -Unique)
   # A legacy/partially initialized profile may contain urls: [] even though the packaged
   # defaults are present. Repair ONLY an empty list; keep nonempty custom lists intact.
   if($loadedUrls.Count -eq 0){
    $loadedUrls=@($script:DefaultApprovedUrls)
    Write-RkaLog 'Missing/empty approved-websites profile: recommended RKA defaults loaded in memory; Windows policy unchanged.'
   }
   # Keep the chosen intranet (including a customized hostname) visible in the editor.
   # Never restore the retired Tyrant name or overwrite other custom websites.
   if((Check-Url ([string]$p.intranet)) -and $loadedUrls -notcontains [string]$p.intranet){$loadedUrls=@([string]$p.intranet)+$loadedUrls}
   $p.urls=@($loadedUrls | Select-Object -Unique)
   # v1.0.2: import the approved host list last verified and changed remotely.
   # This changes only the in-memory editor view until the administrator saves;
   # no user profile files or registry rules are silently overwritten.
   $remoteSites=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl\approved-websites-state.json'
   if((Test-Path -LiteralPath $remoteSites) -and -not [string]::IsNullOrWhiteSpace([string]$p.account)){
    try{
     $rs=Get-Content -LiteralPath $remoteSites -Raw -Encoding UTF8|ConvertFrom-Json
     $matching=@(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop|Where-Object {$_.Name -ceq [string]$p.account -and $_.SID -ceq [string]$rs.sid})
     if($matching.Count -eq 1 -and [int]$rs.schema -eq 1 -and $rs.source -eq 'authenticated_remote_command'){
      $sites=@(([string]$p.intranet))
      foreach($hostName in @($rs.hosts)){
       $hostName=[string]$hostName
       if($hostName -match '^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'){$sites+=('https://'+$hostName+'/')}
      }
      $p.urls=@($sites|Select-Object -Unique)
      Write-RkaLog 'Loaded remote-approved website snapshot into editor; Save Profile Only persists to this administrator profile. Actual policy was not changed.'
     }
    }catch{Write-RkaLog 'Remote website projection unavailable or invalid; preserving local saved list.'}
   }
   return $p
  }catch{Write-RkaLog "Profile load failed: $($_.Exception.Message)"}
 }
 return $default
}
function Find-GuestAccounts {
 $script:GuestAccounts=@()
 $script:Ui.NoGuestMessage.Text=''
 try {
  $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
  $currentSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  foreach($a in @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop)) {
   if($a.Disabled -or $a.Lockout -or $a.SID -match '-(500|501|503|504)$' -or $admins -contains $a.SID -or $a.SID -eq $currentSid){continue}
   $script:GuestAccounts+= [pscustomobject]@{Name=[string]$a.Name;SID=[string]$a.SID;Label=([string]$a.Name+' - Standard user')}
  }
 }catch{Write-RkaLog "Account discovery failed: $($_.Exception.Message)"}
 $script:Ui.GuestSelector.ItemsSource = $script:GuestAccounts
 if($script:GuestAccounts.Count -eq 0){
  $script:Ui.NoGuestMessage.Text='No standard guest account found. Create a local standard account and sign into it once.'
  $script:Ui.GuestSelector.IsEnabled=$false
  $names=@('VerifyPolicyButton','UnlockAllButton','ClientShellOnButton','ClientShellOffButton','ChromeInstall','DeployIntranetButton','SaveDesktopBackupButton','RestoreDesktopBackupButton')
  foreach($row in $script:ItemRows.Values){$names+=$row[1];$names+=$row[2]}
  foreach($name in $names){if($script:Ui.ContainsKey($name)){$script:Ui[$name].IsEnabled=$false}}
 } else {$script:Ui.GuestSelector.IsEnabled=$true}
 $preferred=[string]$script:SavedProfile.account
 $index=-1
 for($i=0;$i -lt $script:GuestAccounts.Count;$i++){if($script:GuestAccounts[$i].Name -ieq $preferred){$index=$i;break}}
 if($index -lt 0 -and $script:GuestAccounts.Count -eq 1){$index=0}
 if($index -ge 0){$script:Ui.GuestSelector.SelectedIndex=$index}
}
function Selected-Guest {
 $guest=$script:Ui.GuestSelector.SelectedItem
 if(-not $guest -or -not $guest.SID){throw 'Select a verified standard guest account. Check the account under Windows Settings and restart this window if it is missing.'}
 # Reconfirm account is not in Administrators at the moment of every privileged action.
 $admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | Where-Object {$_.SID} | ForEach-Object {$_.SID.Value})
 if($admins -contains $guest.SID){throw 'Cannot use an administrator as a guest. Operation canceled.'}
 if($guest.SID -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Cannot target the current admin account.'}
 return $guest
}
function Profile-From-UI {
 $g=Selected-Guest
 $url=Get-CurrentPortalUrl
 if(-not(Check-Url $url)){throw 'Please enter a valid http(s) LAN intranet URL with no wildcard, spaces or embedded credentials.'}
 $urls=@($script:ApprovedUrls | Where-Object {$_ -and (Check-Url ([string]$_))})
 if($urls -notcontains $url){$urls=@($url)+$urls}
 # The saved choices follow what the guest has now (1.2: Block and Allow act straight away).
 $p=[ordered]@{version=$script:AppVersion;account=$g.Name;intranet=$url;urls=$urls}
 foreach($e in $script:RkaProfileFlags.GetEnumerator()){$p[$e.Value]=([string]$script:ItemStates[$e.Key] -eq 'Blocked')}
 $p.networkBrowse=$false;$p.hideThisPc=$false
 return $p
}
function Edit-ApprovedSites {
 try {
  $dialog=New-Object System.Windows.Window
  $dialog.Title='Guest browser approved websites'
  $dialog.Width=670; $dialog.Height=480
  $dialog.MinWidth=530; $dialog.MinHeight=360
  $dialog.WindowStartupLocation='CenterOwner';$dialog.Owner=$script:Window
  $dialog.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0B1C2B')
  $dialog.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#E8F4FF')
  $dialog.FontFamily='Segoe UI'
  $grid=New-Object System.Windows.Controls.Grid
  $grid.Margin='20'
  $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))
  $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=([System.Windows.GridLength]::new(1,[System.Windows.GridUnitType]::Star))}))
  $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))
  $desc=New-Object System.Windows.Controls.TextBlock
  $desc.Text='One website per line, starting with http:// or https://. The intranet and Discord are the RKA defaults.'+"`r`n`r`nAlways allowed, not listed here: "+((Get-AlwaysAllowedSites) -join ', ')
  $desc.TextWrapping='Wrap';$desc.Margin='0,0,0,12'
  [System.Windows.Controls.Grid]::SetRow($desc,0);[void]$grid.Children.Add($desc)
  $urlBox=New-Object System.Windows.Controls.TextBox
  $urlBox.Text=@($script:ApprovedUrls) -join "`r`n"
  $urlBox.AcceptsReturn=$true;$urlBox.VerticalScrollBarVisibility='Auto';$urlBox.FontFamily='Consolas';$urlBox.FontSize=15
  $urlBox.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#102D41')
  $urlBox.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#F5FBFF')
  $urlBox.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#2184A6')
  [System.Windows.Controls.Grid]::SetRow($urlBox,1);[void]$grid.Children.Add($urlBox)
  $panel=New-Object System.Windows.Controls.StackPanel
  $panel.Orientation='Horizontal';$panel.HorizontalAlignment='Right';$panel.Margin='0,14,0,0'
  # Explicit opt-in for existing profiles with a nonempty custom list: merge missing RKA
  # defaults without deleting any entries. The editor still requires Save before applying.
  $defaultsButton=New-Object System.Windows.Controls.Button
  $defaultsButton.Content='Add RKA defaults';$defaultsButton.Padding='10,9';$defaultsButton.Margin='0,0,10,0'
  $defaultsButton.Add_Click({
   $entries=@($urlBox.Text -split '\r?\n' | ForEach-Object {$_.Trim()} | Where-Object {$_})
   foreach($defaultUrl in $script:DefaultApprovedUrls){if($entries -notcontains $defaultUrl){$entries+= $defaultUrl}}
   $urlBox.Text=(@($entries|Select-Object -Unique) -join "`r`n")
  })
  $save=New-Object System.Windows.Controls.Button
  $save.Content='Save website list';$save.Padding='10,9';$save.Margin='0,0,10,0'
  $cancel=New-Object System.Windows.Controls.Button
  $cancel.Content='Cancel';$cancel.Padding='14,9'
  $save.Add_Click({
   try{
    $raw=@($urlBox.Text -split '\r?\n' | ForEach-Object {$_.Trim()} | Where-Object {$_})
    if($raw.Count -gt 20){throw 'Limit the browser allowlist to 20 specific websites.'}
    foreach($u in $raw){if(-not(Check-Url ([string]$u))){throw "Invalid approved website: $u"}}
    if([string]$script:ItemStates.browser -eq 'Blocked' -and $raw.Count -eq 0){throw 'Chrome and Edge are blocked, so keep at least one approved website.'}
    $script:ApprovedUrls=@($raw|Select-Object -Unique)
    $dialog.DialogResult=$true
   }catch{[System.Windows.MessageBox]::Show($dialog,$_.Exception.Message,'Approved websites',[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Warning)|Out-Null}
  })
  $cancel.Add_Click({$dialog.DialogResult=$false})
  [void]$panel.Children.Add($defaultsButton);[void]$panel.Children.Add($save);[void]$panel.Children.Add($cancel)
  [System.Windows.Controls.Grid]::SetRow($panel,2);[void]$grid.Children.Add($panel)
  $dialog.Content=$grid
  if($dialog.ShowDialog() -eq $true){
   Save-Profile $false
   # Already blocked: write the new lists to the guest now.
   if([string]$script:ItemStates.browser -eq 'Blocked'){Invoke-LockItem 'browser' $true}
   else{Set-Footer ('Approved websites saved ('+$script:ApprovedUrls.Count+'). They apply when you Block Chrome and Edge.')}
  }
 }catch{Show-Failure $_.Exception.Message 'Website editor failed'}
}
function Save-Profile([bool]$notify=$false) {
 $p=Profile-From-UI
 $p | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
 $script:SavedProfile=Get-Content -LiteralPath $script:ProfileFile -Raw -Encoding UTF8|ConvertFrom-Json
 if($notify){Show-Notice 'Choices saved.' 'Choices saved'}
}
# The sites the worker always allows, read from PolicyWorker.ps1 so the list is never out of date.
function Get-AlwaysAllowedSites {
 try{
  $line=Select-String -LiteralPath (Join-Path $script:AppRoot 'PolicyWorker.ps1') -Pattern '^\$GameSignInSites=@\((.*)\)$'|Select-Object -First 1
  return @([regex]::Matches($line.Matches[0].Groups[1].Value,"'([^']+)'")|ForEach-Object {$_.Groups[1].Value})
 }catch{return @('sign-in, email-code and captcha sites')}
}
function Start-RkaWorker([string]$scriptName,[string]$arguments='',[bool]$elevate=$true) {
 $path=Join-Path $script:AppRoot $scriptName
 if(-not(Test-Path -LiteralPath $path)){throw "Missing $scriptName. Reinstall RKA Client & Companion."}
 # The window already runs elevated, so workers run hidden as its children and
 # their output can be shown. Only fixed, shipped script names are run.
 $out=Join-Path $env:TEMP ('rka-worker-'+[guid]::NewGuid().ToString('N')+'.txt')
 $cmd='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$path+'" '+$arguments
 try{
  $p=Start-Process -FilePath $script:PowerShellExe -ArgumentList $cmd -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput $out -ErrorAction Stop
  $text=[string](Get-Content -LiteralPath $out -Raw -ErrorAction SilentlyContinue)
 }finally{Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue}
 Write-RkaLog ('Worker: '+$scriptName+' '+$arguments+' exit='+$p.ExitCode)
 if($p.ExitCode -ne 0){
  $why=@(($text -split "`r?`n")|Where-Object {$_ -like 'ERROR:*'}|Select-Object -First 1)
  throw $(if($why.Count){$why[0].Substring(6).Trim()}else{"$scriptName didn't finish (exit $($p.ExitCode)). Its log is in ProgramData\RKA-Lockdown-Agent."})
 }
 return $text
}
function Read-RkaLog([string]$path, [int]$tail=80) {
 if(-not(Test-Path -LiteralPath $path)){return 'No log file found at '+$path}
 return (@(Get-Content -LiteralPath $path -Tail $tail -ErrorAction Stop)-join "`r`n")
}
function Get-GuestLockdownState([string]$sid) {
 # Read-only. Mounts the guest's registry only when Windows has it unloaded.
 $base=[Microsoft.Win32.Registry]::Users
 $root=$base.OpenSubKey($sid,$false)
 $mountId=''
 if(-not $root){
  $wp=Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop | Select-Object -First 1
  if(-not $wp -or -not $wp.LocalPath){throw 'Guest has no local Windows profile yet; sign into it once.'}
  $dat=Join-Path $wp.LocalPath 'NTUSER.DAT'
  if(-not(Test-Path -LiteralPath $dat)){throw 'NTUSER.DAT missing for guest profile.'}
  $mountId='RKA_WPF_READ_'+[Guid]::NewGuid().ToString('N')
  & reg.exe load "HKU\$mountId" $dat | Out-Null
  if($LASTEXITCODE -ne 0){throw 'Could not read the guest registry; sign the guest out first.'}
  $root=$base.OpenSubKey($mountId,$false)
  if(-not $root){& reg.exe unload "HKU\$mountId" | Out-Null;throw 'Guest registry mounted but could not be opened.'}
 }
 try{
  $result=@{}
  foreach($item in $script:RkaGuestItems.Keys){$result[$item]=Get-RkaItemState $root $item}
  $result.Shell=[string](Read-RkaValue $root 'Software\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Shell')
  foreach($b in @(@('ChromeAllowCount','Software\Policies\Google\Chrome\URLAllowlist'),@('EdgeAllowCount','Software\Policies\Microsoft\Edge\URLAllowlist'))){
   $k=$root.OpenSubKey($b[1],$false)
   try{$result[$b[0]]=$(if($k){@($k.GetValueNames()).Count}else{0})}finally{if($k){$k.Dispose()}}
  }
  return $result
 }finally{
  if($root){$root.Dispose()}
  if($mountId){
   [GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 150
   & reg.exe unload "HKU\$mountId" |Out-Null
   if($LASTEXITCODE -ne 0){Write-RkaLog "WARN: Unable to unmount read-only status hive $mountId"}
  }
 }
}
function Set-ItemStatus([string]$name,[string]$state,[string]$tip=''){
 $c=$script:Ui[$name]
 $c.Text=$state
 # Green: the lockdown is on. Red: open. Amber: partly, or unknown.
 $color=switch($state){'Blocked'{'#34E79B'}'On'{'#34E79B'}'After closing only'{'#34E79B'}'Allowed'{'#FF8A96'}'Off'{'#FF8A96'}'Windows default'{'#A0B3C4'}default{'#F7BF58'}}
 $c.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
 if($tip){$c.ToolTip=$tip}
}
function Refresh-PolicyStatuses {
 try{
  $g=Selected-Guest
  $values=Get-GuestLockdownState $g.SID
  foreach($item in $script:ItemRows.Keys){
   $script:ItemStates[$item]=[string]$values[$item]
   Set-ItemStatus $script:ItemRows[$item][0] ([string]$values[$item]) ("What Windows reports for $($g.Name).")
  }
  if($values.browser -eq 'Blocked' -and ($values.ChromeAllowCount -lt 1 -or $values.EdgeAllowCount -lt 1)){
   Set-ItemStatus 'StatusEdge' 'Approved list missing' 'Chrome or Edge is blocked without its approved websites. Click Block again to rewrite the lists.'
  }
  $script:ClientIsShell=([string]$values.Shell -match 'RkaClient\.exe')
  Set-ItemStatus 'ClientShellStatus' $(if($script:ClientIsShell){'On'}else{'Off'}) $(if($script:ClientIsShell){"RKA Client is $($g.Name)'s desktop."}else{"$($g.Name) gets the normal Windows desktop."})
  Update-ClientShellUi
  $script:Ui.PolicySummary.Text="Read from $($g.Name)'s settings. Blocked means Windows has the setting; it stops normal use, not every workaround."
 }catch{
  foreach($row in $script:ItemRows.Values){Set-ItemStatus $row[0] 'Unable to verify' $_.Exception.Message}
  $script:Ui.PolicySummary.Text=$(if($script:GuestAccounts.Count -eq 0){'No guest account found. Create a standard guest account first.'}else{'Cannot read guest registry: '+$_.Exception.Message})
  Write-RkaLog ('Registry status failure: '+$_.Exception.Message)
 }
 Update-WinUpdateStatus
 Refresh-Home
}
function Update-WinUpdateStatus {
 try{
  $policy='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
  $set=(Get-ItemProperty -LiteralPath $policy -Name SetActiveHours -ErrorAction SilentlyContinue).SetActiveHours
  $noReboot=(Get-ItemProperty -LiteralPath (Join-Path $policy 'AU') -Name NoAutoRebootWithLoggedOnUsers -ErrorAction SilentlyContinue).NoAutoRebootWithLoggedOnUsers
  Set-ItemStatus 'StatusWinUpdate' $(if($set -eq 1 -and $noReboot -eq 1){'After closing only'}else{'Windows default'})
 }catch{Set-ItemStatus 'StatusWinUpdate' 'Unable to verify'}
}
function Invoke-LockItem([string]$item,[bool]$block) {
 $label=$script:RkaGuestItems[$item].Label
 try{
  Assert-Admin
  $g=Selected-Guest
  $arguments='-Operation Set -Item '+$item+' -State '+$(if($block){'Block'}else{'Allow'})+' -TargetSid "'+$g.SID+'"'
  if($item -eq 'browser' -and $block){
   if(@($script:ApprovedUrls).Count -lt 1){throw 'Add at least one approved website first.'}
   Save-Profile $false
   $arguments+=' -ProfilePath "'+$script:ProfileFile+'"'
  }
  [void](Start-RkaWorker 'PolicyWorker.ps1' $arguments)
  Refresh-PolicyStatuses
  Save-Profile $false
  Set-Footer ($label+': '+$(if($block){'blocked'}else{'allowed'})+' for '+$g.Name+'. The guest sees it after signing out and back in.')
 }catch{Refresh-PolicyStatuses;Show-Failure $_.Exception.Message $label}
}
function Invoke-WindowsUpdate([bool]$block) {
 try{
  Assert-Admin
  [void](Start-RkaWorker 'PolicyWorker.ps1' ('-Operation WindowsUpdate -State '+$(if($block){'Block'}else{'Allow'})))
  Update-WinUpdateStatus
  Set-Footer $(if($block){'Windows Update now restarts only after closing time.'}else{'Windows Update is back to its default restarts.'})
 }catch{Update-WinUpdateStatus;Show-Failure $_.Exception.Message 'Windows Update restarts'}
}
function Invoke-UnlockAll {
 try{
  Assert-Admin
  $g=Selected-Guest
  $usbPc=((Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices' -Name Deny_All -ErrorAction SilentlyContinue).Deny_All -eq 1)
  $msg="Unlock everything for $($g.Name)?`n`nEvery lockdown on this page is removed, back to Windows' defaults, however it was locked before."+$(if($usbPc){"`n`nUSB storage for every account is allowed again too."}else{''})+"`n`nRKA Client stays the guest's desktop."
  if(-not(Ask-YesNo $msg 'Unlock everything')){return}
  [void](Start-RkaWorker 'PolicyWorker.ps1' ('-Operation UnlockAll -TargetSid "'+$g.SID+'"'))
  if($usbPc){
   try{[void](Start-RkaWorker 'USB-Storage.ps1' '-Action Restore')}
   catch{Remove-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices' -Name Deny_All -ErrorAction SilentlyContinue}
  }
  Refresh-All
  Save-Profile $false
  Set-Footer ('Unlocked everything for '+$g.Name+'. The guest sees it after signing out and back in.')
 }catch{Refresh-PolicyStatuses;Show-Failure $_.Exception.Message 'Unlock everything'}
}
# RKA Client at sign-in, using the installer's own scripts in Program Files\Retro Knights Arcade\Setup.
function Invoke-ClientShell([bool]$on) {
 try{
  Assert-Admin
  $g=Selected-Guest
  $setup=Join-Path $script:KitRoot 'Setup'
  $file=Join-Path $setup $(if($on){'Install-RkaClient.ps1'}else{'Remove-RkaClient.ps1'})
  if(-not(Test-Path -LiteralPath $file)){throw "RKA Client & Companion Setup hasn't been run on this PC, so RKA Client isn't installed. Run the Setup first."}
  if($on){
   if(-not(Test-Path -LiteralPath (Join-Path $env:ProgramData 'RKA-Client\admin-pin.json'))){
    if(Ask-YesNo 'Staff need an admin PIN to unlock RKA Client, and none is set on this PC yet. Open RKA Client Setup to set the PIN and turn RKA Client on there?' 'Set the admin PIN first'){
     Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList ('"'+(Join-Path $setup 'RKA Client Setup.vbs')+'"')
    }
    return
   }
   if(-not(Ask-YesNo "Make RKA Client the desktop for $($g.Name)?`n`nThe guest's current settings are saved first; Turn off puts them back." 'RKA Client at sign-in')){return}
   $out=& $script:PowerShellExe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $file -GuestName $g.Name 2>&1|Out-String
  }else{
   if(-not(Ask-YesNo "Give $($g.Name) the normal Windows desktop back?`n`nRKA Client stays installed and keeps updating." 'RKA Client at sign-in')){return}
   $out=& $script:PowerShellExe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $file 2>&1|Out-String
   $code=$LASTEXITCODE
   # Remove-RkaClient also removes the update task; put it back, so the PC keeps updating.
   $hive=Join-Path $setup 'RkaGuestHive.ps1'
   if($code -eq 0 -and (Test-Path -LiteralPath $hive)){& $script:PowerShellExe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command ". '$hive'; Register-RkaUpdater"|Out-Null}
   $global:LASTEXITCODE=$code
  }
  $code=$LASTEXITCODE
  Write-RkaLog ("RKA Client at sign-in $on for $($g.Name): exit $code")
  if($code -ne 0){throw ($out.Trim())}
  Refresh-PolicyStatuses
  Set-Footer $(if($on){"RKA Client is now $($g.Name)'s desktop. Sign the guest out and back in."}else{"$($g.Name) has the Windows desktop back. Sign the guest out and back in."})
 }catch{Show-Failure $_.Exception.Message 'RKA Client at sign-in'}
}
function Refresh-All {
 # Reading everything takes a few seconds; say so, so the window doesn't look frozen.
 $script:Window.Cursor=[System.Windows.Input.Cursors]::Wait
 $script:Ui.FooterStatus.Text='STATUS: Checking...'
 $script:Window.Dispatcher.Invoke([action]{},[System.Windows.Threading.DispatcherPriority]::Render)
 try{Refresh-PolicyStatuses;Update-UsbStatus;Update-LanStatus;Refresh-AgentIndicators;Refresh-Home;Refresh-UpdatesPage}
 finally{$script:Window.Cursor=$null}
 Set-Footer 'Status refreshed'
}
function Check-Heartbeat {
 try{
  Start-RkaWorker 'Heartbeat-Ui-Status.ps1' '' $true
  $detail=Read-RkaLog $script:HeartbeatStatusFile 100
  $script:Ui.ConnectionReport.Text=$detail
  $device='Device status: local report available'
  if($detail -match '(?m)^DEVICE:\s*(.+)$'){$device=$Matches[1].Trim()}
  $script:Ui.HeartbeatLabel.Text='Connected: '+$device
  $script:Ui.HeartbeatLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#7AE6FA')
  Set-Footer 'Local Lovable heartbeat inspected; check server-side Online in Partner Dashboard'
 }catch{$script:Ui.ConnectionReport.Text="Check failed: $($_.Exception.Message)";Show-Failure $_.Exception.Message 'Connection check failed'}
}
function Refresh-ChromeQuickStatus {
 try{
  $task=Get-ScheduledTask -TaskName 'RKA-Guest-Chrome-Portal' -ErrorAction SilentlyContinue
  $failure=$false
  if(Test-Path -LiteralPath $script:ChromeStatusFile){
   $msg=Read-RkaLog $script:ChromeStatusFile 30
   $failure=($msg -match '(?m)^Outcome:\s*ERROR')
  }
  if($failure){$script:Ui.ChromeQuickLabel.Text='Setup error - view log';$color='#FF7289'}
  elseif($task){$script:Ui.ChromeQuickLabel.Text='Task configured - '+$task.State;$color='#38E5A3'}
  else{$script:Ui.ChromeQuickLabel.Text='Not configured';$color='#A6B6C8'}
  $script:Ui.ChromeQuickLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
 }catch{$script:Ui.ChromeQuickLabel.Text='Status unavailable';Write-RkaLog $_.Exception.Message}
}
function Check-Chrome([string]$operation) {
 try{
  Assert-Admin
  $g=Selected-Guest
  $url=$script:Ui.ChromeUrl.Text.Trim()
  if($operation -eq 'Install'){
   if(-not(Check-Url $url)){throw 'Invalid portal URL. Must use http(s).'}
   $delay=0;if(-not[int]::TryParse($script:Ui.ChromeDelay.Text,[ref]$delay) -or $delay -lt 0 -or $delay -gt 120){throw 'Delay must be an integer from 0 to 120.'}
   $mode=([System.Windows.Controls.ComboBoxItem]$script:Ui.ChromeMode.SelectedItem).Content
   Start-RkaWorker 'Chrome-Portal-Setup.ps1' ('-Action Install -UserName "'+$g.Name+'" -Url "'+$url+'" -Mode '+$mode+' -Delay '+$delay)
  } else {Start-RkaWorker 'Chrome-Portal-Setup.ps1' ('-Action '+$operation)}
  $script:Ui.ChromeReport.Text=Read-RkaLog $script:ChromeStatusFile 100
  Refresh-ChromeQuickStatus
  Update-ClientShellUi
  Set-Footer ('Chrome '+$operation+' completed; guest sign-in test required')
 }catch{
  $script:Ui.ChromeReport.Text=Read-RkaLog $script:ChromeStatusFile 100
  Refresh-ChromeQuickStatus
  Set-Footer ('Chrome '+$operation+' failed: '+$_.Exception.Message) $true
  Show-Failure ($_.Exception.Message+"`n`n"+$script:Ui.ChromeReport.Text) 'Chrome Startup failed'
 }
}
function Run-Health {
 try{
  $target=Join-Path $script:AppRoot 'Run-Preflight.ps1'
  $reportDir=Join-Path $env:TEMP 'RKA-Companion';if(-not(Test-Path $reportDir)){New-Item $reportDir -ItemType Directory -Force|Out-Null}
  $file=Join-Path $reportDir 'health-latest.json'
  # Read-only diagnostic script, no UAC operation needed; capture stdout and stderr permanently.
  $e=Join-Path $reportDir 'health-last-error.txt'
  $p=Start-Process -FilePath $script:PowerShellExe -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$target+'"') -RedirectStandardOutput $file -RedirectStandardError $e -Wait -PassThru
  $script:Ui.HealthReport.Text=$(if(Test-Path $file){Get-Content -LiteralPath $file -Raw -Encoding UTF8}else{'No output generated.'})
  if($p.ExitCode -ne 0){$script:Ui.HealthReport.Text+="`r`nERROR:`r`n"+(Read-RkaLog $e 50);throw 'Diagnostic exited with code '+$p.ExitCode}
  Set-Footer 'Local system preflight completed'
 }catch{Show-Failure $_.Exception.Message 'Diagnostics failed'}
}
function Export-Profile {
 try{
  $dialog=New-Object Microsoft.Win32.SaveFileDialog
  $dialog.FileName='RKA-Guest-Profile.json';$dialog.Filter='JSON profile (*.json)|*.json';$dialog.OverwritePrompt=$true
  if($dialog.ShowDialog($script:Window) -ne $true){return}
  $p=Profile-From-UI
  $export=[ordered]@{schema='RKA-PROFILE-PORTABLE-v1';account=$p.account;intranet=$p.intranet;urls=$p.urls}
  foreach($flag in $script:RkaProfileFlags.Values){$export[$flag]=$p[$flag]}
  $export|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $dialog.FileName -Encoding UTF8
  Show-Notice "Exported this guest's lockdown choices, without Lovable credentials or Windows passwords.`n`n$($dialog.FileName)" 'Choices exported'
 }catch{Show-Failure $_.Exception.Message 'Export failed'}
}
function Import-Profile {
 try{
  Assert-Admin
  $g=Selected-Guest
  $dialog=New-Object Microsoft.Win32.OpenFileDialog;$dialog.Filter='JSON profile (*.json)|*.json'
  if($dialog.ShowDialog($script:Window) -ne $true){return}
  $p=Get-Content -LiteralPath $dialog.FileName -Raw -Encoding UTF8|ConvertFrom-Json
  if($p.schema -ne 'RKA-PROFILE-PORTABLE-v1'){throw 'Only files made with Export to a file can be imported.'}
  if(-not(Check-Url ([string]$p.intranet))){throw 'Invalid intranet URL in the imported file.'}
  $validUrls=@()
  foreach($url in @($p.urls)){if(-not(Check-Url ([string]$url))){throw "Invalid approved website in the imported file: $url"};$validUrls+=([string]$url)}
  $blocked=@($script:RkaProfileFlags.GetEnumerator()|Where-Object {[bool]$p.($_.Value)}|ForEach-Object {$script:RkaGuestItems[$_.Key].Label})
  if(-not(Ask-YesNo ("Apply these choices to $($g.Name) now?`n`nBlocked: "+$(if($blocked.Count){$blocked -join ', '}else{'nothing'})+"`nEverything else is allowed.") 'Import and apply')){return}
  $script:Ui.GamePortalUrl.Text=[string]$p.intranet
  $script:Ui.ChromeUrl.Text=[string]$p.intranet
  $script:ApprovedUrls=$validUrls
  $saved=[ordered]@{version=$script:AppVersion;account=$g.Name;intranet=[string]$p.intranet;urls=$validUrls}
  foreach($flag in $script:RkaProfileFlags.Values){$saved[$flag]=[bool]$p.$flag}
  $saved|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $script:ProfileFile -Encoding UTF8
  [void](Start-RkaWorker 'PolicyWorker.ps1' ('-Operation Persistent -TargetSid "'+$g.SID+'" -ProfilePath "'+$script:ProfileFile+'"'))
  Refresh-PolicyStatuses
  Set-Footer ('Imported choices applied to '+$g.Name+'.')
 }catch{Refresh-PolicyStatuses;Show-Failure $_.Exception.Message 'Import failed'}
}
function Open-LogFile([string]$path) {
 if(Test-Path -LiteralPath $path){Start-Process notepad.exe -ArgumentList ('"'+$path+'"')}
 else{Show-Notice "No log has been written yet:`n$path" 'Log unavailable'}
}
function Show-Page([string]$pageName) {
 foreach($name in @('Home','Policies','Lovable','Updates','Tools')){
  $script:Ui['Page'+$name].Visibility=if($name -eq $pageName){[System.Windows.Visibility]::Visible}else{[System.Windows.Visibility]::Collapsed}
  $nav=$script:Ui['Nav'+$name]
  if($name -eq $pageName){$nav.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#073B54');$nav.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#14CDF1')}
  else{$nav.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0B1A29');$nav.BorderBrush=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#245169')}
 }
}

function Invoke-AutologonSetup([string]$action) {
 try {
  Assert-Admin
  $guest=Selected-Guest
  $scriptFile=Join-Path $script:AppRoot 'Autologon-Setup.ps1'
  $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$scriptFile,'-Action',$action,'-GuestName',$guest.Name,'-GuestSid',$guest.SID)
  $out=& powershell.exe @args 2>&1 | Out-String
  $script:Ui.AutologonReport.Text=($out.Trim())
  if($LASTEXITCODE -ne 0){throw ('Autologon setup failed: '+$out)}
  if($action -eq 'Configure'){Show-Notice 'Microsoft Sysinternals Autologon has opened. Enter the selected guest password there and click Enable. Reboot later to verify. RKA never collects the password.' 'Guest auto sign-in'}
 }catch{Show-Failure $_.Exception.Message 'Automatic sign-in';$script:Ui.AutologonReport.Text=$_.Exception.Message}
}


function Show-CompanionHelp {
 $helpText=@'
RKA WINDOWS COMPANION - HELP

THIS PC
A summary of the guest account, lockdown, RKA Client, Lovable, LAN play, USB storage and versions. Refresh reads everything again.

GUEST LOCKDOWN
Pick the guest account, then Block or Allow each row; it changes straight away. Status shows what Windows reports: green Blocked, red Allowed. The guest sees a change after signing out and back in.
RKA Client at sign-in makes RKA Client the guest's desktop instead of Windows. It needs RKA Client & Companion Setup on the PC and an admin PIN.
Settings and Control Panel, Command Prompt, Registry Editor, Task Manager, Password changes, Lock on Ctrl+Alt+Del, Windows tips and pop-ups, and USB storage are settings for the guest only. Ctrl+Alt+Del itself can't be blocked (Windows keeps it for itself); Sign out and Switch user stay on it as the staff way out. They stop normal use, not every workaround; the guest stays a standard user, and RKA Client resets the PC between customers.
Chrome and Edge websites: the browsers open only approved websites. Sign-in pages (Steam, Epic, Riot, EA, Battle.net, Ubisoft, GOG, Xbox, Microsoft, Google, Yahoo, Apple), their email sites and captcha sites are always allowed; Approved websites lists them. Games and launchers keep full internet access.
Unlock everything removes every guest lockdown, back to Windows' defaults, however the guest was locked before. RKA Client stays the guest's desktop.

WHOLE PC
LAN play allows all traffic from the arcade's local network, so any LAN game can host and join, and turns off the block rules Windows makes when a game's firewall prompt is cancelled. The firewall keeps blocking the internet. Turn off LAN play undoes both.
USB storage, every account blocks removable drives for administrators too. The guest's own USB row is usually enough.
Windows Update restarts only after closing time, and never while someone is signed in.

LOVABLE
The background agent checks in with Lovable every minute, even with this window closed. Turn on remote changes to let Lovable restart the PC, lock or unlock the guest, turn LAN play on or off, send announcements and reset the PC. Remote USB control is a separate switch. Announcements appear in RKA Client as a small message in a corner that never takes focus from a game.

UPDATES
The PC checks GitHub every hour and installs newer RKA Client and Companion builds by itself; Update now checks straight away. The Companion and its agent update together. Install Companion from a ZIP file is for a PC without internet. After a Companion update, set the new agent version in Lovable.

STEAM ON EACH PC (once, by hand)
In Steam > Settings > Downloads: turn on Schedule auto-updates and pick after closing time (for example 1 AM to 9 AM), so games don't update while customers wait. Under Game file transfer over local network, allow transfers to other devices on the local network, so one PC's download feeds the others. Steam keeps these for every account on the PC, the guest included. The Companion doesn't change Steam's own files, because Steam rewrites them while it runs.

TOOLS
Copy diagnostics zips the logs to the desktop, without passwords or Lovable tokens, to send to Claude.
Automatic sign-in uses Microsoft's Autologon; the Companion never sees the password. Hold Shift during startup to skip it once.
Game scan only reads: it lists the guest's startup programs and shortcuts set to Run as administrator.
Older tools are from before RKA Client. Chrome startup is hidden when RKA Client is the guest's desktop.

EMERGENCY RECOVERY
If this window won't open, run Emergency Restore.cmd in the Application folder from an administrator account. It unlocks everything for every guest account and allows USB storage again.
'@
 $dialog=New-Object System.Windows.Window
 $dialog.Title='RKA Companion - Help and Documentation'
 $dialog.Width=880;$dialog.Height=700;$dialog.MinWidth=620;$dialog.MinHeight=430
 $dialog.WindowStartupLocation='CenterOwner';$dialog.Owner=$script:Window
 $dialog.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#08121F')
 $layout=New-Object System.Windows.Controls.DockPanel
 $content=New-Object System.Windows.Controls.TextBox
 $content.Text=$helpText;$content.IsReadOnly=$true;$content.AcceptsReturn=$true;$content.TextWrapping='Wrap'
 $content.VerticalScrollBarVisibility='Auto';$content.HorizontalScrollBarVisibility='Auto'
 $content.Margin='12';$content.Padding='14';$content.FontSize=14
 $content.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#EAF5FF')
 $content.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0A2032')
 [void]$layout.Children.Add($content)
 $dialog.Content=$layout
 [void]$dialog.ShowDialog()
}

function Exit-App {
 $script:AllowExit=$true
 if($script:TrayIcon){$script:TrayIcon.Visible=$false;$script:TrayIcon.Dispose();$script:TrayIcon=$null}
 if($script:Window){$script:Window.Close()}
}
function Setup-Tray {
 try {
  $tray=New-Object System.Windows.Forms.NotifyIcon
  $icon=Join-Path $script:AppRoot 'assets\rka.ico'
  if(Test-Path $icon){$tray.Icon=[System.Drawing.Icon]::new($icon)}else{$tray.Icon=[System.Drawing.SystemIcons]::Application}
  $tray.Text='RKA Windows Companion v'+$script:AppVersion
  $menu=New-Object System.Windows.Forms.ContextMenuStrip
  [void]$menu.Items.Add('Open Companion')
  [void]$menu.Items.Add('Exit Companion')
  $menu.Items[0].Add_Click({$script:Window.Show();$script:Window.WindowState='Normal';$script:Window.Activate()})
  $menu.Items[1].Add_Click({Exit-App})
  $tray.ContextMenuStrip=$menu
  $tray.Add_DoubleClick({$script:Window.Show();$script:Window.WindowState='Normal';$script:Window.Activate()})
  $tray.Visible=$true
  $script:TrayIcon=$tray
 }catch{Write-RkaLog ('Tray setup failed: '+$_.Exception.Message)}
}
function Update-UsbStatus {
 try {
  $path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices'
  $value=(Get-ItemProperty -LiteralPath $path -Name 'Deny_All' -ErrorAction SilentlyContinue).Deny_All
  Set-ItemStatus 'UsbStatus' $(if($value -eq 1){'Blocked'}else{'Allowed'}) 'What Windows reports for every account. Test with a flash drive to be sure.'
  $script:UsbPcBlocked=($value -eq 1)
 }catch{$script:Ui.UsbStatus.Text='Unable to verify'}
}
function Get-AgentState {
 $remote=Join-Path $env:ProgramData 'RKA-Lockdown-Agent\RemoteControl'
 $remoteCfg=Join-Path $remote 'remote-config.json'
 $agentHealth=Join-Path $remote 'agent-health.json'
 $t=Get-ScheduledTask -TaskName 'RKA-Remote-Commands' -ErrorAction SilentlyContinue
 $enabled=$false;$usbEnabled=$false
 if(Test-Path -LiteralPath $remoteCfg){try{$cfg=Get-Content -LiteralPath $remoteCfg -Raw|ConvertFrom-Json;$enabled=[bool]$cfg.allowChanges;$usbEnabled=[bool]$cfg.allowUsb}catch{}}
 # Read installed payload independently of last authenticated remote check-in.
 # Do not present the GUI release as proof that SYSTEM tasks were upgraded.
 $installedPayload='Unknown'
 $agentScript=Join-Path $remote 'Remote-Agent.ps1'
 if(Test-Path -LiteralPath $agentScript){
  try { $head=Get-Content -LiteralPath $agentScript -TotalCount 14 -ErrorAction Stop
   $line=$head | Where-Object {$_ -match '^\$agentVersion='} | Select-Object -First 1
   if($line -match "'([0-9]+\.[0-9]+\.[0-9]+)'$"){$installedPayload=$matches[1]}
  }catch{}
 }
 $agentVersion='Unknown';$healthy=$false;$lastPoll='never'
 if(Test-Path -LiteralPath $agentHealth){
  try{
   $h=Get-Content -LiteralPath $agentHealth -Raw -Encoding UTF8|ConvertFrom-Json
   $agentVersion=[string]$h.version
   $lastPoll=[string]$h.confirmedUtc
   $healthy=(($t -ne $null) -and ($t.State -ne 'Disabled') -and ([datetimeoffset]::UtcNow-[datetimeoffset]::Parse($lastPoll)).TotalMinutes -le 4)
  }catch{$agentVersion='Unverified';$healthy=$false}
 }
 if(-not $t){$healthy=$false; if($agentVersion -eq 'Unknown'){$agentVersion='Not installed'}}
 return [pscustomobject]@{Version=$agentVersion;PayloadVersion=$installedPayload;Healthy=$healthy;RemoteEnabled=$enabled;UsbEnabled=$usbEnabled;Installed=($null -ne $t);LastPoll=$lastPoll}
}
function Refresh-AgentIndicators {
 $a=Get-AgentState
 $client=Get-ClientInfo
 $script:Ui.FooterVersion.Text='Client '+$(if($client.Installed){'v'+$client.Version}else{'not installed'})+'  |  Companion v'+$script:AppVersion+'  |  Agent '+$(if($a.PayloadVersion -match '^\d+\.\d+\.\d+$'){'v'+$a.PayloadVersion}else{$a.Version})
 $script:Ui.FooterVersion.ToolTip='Click for Updates. Agent last checked in with Lovable: '+$a.LastPoll
 $label=if(-not $a.Installed){'Agent not installed'}elseif(-not $a.Healthy){'Agent status stale / unverified'}elseif($a.RemoteEnabled){'Remote changes ENABLED'}else{'Remote changes OFF'}
 $script:Ui.RemoteConsentLabel.Text=$label
 $brush=if(-not $a.Installed -or -not $a.Healthy){'#F8BE5A'}elseif($a.RemoteEnabled){'#32E7A1'}else{'#9BB1C4'}
 $script:Ui.RemoteConsentLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($brush)
 $usbText=if(-not $a.Installed){'USB remote: Agent not installed'}elseif(-not $a.RemoteEnabled){'USB remote: Remote Changes must be enabled first'}elseif($a.UsbEnabled){'USB remote: Authorized locally (await agent check-in)'}else{'USB remote: Not authorized locally'}
 if($a.UsbEnabled -and $a.Healthy -and $a.Version -eq $a.PayloadVersion){$usbText='USB remote: Local permission ENABLED; verify capability in Lovable'}
 $script:Ui.RemoteUsbConsentLabel.Text=$usbText
 $script:Ui.RemoteUsbConsentLabel.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($a.UsbEnabled -and $a.RemoteEnabled){'#32E7A1'}else{'#F8BE5A'}))
 $script:Ui.FooterVersion.ToolTip+=' | Installed agent payload: '+$a.PayloadVersion+' | Remote USB permission: '+$a.UsbEnabled
 $script:Ui.FooterVersion.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($a.Healthy){'#32E7A1'}else{'#F8BE5A'}))
 $script:Ui.HomeAgentLabel.Text=$(if(-not $a.Installed){'Not installed'}elseif($a.Healthy){'v'+$a.Version+', checked in '+$(try{([datetimeoffset]::Parse($a.LastPoll)).ToLocalTime().ToString('h:mm tt')}catch{'recently'})+', '+$(if($a.RemoteEnabled){'remote changes on'}else{'remote changes off'})}else{'Installed, no recent check-in'})
}
function Invoke-UpdaterProcess([string]$action,[string]$zip='') {
 Assert-Admin
 $stdout=Join-Path $script:DataRoot 'updater-stdout.log'
 $stderr=Join-Path $script:DataRoot 'updater-stderr.log'
 $args='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $script:AppRoot 'Update-Manager.ps1')+'" -Action '+$action+' -Channel Stable'
 if($zip){$args+=' -ZipPath "'+$zip+'"'}
 $process=Start-Process -FilePath $script:PowerShellExe -ArgumentList $args -Wait -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr -ErrorAction Stop
 $out=(Get-Content -LiteralPath $stdout -Raw -ErrorAction SilentlyContinue)+"`r`n"+(Get-Content -LiteralPath $stderr -Raw -ErrorAction SilentlyContinue)
 $script:Ui.UpdateReport.Text=$out
 if($process.ExitCode -ne 0){throw ('Updater '+$action+' failed (exit '+$process.ExitCode+'). See Software Updates output.')}
 return $out
}
function Read-LastCheck {
 try{if(Test-Path -LiteralPath $script:LastCheckFile){return Get-Content -LiteralPath $script:LastCheckFile -Raw -Encoding UTF8|ConvertFrom-Json}}catch{}
 return $null
}
# The Updates page: every version, the last check, and anything that needs attention.
function Refresh-UpdatesPage {
 try{
  $c=Get-ClientInfo
  $a=Get-AgentState
  $script:Ui.UpdClientVersion.Text=$(if($c.Installed){'v'+$c.Version}else{'Not installed'})
  $script:Ui.UpdCompanionVersion.Text='v'+$script:AppVersion
  $script:Ui.UpdAgentVersion.Text=$(if(-not $a.Installed){'Not installed'}else{'v'+$a.PayloadVersion+$(if($a.Healthy){', checked in with Lovable '+$(try{([datetimeoffset]::Parse($a.LastPoll)).ToLocalTime().ToString('h:mm tt')}catch{'recently'})}else{', no recent check-in'})})
  $last=Read-LastCheck
  $script:Ui.UpdateLastCheck.Text=$(if($last){([datetime]$last.at).ToLocalTime().ToString('MMM d, h:mm tt')+'. '+[string]$last.message}else{'No check recorded yet.'})
  $warn=@()
  if(-not $c.Installed){$warn+="RKA Client isn't installed. Run RKA Client & Companion Setup."}
  if($a.Installed -and $a.PayloadVersion -match '^\d' -and $a.PayloadVersion -ne $script:AppVersion){$warn+=("The Lovable agent is v"+$a.PayloadVersion+" but the Companion is v"+$script:AppVersion+": click Install or repair agent on the Lovable page.")}
  if($last -and [string]$last.outcome -in @('Failed','Rejected')){$warn+=("The last update didn't finish: "+[string]$last.message)}
  $script:Ui.UpdateWarning.Text=($warn -join "`n")
  $script:Ui.FooterVersion.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($warn.Count){'#F8BE5A'}else{'#32E7A1'}))
 }catch{Write-RkaLog ('Updates page: '+$_.Exception.Message)}
}
function Invoke-UpdateNow {
 try{
  Assert-Admin
  $task=Get-ScheduledTask -TaskName 'RKA Client Updater' -ErrorAction SilentlyContinue
  if($task){
   # RKA Client & Companion Setup's update task updates both apps; start it and watch for its result.
   $script:UpdateBefore=[string](Read-LastCheck).at
   Start-ScheduledTask -TaskName 'RKA Client Updater'
   $script:Ui.UpdateReport.Text='Checking GitHub and installing anything newer for RKA Client and the Companion. This can take a few minutes...'
   $script:UpdateDeadline=(Get-Date).AddMinutes(10)
   if(-not $script:UpdateTimer){
    $script:UpdateTimer=New-Object System.Windows.Threading.DispatcherTimer
    $script:UpdateTimer.Interval=[TimeSpan]::FromSeconds(3)
    $script:UpdateTimer.Add_Tick({Watch-UpdateTask})
   }
   $script:UpdateTimer.Start()
   return
  }
  # Without the Setup's task, the Companion updates itself from GitHub.
  $script:Ui.UpdateReport.Text='Checking GitHub for a newer Companion...'
  $out=Invoke-UpdaterProcess 'Download'
  if($out -match 'UP TO DATE'){$script:Ui.UpdateReport.Text="RKA Companion v$($script:AppVersion) is up to date.";Set-Footer 'The Companion is up to date.';return}
  if($out -notmatch 'STAGED RELEASE: (v\d+\.\d+\.\d+(?:-PILOT)?)'){throw "The updater didn't report a verified download."}
  $version=$matches[1]
  if(-not(Ask-YesNo ("Install RKA Companion $version on this PC now?`n`nIt updates the Companion and the background agent together and keeps a backup of the current files.") 'Install update')){Set-Footer ('Downloaded '+$version+'; not installed.');return}
  $out=Invoke-UpdaterProcess 'InstallStaged'
  if($out -notmatch 'UPDATE INSTALLED:'){throw "The updater didn't confirm the install."}
  Show-Notice 'Update installed. Close the Companion and open it again from the desktop shortcut, then set the new agent version in Lovable.' 'Companion updated'
 }catch{$script:Ui.UpdateReport.Text+="`r`n"+$_.Exception.Message;Show-Failure $_.Exception.Message 'Update now'}
}
function Watch-UpdateTask {
 $last=Read-LastCheck
 $done=($last -and [string]$last.at -ne $script:UpdateBefore)
 if(-not $done -and (Get-Date) -lt $script:UpdateDeadline){return}
 $script:UpdateTimer.Stop()
 $script:Ui.UpdateReport.Text=$(if($done){[string]$last.message}else{'The update task is still running. Click Refresh in a few minutes.'})
 Refresh-UpdatesPage;Refresh-AgentIndicators
 if($done -and [string]$last.message -match 'Companion: installed'){Show-Notice 'The Companion was updated. Close this window and open it again from the desktop shortcut, then set the new agent version in Lovable.' 'Companion updated'}
}
function Update-RemoteStatus {
 $root=Join-Path $env:ProgramData 'RKA-Lockdown-Agent'
 $remote=Join-Path $root 'RemoteControl'
 $text="RKA Companion: v$($script:AppVersion)"
 $a=Get-AgentState
 $text+="`r`nInstalled SYSTEM agent file: v$($a.PayloadVersion) (from protected Remote-Agent.ps1)"
 $text+="`r`nLast authenticated agent poll: v$($a.Version) at $($a.LastPoll)"
 $text+="`r`nRemote Changes: $($a.RemoteEnabled); USB remote permission: $($a.UsbEnabled)"
 if($a.PayloadVersion -ne 'Unknown' -and $a.Version -ne $a.PayloadVersion){$text+="`r`nWARNING: Installed agent file and confirmed poll differ; use Install / Repair Agent, then refresh. Do not treat the GUI version as the installed agent."}
 foreach($spec in @(@('RKA-Lockdown-ReadOnlyHeartbeat','Heartbeat'),@('RKA-Remote-Commands','RemoteControl'))){
  $task=Get-ScheduledTask -TaskName $spec[0] -ErrorAction SilentlyContinue
  $text+="`r`n$($spec[0]): " + $(if($task){[string]$task.State}else{'Not installed'})
  if($task){$text+="`r`n  Script path: " + [string]$task.Actions[0].Arguments}
 }
 $health=Join-Path $remote 'agent-health.json'
 if(Test-Path -LiteralPath $health){
  try{$j=Get-Content -LiteralPath $health -Raw|ConvertFrom-Json;$text+="`r`nAgent authenticated poll: v$($j.version) at $($j.confirmedUtc)"}
  catch{$text+="`r`nAgent health: unreadable"}
 }else{$text+="`r`nAgent authenticated poll: Not yet confirmed"}
 $file=Join-Path $remote 'remote-status.txt'
 $log=Join-Path $remote 'remote.log'
 if(Test-Path -LiteralPath $file){$text+="`r`n"+(Get-Content -LiteralPath $file -Raw -ErrorAction SilentlyContinue)}
 if(Test-Path -LiteralPath $log){$text+="`r`nRecent events:`r`n"+((Get-Content -LiteralPath $log -Tail 5 -ErrorAction SilentlyContinue)-join "`r`n")}
 $script:Ui.RemoteReport.Text=$text
 Refresh-AgentIndicators
}
function Invoke-RemoteSetup([string]$operation) {
 try {
  Assert-Admin
  if($operation -in @('Install','Upgrade')){
   $guest=$null;try{$guest=Selected-Guest}catch{}
   $p=Join-Path $script:DataRoot 'profile.json'
   if($guest){Save-Profile $false}
   $args='-Action Upgrade'
   if(Test-Path -LiteralPath $p){$args+=' -ProfilePath "'+$p+'"'}
  }elseif($operation -eq 'EnableChanges'){
   if(-not(Ask-YesNo 'Let Lovable admins restart this PC, change the guest lockdown, send announcements and reset the PC, without asking here each time?' 'Turn on remote changes')){return}
   $args='-Action EnableChanges'
  }elseif($operation -eq 'EnableUsb'){
   $a=Get-AgentState
   if(-not $a.RemoteEnabled){throw 'Enable Remote Changes locally before authorizing remote USB commands.'}
   if(-not(Ask-YesNo 'Let Lovable block or allow USB storage on this PC? A block affects every account, administrators included. Nothing is blocked now.' 'Turn on remote USB control')){return}
   $args='-Action EnableUsb'
  }elseif($operation -eq 'DisableUsb'){
   $args='-Action DisableUsb'
  }elseif($operation -eq 'SyncProfile'){
   $guest=Selected-Guest;Save-Profile $false
   $args='-Action SyncProfile -ProfilePath "'+$script:ProfileFile+'"'
  }else{$args='-Action '+$operation}
  [void](Start-RkaWorker 'Remote-Setup.ps1' $args)
  Update-RemoteStatus
  $a=Get-AgentState
  if($operation -in @('Install','Upgrade') -and (-not $a.Healthy -or $a.Version -ne $script:AppVersion -or $a.PayloadVersion -ne $script:AppVersion)){
   Set-Footer ('Agent files installed (v'+$a.PayloadVersion+'). Waiting for its first check-in with Lovable; click Check agent in a minute.')
  }else{
   Set-Footer ('Done: '+$operation+'.')
  }  }catch {Update-RemoteStatus;Show-Failure $_.Exception.Message 'Remote management setup failed'}
}
function Invoke-LanScript([string]$action) {
 $path=Join-Path $script:AppRoot 'LAN-Firewall.ps1'
 if(-not(Test-Path -LiteralPath $path)){throw 'LAN-Firewall.ps1 is missing. Extract the whole Companion ZIP.'}
 return @(& $script:PowerShellExe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $path -Action $action 2>&1|ForEach-Object {[string]$_})
}
function Update-LanStatus {
 try{
  $lines=Invoke-LanScript 'Status'
  $script:LanReport=($lines -join "`r`n")
  $summary=@($lines|Where-Object {$_ -like 'SUMMARY: *'}|Select-Object -First 1)
  $text=if($summary.Count){$summary[0].Substring(9)}else{'Unknown'}
  $on=@($lines|Where-Object {$_ -eq 'LAN PLAY: on'}).Count -gt 0
  $script:Ui.LanStatus.Text=$(if($on){$text}else{"Off: Windows Firewall blocks other PCs on the LAN, so LAN games may show a firewall prompt the guest can't answer."})
  $script:Ui.LanStatus.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString($(if($on){'#32E7A1'}else{'#F8BE5A'}))
  $script:Ui.HomeLanLabel.Text=$(if($on){$text}else{'Off'})
 }catch{$script:Ui.LanStatus.Text='Unable to check';$script:Ui.HomeLanLabel.Text='Unable to check';Write-RkaLog ('LAN status: '+$_.Exception.Message)}
}
function Invoke-LanPlay([string]$action) {
 try{
  Assert-Admin
  if($action -eq 'Enable' -and -not(Ask-YesNo "Turn on LAN play for this PC?`n`nEvery PC on the arcade's network can reach it for LAN games. The firewall keeps blocking the internet." 'Turn on LAN play')){return}
  [void](Start-RkaWorker 'LAN-Firewall.ps1' ('-Action '+$action))
  Update-LanStatus
  Set-Footer $(if($action -eq 'Enable'){'LAN play is on. Games can host and join over the local network.'}else{'LAN play is off. The firewall is back to Windows defaults for this PC.'})
 }catch{Update-LanStatus;Show-Failure $_.Exception.Message 'LAN play'}
}
function Show-LanDetails {
 try{
  $lines=Invoke-LanScript 'Preview'
  $dialog=New-Object System.Windows.Window
  $dialog.Title='LAN play details';$dialog.Width=760;$dialog.Height=520;$dialog.Owner=$script:Window;$dialog.WindowStartupLocation='CenterOwner'
  $dialog.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#08121F')
  $box=New-Object System.Windows.Controls.TextBox
  $box.Text=($lines -join "`r`n");$box.IsReadOnly=$true;$box.TextWrapping='NoWrap';$box.FontFamily='Consolas';$box.FontSize=13;$box.Margin='12';$box.Padding='10'
  $box.VerticalScrollBarVisibility='Auto';$box.HorizontalScrollBarVisibility='Auto'
  $box.Foreground=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#EAF5FF')
  $box.Background=[System.Windows.Media.BrushConverter]::new().ConvertFromString('#0A2032')
  $dialog.Content=$box
  [void]$dialog.ShowDialog()
 }catch{Show-Failure $_.Exception.Message 'LAN play details'}
}
function Get-ClientInfo {
 $exe=Join-Path $script:KitRoot 'RKA Client\RkaClient.exe'
 if(-not(Test-Path -LiteralPath $exe)){$exe=Join-Path $env:ProgramFiles 'RKA Client\RkaClient.exe'}
 $info=[ordered]@{Installed=(Test-Path -LiteralPath $exe);Version='';Status=$null}
 if($info.Installed){try{$info.Version=([string](Get-Item -LiteralPath $exe).VersionInfo.ProductVersion).Split('+')[0]}catch{}}
 $statusFile=Join-Path $env:ProgramData 'RKA-Client\status\status.json'
 if(Test-Path -LiteralPath $statusFile){try{$info.Status=Get-Content -LiteralPath $statusFile -Raw -Encoding UTF8|ConvertFrom-Json}catch{}}
 return [pscustomobject]$info
}
# 1.4: Chrome startup also shows while RKA Client is the guest's shell if the
# old Chrome task is still there (it opens a Chrome window under the Client),
# so staff can turn it off.
function Update-ClientShellUi {
 $shell=[bool]$script:ClientIsShell
 $task=$null
 try{$task=Get-ScheduledTask -TaskName 'RKA-Guest-Chrome-Portal' -ErrorAction SilentlyContinue}catch{}
 $show=(-not $shell) -or [bool]$task
 $script:Ui.ChromeStartupPanel.Visibility=$(if($show){[System.Windows.Visibility]::Visible}else{[System.Windows.Visibility]::Collapsed})
 $script:Ui.ClientShellNote.Visibility=$(if($shell){[System.Windows.Visibility]::Visible}else{[System.Windows.Visibility]::Collapsed})
 $script:Ui.ClientShellNote.Text=$(if($shell -and $task){"Chrome startup is still on for this guest from before RKA Client. It opens a Chrome window under the Client: Turn off below."}else{"Chrome startup is hidden: RKA Client is this guest's shell and opens the intranet itself."})
}

# 1.4: rkaserver's fixed address in this PC's hosts file, in the same
# "# RKA Client" line RKA Client Setup writes.
$script:HostsFile=Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
$script:HostsMarker='# RKA Client'
function Get-ServerHostsAddress {
 if(-not(Test-Path -LiteralPath $script:HostsFile)){return $null}
 foreach($line in @(Get-Content -LiteralPath $script:HostsFile)){
  if(-not $line.TrimEnd().EndsWith($script:HostsMarker)){continue}
  $parts=@($line.Trim() -split '\s+')
  if($parts.Count -ge 2 -and $parts[1] -eq 'rkaserver'){return $parts[0]}
 }
 return $null
}
function Test-LanAddressText([string]$a){
 $ip=$null
 if(-not [Net.IPAddress]::TryParse($a,[ref]$ip) -or $ip.AddressFamily -ne 'InterNetwork'){return $false}
 return ($ip.ToString() -eq $a.Trim()) -and ($a -match '^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)')
}
function Refresh-ServerAddress {
 try{
  $a=Get-ServerHostsAddress
  $found='not found'
  try{$found=(@([Net.Dns]::GetHostAddresses('rkaserver')|Where-Object{$_.AddressFamily -eq 'InterNetwork'}|ForEach-Object{$_.ToString()}) -join ', ')}catch{}
  if(-not $found){$found='not found'}
  $script:Ui.ServerAddressLabel.Text=$(if($a){"In this PC's hosts file: rkaserver = $a. Windows finds rkaserver at: $found."}else{"Not in this PC's hosts file. Windows finds rkaserver at: $found."})
  if(-not $script:Ui.ServerAddressBox.Text -and $a){$script:Ui.ServerAddressBox.Text=$a}
 }catch{$script:Ui.ServerAddressLabel.Text='Status unavailable: '+$_.Exception.Message}
}
function Save-ServerAddress([bool]$remove){
 try{
  Assert-Admin
  $lines=@(if(Test-Path -LiteralPath $script:HostsFile){Get-Content -LiteralPath $script:HostsFile})
  $keep=@($lines|Where-Object{-not $_.TrimEnd().EndsWith($script:HostsMarker)})
  if(-not $remove){
   $a=$script:Ui.ServerAddressBox.Text.Trim()
   if(-not(Test-LanAddressText $a)){throw "$a isn't a LAN address. Type rkaserver's fixed address, like 192.168.1.115."}
   $keep+=("$a`trkaserver`t"+$script:HostsMarker)
  }
  Set-Content -LiteralPath $script:HostsFile -Value $keep -Encoding ASCII
  try{Clear-DnsClientCache}catch{}
  if($remove){$script:Ui.ServerAddressBox.Text=''}
  Refresh-ServerAddress
  Set-Footer $(if($remove){'Removed rkaserver from the hosts file'}else{'Saved rkaserver''s address in the hosts file'})
 }catch{Set-Footer ('Intranet server: '+$_.Exception.Message) $true;Show-Failure $_.Exception.Message 'Intranet server'}
}
function Refresh-Home {
 try{
  $brush=[System.Windows.Media.BrushConverter]::new()
  $g=$script:Ui.GuestSelector.SelectedItem
  $script:Ui.HomeGuestLabel.Text=$(if($g){[string]$g.Name+' (standard user)'}else{'No standard guest account found'})
  $applied=@($script:ItemRows.Keys|Where-Object {$script:ItemStates[$_] -eq 'Blocked'}).Count
  $script:Ui.HomeLockdownLabel.Text=$(if($applied -gt 0){'On: '+$applied+' of '+$script:ItemRows.Count+' blocked'}else{'Off'})
  $script:Ui.HomeUsbLabel.Text='Guest: '+$(if($script:ItemStates.usb -eq 'Blocked'){'blocked'}else{'allowed'})+'; every account: '+$(if($script:UsbPcBlocked){'blocked'}else{'allowed'})
  $script:Ui.HomeLockdownLabel.Foreground=$brush.ConvertFromString($(if($applied -gt 0){'#32E7A1'}else{'#F8BE5A'}))
  $c=Get-ClientInfo
  if(-not $c.Installed){$text='Not installed'}
  else{
   $text='v'+$c.Version+$(if($script:ClientIsShell){", the guest's shell"}else{", not the guest's shell"})
   if($c.Status){
    $mode=[string]$c.Status.mode
    $when=[datetimeoffset]::MinValue
    $fresh=[datetimeoffset]::TryParse([string]$c.Status.updatedUtc,[ref]$when) -and ([datetimeoffset]::UtcNow-$when).TotalMinutes -lt 3
    if($fresh){$text+=', running: '+$(switch($mode){'locked'{'locked'}'staff'{'staff mode'}default{'not locked'}})+$(if($c.Status.customerActive){', someone is playing'}else{''})}
    elseif($when -ne [datetimeoffset]::MinValue){$text+=', last seen '+$when.ToLocalTime().ToString('MMM d h:mm tt')}
   }
  }
  $script:Ui.HomeClientLabel.Text=$text
  $a=Get-AgentState
  $script:Ui.HomeVersionLabel.Text='Client '+$(if($c.Installed){'v'+$c.Version}else{'not installed'})+', Companion v'+$script:AppVersion+', agent '+$(if($a.PayloadVersion -match '^\d'){'v'+$a.PayloadVersion}else{$a.Version})
 }catch{Write-RkaLog ('This PC refresh: '+$_.Exception.Message)}
}
# Zips logs and status files to the desktop for sending to Claude. Never the
# Lovable token, enrollment, consent or PIN files.
function Copy-Diagnostics {
 try{
  $zip=Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) ('RKA-diagnostics-'+$env:COMPUTERNAME+'-'+(Get-Date -Format 'yyyyMMdd-HHmm')+'.zip')
  $temp=Join-Path $env:TEMP ('rka-diag-'+[guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $temp -Force|Out-Null
  $keep=@('status.json','last-check.json','update-state.json','agent-health.json','features.json','approved-policy.json','profile.json')
  foreach($src in @(@((Join-Path $env:ProgramData 'RKA-Lockdown-Agent'),'Companion-agent'),@($script:DataRoot,'Companion-window'),@((Join-Path $env:ProgramData 'RKA-Client'),'Client'))){
   if(-not(Test-Path -LiteralPath $src[0])){continue}
   Get-ChildItem -LiteralPath $src[0] -Recurse -File -Force -ErrorAction SilentlyContinue|Where-Object {
    ($_.Extension -in @('.log','.txt') -or $_.Name -in $keep) -and $_.Length -lt 5MB -and $_.Name -notmatch '(?i)token|secret|configuration|enroll|consent|admin-pin|remote-config'
   }|ForEach-Object {
    $dest=Join-Path (Join-Path $temp $src[1]) $_.FullName.Substring($src[0].Length).TrimStart('\')
    New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $dest
   }
  }
  # Every account's RKA Client log, the guest's included, and the Setup logs.
  foreach($log in @(Get-ChildItem -Path "$env:SystemDrive\Users\*\AppData\Local\RKA-Client\*.log","$env:SystemDrive\Users\*\AppData\Local\Temp\Setup Log *.txt" -Force -ErrorAction SilentlyContinue)){
   $user=$log.FullName.Split('\')[2]
   Copy-Item -LiteralPath $log.FullName -Destination (Join-Path $temp ($user+'-'+$log.Name))
  }
  $a=Get-AgentState;$c=Get-ClientInfo
  @("Computer: $env:COMPUTERNAME","Made: $(Get-Date -Format o)","RKA Client: $($c.Version)","Companion: $($script:AppVersion)","Agent files: $($a.PayloadVersion); last Lovable check-in $($a.LastPoll)",("Guest lockdown: "+(($script:ItemStates.GetEnumerator()|ForEach-Object {$_.Key+'='+$_.Value}) -join ', '))) | Set-Content -LiteralPath (Join-Path $temp 'summary.txt') -Encoding UTF8
  Compress-Archive -Path (Join-Path $temp '*') -DestinationPath $zip -Force
  Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
  Show-Notice "Saved to the desktop:`n$zip`n`nLogs and versions only, no passwords or Lovable tokens." 'Copy diagnostics'
 }catch{Show-Failure $_.Exception.Message 'Copy diagnostics'}
}
try {
 if(-not(Test-Path $script:DataRoot)){New-Item -Path $script:DataRoot -ItemType Directory -Force|Out-Null}
 Add-Type -AssemblyName PresentationFramework
 Add-Type -AssemblyName PresentationCore
 Add-Type -AssemblyName WindowsBase
 Add-Type -AssemblyName System.Xaml
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 $principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  [System.Windows.MessageBox]::Show('RKA Companion is for staff.','RKA Companion')|Out-Null
  exit 0
 }
 $created=$false
 $script:Mutex=[System.Threading.Mutex]::new($true,'Local\RKA.Companion.WPF.v040',[ref]$created)
 $script:MutexAcquired=$created
 if(-not $created){[System.Windows.MessageBox]::Show('RKA WPF Companion is already running; open its system tray icon.','Already running')|Out-Null;exit 0}
 $reader=[System.Xml.XmlReader]::Create((Join-Path $script:AppRoot 'RKA-Window.xaml'))
 try{$script:Window=[System.Windows.Markup.XamlReader]::Load($reader)}finally{$reader.Dispose()}
 # Fit smaller laptop displays while preserving a comfortable minimum layout.
 $work=[System.Windows.SystemParameters]::WorkArea
 if($work.Width -gt 1120){$script:Window.Width=[math]::Min($script:Window.Width,$work.Width-28)}
 if($work.Height -gt 750){$script:Window.Height=[math]::Min($script:Window.Height,$work.Height-35)}
 $script:Ui=@{}
 foreach($name in @('CopyAdminShortcutsButton','GameCompatibilityScanButton','GameCompatibilityReport','UpdateInstallZipButton','UsbStatus','UsbEnableButton','UsbRestoreButton','RemoteInstall','RemoteEnableChanges','RemoteDisableChanges','RemoteEnableUsb','RemoteDisableUsb','RemoteUsbConsentLabel','RemoteSyncProfile','RemoteRemove','RemoteStatus','RemoteReport','AppLogo','NoGuestMessage','InstallDiscordButton','EditApprovedSitesButton','SaveDesktopBackupButton','RestoreDesktopBackupButton','DeployIntranetButton','TitleBar','MinimizeButton','MaximizeButton','CloseButton','NavHome','NavPolicies','NavLovable','NavUpdates','NavTools','PageHome','PagePolicies','PageLovable','PageUpdates','PageTools','OpenHelpButton','ConfigureAutologonButton','AutologonStatusButton','DisableAutologonButton','AutologonReport','GuestSelector','StatusSettings','StatusCmd','StatusRegistry','StatusTaskMgr','StatusPassword','StatusLock','StatusPopups','StatusUsbGuest','StatusEdge','StatusWinUpdate','ClientShellStatus','BlockSettings','AllowSettings','BlockCmd','AllowCmd','BlockRegistry','AllowRegistry','BlockTaskMgr','AllowTaskMgr','BlockPassword','AllowPassword','BlockLock','AllowLock','BlockPopups','AllowPopups','BlockUsbGuest','AllowUsbGuest','BlockEdge','AllowEdge','BlockWinUpdate','AllowWinUpdate','ClientShellOnButton','ClientShellOffButton','UnlockAllButton','PolicySummary','ComputerLabel','HeartbeatLabel','ChromeQuickLabel','QuickCheckHeartbeat','LatestActionLabel','ViewPolicyLog','HomeGuestLabel','HomeLockdownLabel','HomeClientLabel','HomeAgentLabel','HomeLanLabel','HomeUsbLabel','HomeVersionLabel','HomeRefreshButton','LanStatus','LanEnableButton','LanDisableButton','LanPreviewButton','ChromeStartupPanel','ClientShellNote','GamePortalUrl','OpenPortalButton','OpenSteamButton','CheckConnectionButton','ConnectDeviceButton','ViewHeartbeatLog','ConnectionReport','ChromeUrl','ChromeMode','ChromeDelay','ChromeInstall','ChromeRemove','ChromeStatus','ChromeReport','RunHealthButton','CopyDiagnosticsButton','ExportProfileButton','ImportProfileButton','CreateShortcutButton','HealthReport','OpenLogsButton','VerifyPolicyButton','FooterStatus','FooterVersion','RemoteConsentLabel','UpdateNowButton','UpdateCheckButton','UpdateOpenGithubButton','UpdateReport','UpdateWarning','UpdateLastCheck','UpdClientVersion','UpdCompanionVersion','UpdAgentVersion','ServerAddressLabel','ServerAddressBox','ServerAddressSave','ServerAddressRemove','ServerAddressCheck')){
  $c=$script:Window.FindName($name)
  if($null -eq $c){throw "XAML control missing: $name"}
  $script:Ui[$name]=$c
 }
 $logoFile=Join-Path $script:AppRoot 'assets\rka-icon-preview.png'
 if(Test-Path -LiteralPath $logoFile){
  $bmp=New-Object System.Windows.Media.Imaging.BitmapImage
  $bmp.BeginInit();$bmp.UriSource=[System.Uri]::new($logoFile);$bmp.CacheOption=[System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad;$bmp.EndInit()
  $script:Ui.AppLogo.Source=$bmp
 }
 $script:Ui.ComputerLabel.Text=$env:COMPUTERNAME
 Update-UsbStatus
 Update-RemoteStatus
 $script:Ui.ChromeMode.SelectedIndex=0
 $script:SavedProfile=Read-Profile
 $script:ApprovedUrls=@($script:SavedProfile.urls)
 $script:Ui.GamePortalUrl.Text=[string]$script:SavedProfile.intranet
 $script:Ui.ChromeUrl.Text=[string]$script:SavedProfile.intranet
 $script:PortalUrlSyncing=$false
 $script:Ui.ChromeUrl.Add_TextChanged({Sync-PortalUrl 'Chrome'})
 $script:Ui.GamePortalUrl.Add_TextChanged({Sync-PortalUrl 'Games'})
 Find-GuestAccounts
 $script:Ui.GuestSelector.Add_SelectionChanged({Refresh-PolicyStatuses})
 $script:Ui.TitleBar.Add_MouseLeftButtonDown({if($_.ClickCount -eq 2){if($script:Window.WindowState -eq 'Maximized'){$script:Window.WindowState='Normal'}else{$script:Window.WindowState='Maximized'}}else{try{$script:Window.DragMove()}catch{}}})
 $script:Ui.MinimizeButton.Add_Click({$script:Window.WindowState='Minimized'})
 $script:Ui.MaximizeButton.Add_Click({if($script:Window.WindowState -eq 'Maximized'){$script:Window.WindowState='Normal'}else{$script:Window.WindowState='Maximized'}})
 $script:Ui.CloseButton.Add_Click({$script:Window.Hide();Set-Footer 'Window hidden to tray. Background heartbeat remains independent.'})
 $script:Window.Add_Closing({if(-not $script:AllowExit){$_.Cancel=$true;$script:Window.Hide()}})
 $script:Ui.NavHome.Add_Click({Show-Page 'Home';Refresh-Home})
 $script:Ui.NavPolicies.Add_Click({Show-Page 'Policies'})
 $script:Ui.NavLovable.Add_Click({Show-Page 'Lovable'})
 $script:Ui.NavUpdates.Add_Click({Show-Page 'Updates';Refresh-UpdatesPage})
 $script:Ui.NavTools.Add_Click({Show-Page 'Tools'})
 $script:Ui.FooterVersion.Add_MouseLeftButtonUp({Show-Page 'Updates';Refresh-UpdatesPage})
 # Block and Allow: each button's Tag says which item and which way.
 foreach($entry in $script:ItemRows.GetEnumerator()){
  $script:Ui[$entry.Value[1]].Tag=$entry.Key+'|Block'
  $script:Ui[$entry.Value[2]].Tag=$entry.Key+'|Allow'
  foreach($button in @($script:Ui[$entry.Value[1]],$script:Ui[$entry.Value[2]])){
   $button.Add_Click({$t=([string]$this.Tag).Split('|');Invoke-LockItem $t[0] ($t[1] -eq 'Block')})
  }
 }
 $script:Ui.BlockWinUpdate.Add_Click({Invoke-WindowsUpdate $true})
 $script:Ui.AllowWinUpdate.Add_Click({Invoke-WindowsUpdate $false})
 $script:Ui.ClientShellOnButton.Add_Click({Invoke-ClientShell $true})
 $script:Ui.ClientShellOffButton.Add_Click({Invoke-ClientShell $false})
 $script:Ui.UnlockAllButton.Add_Click({Invoke-UnlockAll})
 $script:Ui.CopyDiagnosticsButton.Add_Click({Copy-Diagnostics})
 $script:Ui.HomeRefreshButton.Add_Click({Refresh-All})
 $script:Ui.LanEnableButton.Add_Click({Invoke-LanPlay 'Enable'})
 $script:Ui.LanDisableButton.Add_Click({Invoke-LanPlay 'Disable'})
 $script:Ui.LanPreviewButton.Add_Click({Show-LanDetails})
 $script:Ui.EditApprovedSitesButton.Add_Click({Edit-ApprovedSites})
 $script:Ui.OpenHelpButton.Add_Click({Show-CompanionHelp})
 $script:Ui.ConfigureAutologonButton.Add_Click({Invoke-AutologonSetup 'Configure'})
 $script:Ui.AutologonStatusButton.Add_Click({Invoke-AutologonSetup 'Status'})
 $script:Ui.DisableAutologonButton.Add_Click({Invoke-AutologonSetup 'Disable'})
 $script:Ui.VerifyPolicyButton.Add_Click({Refresh-All})
 $script:Ui.UsbEnableButton.Add_Click({
  try {
   Assert-Admin
   if(-not (Ask-YesNo "Block USB storage for every account on this PC, administrators included?`n`nThe guest's own USB row is usually enough. Keyboards, mice and controllers keep working." 'Block USB storage')){return}
   [void](Start-RkaWorker 'USB-Storage.ps1' '-Action Enable')
   Update-UsbStatus; Set-Footer 'USB storage blocked. Try a flash drive and a controller to check.'
  } catch {Show-Failure $_.Exception.Message 'USB storage setup failed'}
 })
 $script:Ui.UsbRestoreButton.Add_Click({
  try {[void](Start-RkaWorker 'USB-Storage.ps1' '-Action Restore');Update-UsbStatus;Refresh-Home;Set-Footer 'USB storage is allowed again for every account.'} catch{Show-Failure $_.Exception.Message 'USB storage'}
 })
 $script:Ui.RemoteInstall.Add_Click({Invoke-RemoteSetup 'Upgrade'})
 $script:Ui.RemoteEnableChanges.Add_Click({Invoke-RemoteSetup 'EnableChanges'})
 $script:Ui.RemoteDisableChanges.Add_Click({Invoke-RemoteSetup 'DisableChanges'})
 $script:Ui.RemoteEnableUsb.Add_Click({Invoke-RemoteSetup 'EnableUsb'})
 $script:Ui.RemoteDisableUsb.Add_Click({Invoke-RemoteSetup 'DisableUsb'})
 $script:Ui.RemoteSyncProfile.Add_Click({Invoke-RemoteSetup 'SyncProfile'})
 $script:Ui.RemoteRemove.Add_Click({if(Ask-YesNo 'Disable remote command polling on this PC? Existing Lovable heartbeat will continue.' 'Disable remote commands'){Invoke-RemoteSetup 'Remove'}})
 $script:Ui.RemoteStatus.Add_Click({Update-RemoteStatus})
 $script:Ui.UpdateCheckButton.Add_Click({Refresh-UpdatesPage;Refresh-AgentIndicators})
 $script:Ui.UpdateNowButton.Add_Click({Invoke-UpdateNow})
 $script:Ui.UpdateOpenGithubButton.Add_Click({try{Start-Process 'https://github.com/aehs01/rka-companion-releases/releases'}catch{Show-Failure $_.Exception.Message 'Could not open GitHub'}})
 $script:Ui.ViewPolicyLog.Add_Click({Open-LogFile (Join-Path $script:RecoveryRoot 'worker.log')})
 $script:Ui.QuickCheckHeartbeat.Add_Click({Check-Heartbeat})
 $script:Ui.CheckConnectionButton.Add_Click({Check-Heartbeat})
 $script:Ui.ConnectDeviceButton.Add_Click({
  try {
   if(-not(Ask-YesNo 'This opens the EXISTING heartbeat setup. Your working Lovable connection does not require reinstalling. Continue only if re-enrollment is necessary.' 'Reconnect?')){return}
   Start-Process -FilePath $script:PowerShellExe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:AppRoot 'Heartbeat-Setup.ps1')+'"') -Verb RunAs -Wait
   Check-Heartbeat
  }catch{Show-Failure $_.Exception.Message 'Reconnect failed'}
 })
 $script:Ui.ViewHeartbeatLog.Add_Click({Open-LogFile (Join-Path $env:ProgramData 'RKA-Lockdown-Agent\Heartbeat\status.log')})
 $script:Ui.ChromeInstall.Add_Click({Check-Chrome 'Install'})
 $script:Ui.ServerAddressSave.Add_Click({Save-ServerAddress $false})
 $script:Ui.ServerAddressRemove.Add_Click({Save-ServerAddress $true})
 $script:Ui.ServerAddressCheck.Add_Click({Refresh-ServerAddress;Set-Footer 'Checked rkaserver'})
 $script:Ui.ChromeRemove.Add_Click({Check-Chrome 'Remove'})
 $script:Ui.ChromeStatus.Add_Click({Check-Chrome 'Status'})
 $script:Ui.RunHealthButton.Add_Click({Run-Health})
 $script:Ui.ExportProfileButton.Add_Click({Export-Profile})
 $script:Ui.ImportProfileButton.Add_Click({Import-Profile})
 $script:Ui.DeployIntranetButton.Add_Click({
  try{
   $guest=Selected-Guest
   $url=Get-CurrentPortalUrl
   $args='-TargetSid "'+$guest.SID+'" -Url "'+$url+'"'
   Start-RkaWorker 'Deploy-Guest-Intranet.ps1' $args
   Set-Footer ('LAN portal shortcut deployed for '+$guest.Name)
   Set-Footer ('Intranet shortcut added to '+$guest.Name+"'s desktop.")
  }catch{Show-Failure $_.Exception.Message 'Deploy intranet shortcut failed'}
 })
 $script:Ui.SaveDesktopBackupButton.Add_Click({
  try{$g=Selected-Guest;Start-RkaWorker 'Guest-Desktop-Backup.ps1' ('-Action Save -TargetSid "'+$g.SID+'"');Set-Footer 'Guest shortcuts backed up.'}catch{Show-Failure $_.Exception.Message 'Backup shortcuts failed'}
 })
 $script:Ui.RestoreDesktopBackupButton.Add_Click({
  try{$g=Selected-Guest;Start-RkaWorker 'Guest-Desktop-Backup.ps1' ('-Action Restore -TargetSid "'+$g.SID+'"');Set-Footer 'Guest shortcuts restored. Icon positions are not.'}catch{Show-Failure $_.Exception.Message 'Restore shortcuts failed'}
 })
 $script:Ui.CopyAdminShortcutsButton.Add_Click({
  try{
   Assert-Admin
   $g=Selected-Guest
   $adminDesktop=[Environment]::GetFolderPath('DesktopDirectory')
   $candidates=@(Get-ChildItem -LiteralPath $adminDesktop -File -ErrorAction Stop|Where-Object {$_.Extension -in @('.lnk','.url')})
   if($candidates.Count -eq 0){Show-Notice 'No .lnk or .url shortcuts found on the current administrator desktop.' 'Copy game shortcuts';return}
   $preview=(@($candidates|Select-Object -First 16|ForEach-Object {$_.Name}) -join "`n")
   if(-not(Ask-YesNo ("Copy game shortcuts from administrator desktop to guest $($g.Name)?`n`nCandidates ($($candidates.Count)):`n$preview`n`nSafety: existing guest shortcuts will NOT be overwritten, private-admin paths and Windows admin tools will be skipped. Copying a shortcut does NOT elevate the program.") 'Copy shortcuts to guest')){return}
   Start-RkaWorker 'Copy-Admin-Shortcuts.ps1' ('-TargetSid "'+$g.SID+'"')
   Show-Notice ('Shortcut copy completed for '+$g.Name+'. Check the guest Desktop; unsafe shortcuts and existing files were skipped. See the protected copy report under ProgramData\RKA-Lockdown-Agent\DesktopBackup.') 'Copy game shortcuts'
  }catch{Show-Failure $_.Exception.Message 'Copy game shortcuts failed'}
 })
 $script:Ui.GameCompatibilityScanButton.Add_Click({
  try{
   Assert-Admin
   $g=Selected-Guest
   $cmd='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:AppRoot 'Game-Compatibility.ps1')+'" -TargetSid "'+$g.SID+'"'
   $output=@(& $script:PowerShellExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:AppRoot 'Game-Compatibility.ps1') -TargetSid $g.SID 2>&1 | ForEach-Object {[string]$_}) -join "`r`n"
   $script:Ui.GameCompatibilityReport.Text=$output
   Set-Footer 'Read-only compatibility scan completed; no launch or UAC policy changed'
  }catch{Show-Failure $_.Exception.Message 'Game compatibility scan failed'}
 })
 $script:Ui.UpdateInstallZipButton.Add_Click({
  try{
   Assert-Admin
   $picker=New-Object Microsoft.Win32.OpenFileDialog
   $picker.Title='Select a trusted RKA Companion release ZIP (local or administrator-accessible LAN share)'
   $picker.Filter='ZIP release archives (*.zip)|*.zip'
   $picker.CheckFileExists=$true
   $picker.Multiselect=$false
   if($picker.ShowDialog($script:Window) -ne $true){return}
   $zip=[string]$picker.FileName
   $hash=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
   if(-not(Ask-YesNo ("Upgrade this PC from this release ZIP?`n`nFile: $zip`nSHA256: $hash`n`nOnly use official RKA releases. The ZIP is not code-signed; checksum alone does NOT establish publisher authenticity. This creates a backup, copies files and upgrades both agent tasks if enrolled. You must review results and restart the Companion after successful installation.") 'Install trusted ZIP update')){return}
   $out=Invoke-UpdaterProcess 'InstallLocal' $zip
   if($out -notmatch 'UPDATE INSTALLED:'){throw 'Update output did not verify a successful install.'}
   Show-Notice 'Update installed and agent upgrade attempted. Close this old Companion window and reopen the administrator shortcut; check installed agent file and latest authenticated poll version before updating other PCs.' 'RKA update completed'
  }catch{Show-Failure $_.Exception.Message 'RKA package update failed'}
 })
 $script:Ui.CreateShortcutButton.Add_Click({
  try{Start-RkaWorker 'Create-Desktop-Shortcut.ps1' '' $false;Show-Notice 'RKA Companion shortcut added to your desktop. RKA Client & Companion Setup adds one for every administrator.' 'Shortcut created'}catch{Show-Failure $_.Exception.Message 'Shortcut failed'}
 })
 $script:Ui.OpenLogsButton.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$script:DataRoot+'"')})
 $script:Ui.OpenPortalButton.Add_Click({try{$url=Get-CurrentPortalUrl;if(-not(Check-Url $url)){throw 'Invalid intranet URL.'};Start-Process $url}catch{Show-Failure $_.Exception.Message}})
 $script:Ui.OpenSteamButton.Add_Click({try{Start-Process 'steam://open/main'}catch{Show-Failure $_.Exception.Message 'Steam not available'}})
 $script:Ui.InstallDiscordButton.Add_Click({try{Start-Process 'https://discord.com/download'}catch{Show-Failure $_.Exception.Message 'Could not open Discord download page'}})
 Setup-Tray
 Refresh-PolicyStatuses;Refresh-ChromeQuickStatus;Update-LanStatus;Refresh-AgentIndicators;Refresh-Home;Refresh-UpdatesPage;Refresh-ServerAddress
 Show-Page 'Home'
 Write-RkaLog ('WPF v'+$script:AppVersion+' opening')
 [void]$script:Window.ShowDialog()
}catch{
 $msg=$_.Exception.ToString()
 Write-RkaLog 'FATAL WPF STARTUP: '+$msg
 try{[System.Windows.MessageBox]::Show($msg,'RKA WPF Startup Error')|Out-Null}catch{Write-Host $msg}
}finally{
 try{if($script:TrayIcon){$script:TrayIcon.Visible=$false;$script:TrayIcon.Dispose()}}catch{}
 try{if($script:MutexAcquired -and $script:Mutex){$script:Mutex.ReleaseMutex()}}catch{}
 try{if($script:Mutex){$script:Mutex.Dispose()}}catch{}
}
